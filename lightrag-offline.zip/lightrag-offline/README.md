# Offline LightRAG + MinerU (Windows 11, no admin, no Docker, no database service)

See the PDF guide `LightRAG_Offline_Guide.pdf` for the full explanation. Quick path:

## A. Online PC (test everything first)
1. Put this folder at a short path without spaces, e.g. `D:\rag`.
2. `scripts\01_setup_online.bat`   (installs Python 3.11 for your user only, 2 venvs, Ollama runtime)
3. `scripts\02_fetch_models.bat`   (or follow docs\MODELS.md)
4. `scripts\20_start_all.bat`      -> browser opens http://127.0.0.1:9621/webui
5. `scripts\50_ingest.bat "D:\some docs"` or use Upload in the UI. Ask questions in the Retrieval tab.
6. `scripts\60_doctor.bat` when something is wrong.
7. When happy: `scripts\03_build_bundle.bat`  -> `dist\` (DVD-sized parts, no models).

## B. Offline PC
1. Copy all files from `dist\` into one folder, run `RESTORE.bat D:\rag`.
2. Copy your models into `D:\rag\models\...` (docs\MODELS.md).
3. `scripts\10_install_offline.bat` then `scripts\20_start_all.bat`.

## Where to customise
* Everyday settings: `config\user_settings.env` -> `scripts\30_apply_config.bat`
* Advanced LightRAG variables: `config\lightrag.env.template`
* Entity types / extraction examples: `prompts\entity_type\technical_docs.yml`
* Answer instructions: `prompts\user_prompt\answer_style.md`
* Code: `scripts\40_make_editable_copy.bat lightrag` (or `mineru`), edit under `custom\`, restart.

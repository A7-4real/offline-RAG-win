@echo off
call "%~dp0env.bat"
title Reranker - port %RERANK_PORT%
set "HF_HUB_OFFLINE=1"
set "TRANSFORMERS_OFFLINE=1"
if not defined RERANK_DEVICE set "RERANK_DEVICE=cpu"
"%VENV_MN%\Scripts\python.exe" "%ROOT%\tools\rerank_server.py" --port %RERANK_PORT% --model "%ROOT%\models\rerank\bge-reranker-v2-m3" --device %RERANK_DEVICE%
pause

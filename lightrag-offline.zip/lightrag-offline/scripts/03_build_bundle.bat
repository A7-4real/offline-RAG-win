@echo off
rem DEV PC WITH INTERNET, after everything works here: pack wheels + code into DVD-sized parts (models excluded).
call "%~dp0env.bat"
"%PY%" "%ROOT%\tools\build_bundle.py" %*
pause

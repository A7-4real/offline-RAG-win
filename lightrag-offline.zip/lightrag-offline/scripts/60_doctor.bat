@echo off
call "%~dp0env.bat"
"%PY%" "%ROOT%\tools\doctor.py" static
"%PY%" "%ROOT%\tools\doctor.py" live
pause

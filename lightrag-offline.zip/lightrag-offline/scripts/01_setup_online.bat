@echo off
rem DEV PC WITH INTERNET: install Python + both virtual environments + Ollama runtime.
call "%~dp0env.bat"
call "%~dp0_ensure_python.bat" online || exit /b 1
"%PY%" "%ROOT%\tools\gen_config.py" || exit /b 1
"%PY%" "%ROOT%\tools\setup.py" online || exit /b 1
echo.
echo DONE. Next step: 02_fetch_models.bat
pause

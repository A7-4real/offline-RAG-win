@echo off
rem Re-generate .env / mineru.json after editing config\user_settings.env or moving the folder.
call "%~dp0env.bat"
"%PY%" "%ROOT%\tools\gen_config.py"
echo Restart the servers (21_stop_all.bat, then 20_start_all.bat) for changes to take effect.
pause

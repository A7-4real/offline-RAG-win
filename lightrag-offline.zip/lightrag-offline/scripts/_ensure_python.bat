@echo off
rem Installs Python 3.11 into <ROOT>\runtime\python311 for the CURRENT USER ONLY (no admin rights).
rem Usage: call _ensure_python.bat [online]
call "%~dp0env.bat"
if exist "%PY%" (
  echo Python found: %PY%
  exit /b 0
)
set "PYINST=%BUNDLE%\installers\python-3.11.9-amd64.exe"
if not exist "%PYINST%" (
  if /i "%~1"=="online" (
    if not exist "%BUNDLE%\installers" mkdir "%BUNDLE%\installers"
    echo Downloading Python 3.11.9 installer ...
    curl.exe -L --fail -o "%PYINST%" https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe
    if errorlevel 1 (
      echo Download failed. Install Python 3.11 yourself, then run:  set PYTHON_OVERRIDE=C:\path\to\python.exe
      exit /b 1
    )
  ) else (
    echo ERROR: %PYINST% not found. Restore the bundle first, or set PYTHON_OVERRIDE to a Python 3.11 you already have.
    exit /b 1
  )
)
echo Installing Python 3.11 for the current user into %PY_DIR% ...
start /wait "" "%PYINST%" /quiet InstallAllUsers=0 "TargetDir=%PY_DIR%" Include_launcher=0 InstallLauncherAllUsers=0 Include_test=0 Include_doc=0 Include_tcltk=0 Shortcuts=0 PrependPath=0 AssociateFiles=0 Include_pip=1
if not exist "%PY%" (
  echo ERROR: Python installation failed. If your PC blocks installers, install/copy any Python 3.11 and use PYTHON_OVERRIDE.
  exit /b 1
)
echo Python installed.
exit /b 0

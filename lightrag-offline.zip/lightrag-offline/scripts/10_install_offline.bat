@echo off
rem TARGET PC (no internet, no admin): install everything from the restored bundle.
call "%~dp0env.bat"
call "%~dp0_ensure_python.bat" || exit /b 1
"%PY%" "%ROOT%\tools\gen_config.py" || exit /b 1
"%PY%" "%ROOT%\tools\setup.py" offline || exit /b 1
"%PY%" "%ROOT%\tools\doctor.py" static
pause

@echo off
call "%~dp0env.bat"
title LightRAG server - port %LIGHTRAG_PORT%
if exist "%ROOT%\custom\lightrag_src\lightrag" (
  set "PYTHONPATH=%ROOT%\custom\lightrag_src"
  echo Using customised LightRAG code from custom\lightrag_src
)
cd /d "%ROOT%\data\lightrag_run"
"%VENV_LR%\Scripts\lightrag-server.exe"
pause

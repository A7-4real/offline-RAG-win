@echo off
call "%~dp0env.bat"
title MinerU API - port %MINERU_PORT% (device: %MINERU_DEVICE%)
set "MINERU_TOOLS_CONFIG_JSON=%ROOT%\config\mineru.json"
set "MINERU_MODEL_SOURCE=local"
set "MINERU_DEVICE_MODE=%MINERU_DEVICE%"
set "MINERU_API_OUTPUT_ROOT=%ROOT%\data\mineru_output"
set "HF_HUB_OFFLINE=1"
set "TRANSFORMERS_OFFLINE=1"
set "HF_HUB_DISABLE_TELEMETRY=1"
if exist "%ROOT%\custom\mineru_src\mineru" (
  set "PYTHONPATH=%ROOT%\custom\mineru_src"
  echo Using customised MinerU code from custom\mineru_src
)
"%VENV_MN%\Scripts\mineru-api.exe" --host 127.0.0.1 --port %MINERU_PORT%
pause

@echo off
rem DEV PC WITH INTERNET: download Ollama models, MinerU models, tokenizer cache (and reranker if enabled).
call "%~dp0env.bat"
"%PY%" "%ROOT%\tools\fetch_models.py" %*
pause

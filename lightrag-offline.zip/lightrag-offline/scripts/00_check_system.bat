@echo off
call "%~dp0env.bat"
echo ===== Windows =====
ver
echo.
echo ===== RAM / CPU =====
systeminfo | findstr /C:"Total Physical Memory" /C:"Processor(s)" /C:"OS Name"
echo.
echo ===== GPU =====
nvidia-smi 2>nul || echo nvidia-smi not found on PATH ^(driver may still be fine, try C:\Windows\System32\nvidia-smi.exe^)
echo.
echo ===== Free disk space on the install drive =====
for %%D in ("%ROOT%") do dir /-c "%%~dD\" | findstr /i "bytes free"
echo.
echo ===== Install path =====
echo %ROOT%
echo %ROOT% | findstr /r /c:" " >nul && echo WARNING: the path contains spaces - move the folder to something like D:\rag
echo.
if exist "%PY%" ( "%PY%" --version ) else ( echo Private Python not installed yet )
pause

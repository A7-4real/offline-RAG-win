@echo off
call "%~dp0env.bat"
echo Stopping services by port (only processes listening on this install's ports) ...
for %%P in (%LIGHTRAG_PORT% %RERANK_PORT% %MINERU_PORT% %OLLAMA_PORT%) do (
  for /f "tokens=5" %%I in ('netstat -ano ^| findstr /r /c:":%%P .*LISTENING"') do (
    echo   port %%P  pid %%I
    taskkill /pid %%I /t /f >nul 2>&1
  )
)
echo Done.
pause

@echo off
rem Copies the installed LightRAG (or MinerU) Python package into custom\ so you can edit it.
rem The start scripts automatically prefer the copy in custom\ over the installed one.
rem Usage:  40_make_editable_copy.bat lightrag     or     40_make_editable_copy.bat mineru
call "%~dp0env.bat"
"%PY%" "%ROOT%\tools\make_editable_copy.py" %*
pause

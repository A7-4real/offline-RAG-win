@echo off
call "%~dp0env.bat"
if not exist "%ROOT%\data\lightrag_run\.env" "%PY%" "%ROOT%\tools\gen_config.py"

echo [1/4] Starting Ollama ...
start "Ollama" "%~dp0start_ollama.bat"
call :wait http://127.0.0.1:%OLLAMA_PORT%/api/version 90 Ollama || exit /b 1

echo [2/4] Starting MinerU parser service ...
start "MinerU" "%~dp0start_mineru.bat"
call :wait http://127.0.0.1:%MINERU_PORT%/health 180 MinerU || exit /b 1

if /i "%RERANK%"=="on" (
  echo [3/4] Starting reranker ...
  start "Reranker" "%~dp0start_rerank.bat"
  call :wait http://127.0.0.1:%RERANK_PORT%/health 180 Reranker || exit /b 1
) else (
  echo [3/4] Reranker disabled
)

echo [4/4] Starting LightRAG ...
start "LightRAG" "%~dp0start_lightrag.bat"
call :wait http://127.0.0.1:%LIGHTRAG_PORT%/health 180 LightRAG || exit /b 1

echo.
echo Everything is up. Opening the web UI ...
start "" "http://127.0.0.1:%LIGHTRAG_PORT%/webui"
exit /b 0

:wait
set /a n=0
:waitloop
curl.exe -s -o nul --max-time 3 %1
if not errorlevel 1 ( echo     %3 is ready & exit /b 0 )
set /a n+=2
if %n% GEQ %2 ( echo     ERROR: %3 did not start within %2 seconds - read its window & exit /b 1 )
timeout /t 2 /nobreak >nul
goto waitloop

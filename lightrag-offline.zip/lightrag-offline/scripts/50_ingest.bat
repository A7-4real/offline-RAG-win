@echo off
rem Copy a folder (or files) of documents into data\inputs and tell LightRAG to index them.
rem Usage:  50_ingest.bat "D:\my documents"
call "%~dp0env.bat"
"%VENV_LR%\Scripts\python.exe" "%ROOT%\tools\ingest_folder.py" %*
pause

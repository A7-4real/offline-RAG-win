@echo off
rem ===================================================================
rem  Shared environment. Every script starts with:  call "%~dp0env.bat"
rem  Nothing here touches the registry, PATH or the user profile.
rem ===================================================================
set "ROOT=%~dp0.."
for %%I in ("%ROOT%") do set "ROOT=%%~fI"
set "BUNDLE=%ROOT%\bundle"
set "PY_DIR=%ROOT%\runtime\python311"
set "PY=%PY_DIR%\python.exe"
rem To use a system Python 3.11 instead, set PYTHON_OVERRIDE before running a script.
if defined PYTHON_OVERRIDE set "PY=%PYTHON_OVERRIDE%"
set "VENV_LR=%ROOT%\runtime\venv_lightrag"
set "VENV_MN=%ROOT%\runtime\venv_mineru"
set "OLLAMA_EXE=%ROOT%\runtime\ollama\ollama.exe"

rem ---- defaults, then overridden by config\runtime.env (written by tools\gen_config.py) ----
set "OLLAMA_PORT=11435"
set "MINERU_PORT=8000"
set "RERANK_PORT=8001"
set "LIGHTRAG_PORT=9621"
set "MINERU_DEVICE=cpu"
set "RERANK=off"
if exist "%ROOT%\config\runtime.env" (
  for /f "usebackq eol=# tokens=1,* delims==" %%A in ("%ROOT%\config\runtime.env") do set "%%A=%%B"
)

rem ---- Ollama: private instance, private model folder, private port ----
set "OLLAMA_HOST=127.0.0.1:%OLLAMA_PORT%"
set "OLLAMA_MODELS=%ROOT%\models\ollama"
set "OLLAMA_FLASH_ATTENTION=1"
set "OLLAMA_KV_CACHE_TYPE=q8_0"
set "OLLAMA_NUM_PARALLEL=1"
set "OLLAMA_MAX_LOADED_MODELS=2"
set "OLLAMA_KEEP_ALIVE=30m"
set "OLLAMA_NO_CLOUD=1"

set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"

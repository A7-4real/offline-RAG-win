@echo off
call "%~dp0env.bat"
title Ollama - private instance on port %OLLAMA_PORT%
echo Models folder: %OLLAMA_MODELS%
"%OLLAMA_EXE%" serve
pause

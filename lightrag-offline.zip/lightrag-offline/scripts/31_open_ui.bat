@echo off
call "%~dp0env.bat"
start "" "http://127.0.0.1:%LIGHTRAG_PORT%/webui"

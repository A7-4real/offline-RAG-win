#!/usr/bin/env python
"""Tiny local reranker speaking the Cohere/Jina-style API that LightRAG expects.

    python rerank_server.py --model <folder with bge-reranker-v2-m3> --port 8001 --device cpu

POST /rerank  {"query","documents":[...],"top_n"}  ->  {"results":[{"index","relevance_score"}]}
Runs inside venv_mineru (it already has torch + transformers + fastapi).
"""
import argparse

import torch
import uvicorn
from fastapi import FastAPI
from pydantic import BaseModel
from transformers import AutoModelForSequenceClassification, AutoTokenizer

ap = argparse.ArgumentParser()
ap.add_argument("--model", required=True)
ap.add_argument("--port", type=int, default=8001)
ap.add_argument("--device", default="cpu")
ap.add_argument("--max-length", type=int, default=512)
args = ap.parse_args()

tok = AutoTokenizer.from_pretrained(args.model, local_files_only=True)
model = AutoModelForSequenceClassification.from_pretrained(args.model, local_files_only=True)
if args.device != "cpu":
    model = model.half()
model = model.to(args.device).eval()
app = FastAPI()


class Req(BaseModel):
    query: str
    documents: list
    top_n: int | None = None
    model: str | None = None


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/rerank")
@app.post("/v1/rerank")
def rerank(r: Req):
    docs = [d if isinstance(d, str) else str(d.get("text", d)) for d in r.documents]
    scores = []
    with torch.no_grad():
        for i in range(0, len(docs), 16):
            batch = docs[i:i + 16]
            enc = tok([r.query] * len(batch), batch, padding=True, truncation=True,
                      max_length=args.max_length, return_tensors="pt").to(args.device)
            scores += torch.sigmoid(model(**enc).logits.view(-1).float()).cpu().tolist()
    order = sorted(range(len(docs)), key=lambda i: scores[i], reverse=True)
    if r.top_n:
        order = order[:r.top_n]
    return {"results": [{"index": i, "relevance_score": scores[i]} for i in order]}


if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=args.port)

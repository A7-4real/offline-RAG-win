#!/usr/bin/env python
"""Build the transfer bundle in dist/  (run on the ONLINE PC after you tested everything).

    python tools/build_bundle.py [--part-gb 4.3]

1. freezes both virtual environments into exact lock files
2. downloads every wheel into bundle/wheelhouse/ (so the target needs no internet)
3. makes sure the Python installer and the Ollama zip are in bundle/installers/
4. writes dist/core.tar.NNN (project, scripts, prompts, small wheels, installers) and
   dist/wheels_mineru.tar.NNN (PyTorch + MinerU wheels), cut into DVD-sized parts,
   plus SHA256SUMS.txt and RESTORE.bat.
Models (models/) and your data (data/) are NOT included - see docs/MODELS.md.
"""
import hashlib
import subprocess
import sys
import tarfile
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DIST = ROOT / "dist"
BUNDLE = ROOT / "bundle"
sys.path.insert(0, str(ROOT / "tools"))
from doctor import read_kv  # noqa: E402

PART = int(float(sys.argv[sys.argv.index("--part-gb") + 1]) * 1e9) if "--part-gb" in sys.argv else int(4.3e9)
PYURL = "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe"
OLLAMA_URL = "https://github.com/ollama/ollama/releases/latest/download/ollama-windows-amd64.zip"


def vpy(name):
    return str(ROOT / "runtime" / name / "Scripts" / "python.exe")


def sh(cmd):
    print(">>", " ".join(cmd), flush=True)
    subprocess.run(cmd, check=True)


def fetch(url, dest):
    if dest.exists():
        return
    dest.parent.mkdir(parents=True, exist_ok=True)
    print("Downloading", url)
    urllib.request.urlretrieve(url, dest)


class Splitter:
    """File-like object that writes a stream into numbered parts of at most PART bytes."""

    def __init__(self, prefix):
        self.prefix, self.n, self.f, self.size, self.sums = prefix, 0, None, 0, []
        self.h = None

    def _open(self):
        if self.f:
            self._close()
        self.n += 1
        self.name = f"{self.prefix}.{self.n:03d}"
        self.f, self.size, self.h = open(DIST / self.name, "wb"), 0, hashlib.sha256()

    def _close(self):
        self.f.close()
        self.sums.append((self.h.hexdigest(), self.name))

    def write(self, data):
        mv = memoryview(data)
        while len(mv):
            if not self.f or self.size >= PART:
                self._open()
            take = mv[: PART - self.size]
            self.f.write(take)
            self.h.update(take)
            self.size += len(take)
            mv = mv[len(take):]
        return len(data)

    def close(self):
        if self.f:
            self._close()
            self.f = None


def pack(prefix, base, include, exclude=lambda rel: False):
    sp = Splitter(prefix)
    with tarfile.open(fileobj=sp, mode="w|") as tar:
        for top in include:
            top = ROOT / top
            files = [top] if top.is_file() else sorted(p for p in top.rglob("*") if p.is_file())
            for p in files:
                rel = p.relative_to(ROOT).as_posix()
                if "__pycache__" in rel or exclude(rel):
                    continue
                tar.add(p, arcname=rel, recursive=False)
    sp.close()
    return sp.sums


def main():
    s = read_kv(ROOT / "config" / "user_settings.env")
    (BUNDLE / "locks").mkdir(parents=True, exist_ok=True)
    for name, venv in (("lightrag", "venv_lightrag"), ("mineru", "venv_mineru")):
        out = subprocess.run([vpy(venv), "-m", "pip", "freeze", "--exclude-editable"],
                             capture_output=True, text=True, check=True).stdout
        lines = [l for l in out.splitlines() if l.strip() and " @ " not in l]
        (BUNDLE / "locks" / f"{name}.lock.txt").write_text("\n".join(lines) + "\n")
        wheels = BUNDLE / "wheelhouse" / name
        wheels.mkdir(parents=True, exist_ok=True)
        cmd = [vpy(venv), "-m", "pip", "download", "-r", str(BUNDLE / "locks" / f"{name}.lock.txt"), "-d", str(wheels)]
        if name == "mineru":
            cmd += ["--index-url", s.get("TORCH_INDEX", "https://download.pytorch.org/whl/cu126"),
                    "--extra-index-url", "https://pypi.org/simple"]
        sh(cmd)
    ver = subprocess.run([vpy("venv_lightrag"), "-c",
                          "import sys;print(f'cp{sys.version_info.major}{sys.version_info.minor}')"],
                         capture_output=True, text=True, check=True).stdout.strip()
    (BUNDLE / "locks" / "python_tag.txt").write_text(ver)
    fetch(PYURL, BUNDLE / "installers" / "python-3.11.9-amd64.exe")
    fetch(OLLAMA_URL, BUNDLE / "installers" / "ollama-windows-amd64.zip")

    DIST.mkdir(exist_ok=True)
    for old in DIST.glob("*"):
        old.unlink()
    skip_top = ("runtime/", "models/", "data/", "dist/", "bundle/wheelhouse/mineru/")
    top_items = [p.name for p in ROOT.iterdir() if p.name not in ("runtime", "models", "dist", "data")]
    sums = pack("core", ROOT, top_items + ["data/inputs/.keep"], lambda r: r.startswith(skip_top))
    sums += pack("wheels_mineru", ROOT, ["bundle/wheelhouse/mineru"])
    (DIST / "SHA256SUMS.txt").write_text("".join(f"{h} {n}\n" for h, n in sums))
    (DIST / "RESTORE.bat").write_text(RESTORE, encoding="ascii", newline="\r\n")
    print(f"\nDone. Burn/copy everything in {DIST} ({len(sums)} part files + SHA256SUMS.txt + RESTORE.bat).")


RESTORE = r"""@echo off
setlocal enabledelayedexpansion
rem Usage: RESTORE.bat D:\rag      (all part files must sit next to this file)
set "DEST=%~1"
if "%DEST%"=="" ( echo Usage: RESTORE.bat D:\rag & exit /b 1 )
if not exist "%DEST%" mkdir "%DEST%"
set "SRC=%~dp0"
echo Verifying checksums (this takes a few minutes) ...
set BAD=0
for /f "usebackq tokens=1,2" %%H in ("%SRC%SHA256SUMS.txt") do (
  set "ACT="
  for /f "skip=1 delims=" %%X in ('certutil -hashfile "%SRC%%%I" SHA256') do if not defined ACT set "ACT=%%X"
  set "ACT=!ACT: =!"
  if /i "!ACT!"=="%%H" ( echo   ok   %%I ) else ( echo   BAD  %%I & set BAD=1 )
)
if "%BAD%"=="1" ( echo A part is damaged or missing. Re-copy it and run again. & exit /b 1 )
for %%C in (core wheels_mineru) do (
  if exist "%SRC%%%C.tar.001" (
    echo Joining %%C ...
    copy /b "%SRC%%%C.tar.*" "%SRC%%%C.joined" >nul
    echo Extracting %%C ...
    tar -xf "%SRC%%%C.joined" -C "%DEST%"
    del "%SRC%%%C.joined"
  )
)
echo.
echo Restored to %DEST%.  Next: copy your models (docs\MODELS.md), then run scripts\10_install_offline.bat
"""

if __name__ == "__main__":
    main()

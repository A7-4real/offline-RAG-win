#!/usr/bin/env python
"""Generate every machine-specific config file from config/user_settings.env.

Run it again whenever you (a) edit user_settings.env or (b) move the install
folder to another path/PC.  Uses the Python standard library only.

Writes:
  data/lightrag_run/.env      LightRAG server configuration
  config/mineru.json          MinerU model locations (absolute paths for THIS install)
  config/runtime.env          values that the .bat scripts read (ports, device, ...)
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def read_kv(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        out[key.strip()] = value.strip()
    return out


def main() -> int:
    settings_path = ROOT / "config" / "user_settings.env"
    if not settings_path.exists():
        print(f"ERROR: {settings_path} not found", file=sys.stderr)
        return 1
    s = read_kv(settings_path)
    s["ROOT"] = ROOT.as_posix()  # forward slashes work everywhere, including .env files

    # ---- sanity checks that save hours of debugging ----
    try:
        ctx, total = int(s["LLM_NUM_CTX"]), int(s["MAX_TOTAL_TOKENS"])
    except (KeyError, ValueError):
        print("ERROR: LLM_NUM_CTX and MAX_TOTAL_TOKENS must be integers", file=sys.stderr)
        return 1
    if ctx < total + 2000:
        print(f"ERROR: LLM_NUM_CTX ({ctx}) must be at least MAX_TOTAL_TOKENS + 2000 ({total + 2000})",
              file=sys.stderr)
        return 1
    if s.get("LIGHTRAG_HOST", "127.0.0.1") != "127.0.0.1" and not s.get("LIGHTRAG_API_KEY"):
        print("ERROR: LIGHTRAG_HOST is not 127.0.0.1 but LIGHTRAG_API_KEY is empty. "
              "Set a key or bind to 127.0.0.1.", file=sys.stderr)
        return 1

    # ---- LightRAG .env ----
    template = (ROOT / "config" / "lightrag.env.template").read_text(encoding="utf-8")
    missing: set[str] = set()

    def sub(match: re.Match) -> str:
        key = match.group(1)
        if key not in s:
            missing.add(key)
            return match.group(0)
        return s[key]

    env_text = re.sub(r"@([A-Z0-9_]+)@", sub, template)
    if missing:
        print("ERROR: placeholders without a value in user_settings.env: " + ", ".join(sorted(missing)),
              file=sys.stderr)
        return 1

    if s.get("RERANK", "off").lower() == "on":
        rerank_block = (
            "RERANK_BINDING=cohere\n"
            "RERANK_MODEL=bge-reranker-v2-m3\n"
            f"RERANK_BINDING_HOST=http://127.0.0.1:{s['RERANK_PORT']}/rerank\n"
            "RERANK_BINDING_API_KEY=local\n"
            "RERANK_BY_DEFAULT=True\n"
            "MIN_RERANK_SCORE=0.0\n"
        )
        env_text = env_text.replace("RERANK_BINDING=null\n", rerank_block)
    if s.get("LIGHTRAG_API_KEY"):
        env_text += f"\nLIGHTRAG_API_KEY={s['LIGHTRAG_API_KEY']}\n"

    run_dir = ROOT / "data" / "lightrag_run"
    for d in (run_dir, ROOT / "data" / "inputs", ROOT / "data" / "rag_storage",
              ROOT / "data" / "logs", ROOT / "data" / "mineru_output"):
        d.mkdir(parents=True, exist_ok=True)
    (run_dir / ".env").write_text(env_text, encoding="utf-8")

    # ---- MinerU model config: absolute paths of THIS install ----
    mineru_json = {
        "config_version": "1.3.2",
        "model-source": "local",
        "models-dir": {
            "pipeline": str(ROOT / "models" / "mineru" / "pipeline"),
            "vlm": str(ROOT / "models" / "mineru" / "vlm"),
        },
    }
    (ROOT / "config" / "mineru.json").write_text(json.dumps(mineru_json, indent=2), encoding="utf-8")

    # ---- values for the batch scripts (simple KEY=VALUE, read with `for /f`) ----
    keys = ["OLLAMA_PORT", "MINERU_PORT", "RERANK_PORT", "LIGHTRAG_PORT", "MINERU_DEVICE",
            "RERANK", "LLM_MODEL", "VLM_MODEL", "EMBED_MODEL", "TORCH_INDEX"]
    runtime = "\n".join(f"{k}={s[k]}" for k in keys if k in s) + "\n"
    (ROOT / "config" / "runtime.env").write_text(runtime, encoding="utf-8")

    print("Generated:")
    print(f"  {run_dir / '.env'}")
    print(f"  {ROOT / 'config' / 'mineru.json'}")
    print(f"  {ROOT / 'config' / 'runtime.env'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

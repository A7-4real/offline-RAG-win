#!/usr/bin/env python
"""Create the two isolated virtual environments and unpack Ollama.

    python tools/setup.py online     # dev PC with internet: install from PyPI + PyTorch index
    python tools/setup.py offline    # target PC: install ONLY from bundle/wheelhouse (no network)

Standard library only, so it runs with the freshly installed Python 3.11.

Layout created under <ROOT>/runtime/:
    venv_lightrag/   lightrag-hku[api] + ollama client           (small, pure Python)
    venv_mineru/     CUDA PyTorch + MinerU + transformers        (large)
    ollama/          portable ollama.exe (+ CUDA libs), no installer, no admin rights
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RUNTIME = ROOT / "runtime"
BUNDLE = ROOT / "bundle"
VENV_LR = RUNTIME / "venv_lightrag"
VENV_MN = RUNTIME / "venv_mineru"
OLLAMA_DIR = RUNTIME / "ollama"
OLLAMA_ZIP = BUNDLE / "installers" / "ollama-windows-amd64.zip"
OLLAMA_URL = "https://github.com/ollama/ollama/releases/latest/download/ollama-windows-amd64.zip"

# Versions that were verified to work together (LightRAG calls MinerU's /tasks API,
# which MinerU changed to /v1/tasks in 4.1 -> stay on the 3.x line).
LIGHTRAG_SPEC = "lightrag-hku[api]==1.5.7"
MINERU_SPEC = "mineru[core]==3.4.5"
PY_TAG = "cp311"


def vpy(venv: Path) -> str:
    return str(venv / "Scripts" / "python.exe")


def run(cmd: list[str], **kw) -> None:
    print("\n>>", " ".join(str(c) for c in cmd), flush=True)
    subprocess.run(cmd, check=True, **kw)


def read_runtime_env() -> dict[str, str]:
    path = ROOT / "config" / "runtime.env"
    out: dict[str, str] = {}
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.startswith("#"):
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip()
    return out


def make_venv(path: Path) -> None:
    if (path / "Scripts" / "python.exe").exists():
        print(f"venv exists: {path}")
        return
    run([sys.executable, "-m", "venv", str(path)])


def download(url: str, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    print(f"Downloading {url}\n  -> {dest}")
    tmp = dest.with_suffix(dest.suffix + ".part")
    with urllib.request.urlopen(url) as r, open(tmp, "wb") as f:
        total = int(r.headers.get("Content-Length") or 0)
        done = 0
        while True:
            chunk = r.read(1 << 20)
            if not chunk:
                break
            f.write(chunk)
            done += len(chunk)
            if total:
                print(f"\r  {done / 1e6:8.0f} / {total / 1e6:.0f} MB", end="", flush=True)
    print()
    tmp.replace(dest)


def unpack_ollama() -> None:
    exe = OLLAMA_DIR / "ollama.exe"
    if exe.exists():
        print(f"ollama already unpacked: {exe}")
        return
    if not OLLAMA_ZIP.exists():
        raise SystemExit(f"Missing {OLLAMA_ZIP}")
    OLLAMA_DIR.mkdir(parents=True, exist_ok=True)
    print(f"Unpacking {OLLAMA_ZIP.name} ...")
    with zipfile.ZipFile(OLLAMA_ZIP) as z:
        z.extractall(OLLAMA_DIR)
    if not exe.exists():
        found = list(OLLAMA_DIR.rglob("ollama.exe"))
        if not found:
            raise SystemExit("ollama.exe not found inside the zip")
        # zip had a top-level folder: flatten it
        src = found[0].parent
        for item in src.iterdir():
            shutil.move(str(item), str(OLLAMA_DIR / item.name))
    print("ollama ready:", exe)


def online() -> None:
    rt = read_runtime_env()
    torch_index = rt.get("TORCH_INDEX", "https://download.pytorch.org/whl/cu126")

    make_venv(VENV_LR)
    run([vpy(VENV_LR), "-m", "pip", "install", "--upgrade", "pip", "wheel", "setuptools"])
    run([vpy(VENV_LR), "-m", "pip", "install", LIGHTRAG_SPEC, "ollama>=0.5.4"])

    make_venv(VENV_MN)
    run([vpy(VENV_MN), "-m", "pip", "install", "--upgrade", "pip", "wheel", "setuptools"])
    # CUDA build of torch FIRST, so that mineru's "torch>=2.6" is already satisfied by it
    run([vpy(VENV_MN), "-m", "pip", "install", "torch", "torchvision", "--index-url", torch_index])
    run([vpy(VENV_MN), "-m", "pip", "install", MINERU_SPEC])

    if not OLLAMA_ZIP.exists():
        download(OLLAMA_URL, OLLAMA_ZIP)
    unpack_ollama()


def offline() -> None:
    lock_py = BUNDLE / "locks" / "python_tag.txt"
    if lock_py.exists():
        want = lock_py.read_text().strip()
        have = f"cp{sys.version_info.major}{sys.version_info.minor}"
        if want != have:
            raise SystemExit(f"Wheelhouse was built for {want} but this Python is {have}. "
                             f"Use the bundled Python installer (bundle/installers).")
    for venv, name in ((VENV_LR, "lightrag"), (VENV_MN, "mineru")):
        lock = BUNDLE / "locks" / f"{name}.lock.txt"
        wheels = BUNDLE / "wheelhouse" / name
        if not lock.exists() or not wheels.exists():
            raise SystemExit(f"Missing {lock} or {wheels} - was the bundle restored completely?")
        make_venv(venv)
        run([vpy(venv), "-m", "pip", "install", "--no-index", "--find-links", str(wheels),
             "-r", str(lock)])
    unpack_ollama()


def main() -> int:
    if len(sys.argv) != 2 or sys.argv[1] not in ("online", "offline"):
        print(__doc__)
        return 2
    os.chdir(ROOT)
    (online if sys.argv[1] == "online" else offline)()
    run([sys.executable, str(ROOT / "tools" / "gen_config.py")])
    print("\nSetup finished. Next: scripts\\02_fetch_models.bat (online PC) or "
          "scripts\\20_start_all.bat (offline PC, after the model files are restored).")
    return 0


if __name__ == "__main__":
    sys.exit(main())

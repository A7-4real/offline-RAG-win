#!/usr/bin/env python
"""Copy an installed package into custom/ so you can edit it.

    python tools/make_editable_copy.py lightrag   -> custom/lightrag_src/lightrag/
    python tools/make_editable_copy.py mineru     -> custom/mineru_src/mineru/

start_lightrag.bat / start_mineru.bat put custom/<pkg>_src first on PYTHONPATH when it exists,
so your edited copy wins over the installed one. Delete the folder to go back to stock code.
"""
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
MAP = {"lightrag": "venv_lightrag", "mineru": "venv_mineru"}

if len(sys.argv) != 2 or sys.argv[1] not in MAP:
    print(__doc__)
    sys.exit(2)
pkg = sys.argv[1]
src = ROOT / "runtime" / MAP[pkg] / "Lib" / "site-packages" / pkg
dst_root = ROOT / "custom" / f"{pkg}_src"
if not src.exists():
    sys.exit(f"Not installed: {src}")
if dst_root.exists():
    sys.exit(f"{dst_root} already exists - delete it first if you want a fresh copy")
shutil.copytree(src, dst_root / pkg, ignore=shutil.ignore_patterns("__pycache__"))
print(f"Copied to {dst_root / pkg}\nEdit files there, then restart the service.")
if pkg == "lightrag":
    print("Useful files: prompt.py (all prompts), prompt_multimodal.py (image/table/equation prompts),\n"
          "operate.py (extraction + query logic), pipeline.py, parser/ (parsers), chunker/ (chunking).")

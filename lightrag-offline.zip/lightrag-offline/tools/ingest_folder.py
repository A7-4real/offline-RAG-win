#!/usr/bin/env python
"""Copy documents into data/inputs and ask the running LightRAG server to index them.

    python tools/ingest_folder.py "D:\\docs" [more files or folders ...]  [--no-wait]

A per-file parser hint can be put in the file name, e.g.  manual.[mineru-iteP].docx
(see guide section on LIGHTRAG_PARSER).  Standard library only.
"""
import json
import shutil
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
INPUTS = ROOT / "data" / "inputs"
EXT = {".pdf", ".docx", ".pptx", ".xlsx", ".md", ".txt", ".png", ".jpg", ".jpeg", ".webp",
       ".bmp", ".gif", ".html", ".htm", ".csv", ".json", ".xml", ".rtf", ".odt", ".tex",
       ".py", ".c", ".h", ".cpp", ".hpp", ".java", ".js", ".ts", ".sql", ".yaml", ".yml"}


def kv(path):
    out = {}
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.lstrip().startswith("#"):
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip()
    return out


def call(url, key, method="GET"):
    req = urllib.request.Request(url, method=method, data=b"" if method == "POST" else None)
    if key:
        req.add_header("X-API-Key", key)
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode("utf-8", "replace") or "{}")


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not args:
        print(__doc__)
        return 2
    s = kv(ROOT / "config" / "user_settings.env")
    base = f"http://127.0.0.1:{s.get('LIGHTRAG_PORT', '9621')}"
    key = s.get("LIGHTRAG_API_KEY", "")
    INPUTS.mkdir(parents=True, exist_ok=True)
    n = 0
    for a in args:
        p = Path(a)
        files = [p] if p.is_file() else [f for f in p.rglob("*") if f.is_file()]
        for f in files:
            if f.suffix.lower() not in EXT:
                continue
            name = f.name
            dst = INPUTS / name
            if dst.exists() and dst.stat().st_size != f.stat().st_size:
                dst = INPUTS / f"{f.parent.name}__{name}"   # same name, different file
            if not dst.exists():
                shutil.copy2(f, dst)
                n += 1
    print(f"Copied {n} new file(s) into {INPUTS}")
    print("Scan:", json.dumps(call(f"{base}/documents/scan", key, "POST"))[:300])
    if "--no-wait" in sys.argv:
        return 0
    print("Waiting for the pipeline (Ctrl+C is safe, indexing continues in the server) ...")
    last = ""
    while True:
        time.sleep(5)
        st = call(f"{base}/documents/pipeline_status", key)
        msg = str(st.get("latest_message", ""))[:150]
        if msg != last:
            print(" ", msg)
            last = msg
        if not st.get("busy"):
            print("Pipeline idle. Check the Documents tab of the web UI for failures.")
            return 0


if __name__ == "__main__":
    sys.exit(main())

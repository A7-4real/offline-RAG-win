#!/usr/bin/env python
"""Self-check.

    python tools/doctor.py static    # files, environments, models present?  (nothing needs to be running)
    python tools/doctor.py live      # are the services up and answering?

Standard library only.
"""
from __future__ import annotations

import json
import subprocess
import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OK, BAD, WARN = "[ OK ]", "[FAIL]", "[WARN]"
failures = 0


def report(ok: bool, msg: str, warn_only: bool = False) -> None:
    global failures
    tag = OK if ok else (WARN if warn_only else BAD)
    if not ok and not warn_only:
        failures += 1
    print(f"{tag} {msg}")


def read_kv(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    if path.exists():
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip()
    return out


def ollama_manifest(model: str) -> Path:
    name, _, tag = model.partition(":")
    tag = tag or "latest"
    parts = name.split("/")
    if len(parts) == 1:
        parts = ["library", name]
    return ROOT / "models" / "ollama" / "manifests" / "registry.ollama.ai" / Path(*parts) / tag


def venv_run(venv: str, code: str) -> tuple[bool, str]:
    py = ROOT / "runtime" / venv / "Scripts" / "python.exe"
    if not py.exists():
        return False, "venv missing"
    try:
        r = subprocess.run([str(py), "-c", code], capture_output=True, text=True, timeout=180)
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)
    return r.returncode == 0, (r.stdout + r.stderr).strip().splitlines()[-1] if (r.stdout + r.stderr).strip() else ""


def static() -> None:
    s = read_kv(ROOT / "config" / "user_settings.env")
    print(f"Install folder: {ROOT}")
    if " " in str(ROOT):
        report(False, "install path contains spaces; move it to e.g. D:\\rag", warn_only=True)
    for rel, label in [
        ("runtime/ollama/ollama.exe", "Ollama runtime"),
        ("runtime/venv_lightrag/Scripts/lightrag-server.exe", "LightRAG server"),
        ("runtime/venv_mineru/Scripts/mineru-api.exe", "MinerU API"),
        ("data/lightrag_run/.env", "generated .env (run 30_apply_config.bat)"),
        ("config/mineru.json", "generated mineru.json"),
        ("prompts/entity_type/technical_docs.yml", "entity-type prompt profile"),
        ("prompts/user_prompt/answer_style.md", "answer-style prompt prefix"),
    ]:
        report((ROOT / rel).exists(), label)

    ok, msg = venv_run("venv_lightrag", "import lightrag, ollama; print('lightrag import ok')")
    report(ok, f"venv_lightrag imports: {msg}")
    ok, msg = venv_run("venv_mineru",
                       "import mineru, torch; print('torch', torch.__version__, 'cuda', torch.cuda.is_available())")
    report(ok, f"venv_mineru imports: {msg}")
    if ok and "cuda False" in msg:
        report(False, "PyTorch cannot see the GPU (CPU build or driver problem). MinerU will run on CPU only.",
               warn_only=True)

    for key in ("LLM_MODEL", "VLM_MODEL", "EMBED_MODEL"):
        model = s.get(key, "")
        report(bool(model) and ollama_manifest(model).exists(), f"Ollama model {key} = {model}")
    for sub in ("pipeline", "vlm"):
        d = ROOT / "models" / "mineru" / sub
        report(d.exists() and any(d.iterdir()), f"MinerU {sub} models in {d}", warn_only=(sub == "vlm"))
    t = ROOT / "models" / "tiktoken"
    report(t.exists() and any(t.iterdir()), "tiktoken cache (needed by LightRAG offline)")
    if s.get("RERANK", "off").lower() == "on":
        report((ROOT / "models" / "rerank" / "bge-reranker-v2-m3").exists(), "reranker model")
    print(f"\n{'ALL CHECKS PASSED' if failures == 0 else str(failures) + ' problem(s) found'}")


def get(url: str, timeout: int = 5) -> tuple[bool, str]:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            return True, r.read().decode("utf-8", "replace")
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)


def live() -> None:
    rt = read_kv(ROOT / "config" / "runtime.env")
    op, mp, rp, lp = (rt.get("OLLAMA_PORT", "11435"), rt.get("MINERU_PORT", "8000"),
                      rt.get("RERANK_PORT", "8001"), rt.get("LIGHTRAG_PORT", "9621"))
    ok, body = get(f"http://127.0.0.1:{op}/api/tags")
    report(ok, f"Ollama on :{op}")
    if ok:
        names = [m["name"] for m in json.loads(body).get("models", [])]
        print("       models:", ", ".join(names) or "(none)")
        ok2, ps = get(f"http://127.0.0.1:{op}/api/ps")
        if ok2:
            for m in json.loads(ps).get("models", []):
                size, vram = m.get("size", 0), m.get("size_vram", 0)
                pct = 100 * vram / size if size else 0
                print(f"       loaded: {m['name']}  {pct:.0f}% on GPU")
    ok, _ = get(f"http://127.0.0.1:{mp}/health")
    report(ok, f"MinerU on :{mp}")
    if rt.get("RERANK", "off").lower() == "on":
        ok, _ = get(f"http://127.0.0.1:{rp}/health")
        report(ok, f"Reranker on :{rp}")
    ok, body = get(f"http://127.0.0.1:{lp}/health")
    report(ok, f"LightRAG on :{lp}")
    print(f"\n{'ALL SERVICES UP' if failures == 0 else str(failures) + ' service(s) down'}")


if __name__ == "__main__":
    if len(sys.argv) != 2 or sys.argv[1] not in ("static", "live"):
        print(__doc__)
        sys.exit(2)
    (static if sys.argv[1] == "static" else live)()
    sys.exit(1 if failures else 0)

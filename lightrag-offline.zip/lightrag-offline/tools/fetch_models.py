#!/usr/bin/env python
"""OPTIONAL helper for the ONLINE PC: download all models into models/.
You can also do this by hand - see docs/MODELS.md.   python tools/fetch_models.py [--with-rerank]
"""
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tools"))
from doctor import read_kv  # noqa: E402

s = read_kv(ROOT / "config" / "user_settings.env")
rt = read_kv(ROOT / "config" / "runtime.env")
port = rt.get("OLLAMA_PORT", "11435")
env = dict(os.environ, OLLAMA_HOST=f"127.0.0.1:{port}", OLLAMA_MODELS=str(ROOT / "models" / "ollama"))
ollama = str(ROOT / "runtime" / "ollama" / "ollama.exe")
lr = ROOT / "runtime" / "venv_lightrag" / "Scripts"
mn = ROOT / "runtime" / "venv_mineru" / "Scripts"

# 1. Ollama models
srv = subprocess.Popen([ollama, "serve"], env=env)
for _ in range(60):
    try:
        urllib.request.urlopen(f"http://127.0.0.1:{port}/api/version", timeout=2)
        break
    except Exception:
        time.sleep(1)
try:
    for m in sorted({s["LLM_MODEL"], s["VLM_MODEL"], s["EMBED_MODEL"]}):
        subprocess.run([ollama, "pull", m], env=env, check=True)
finally:
    srv.terminate()

# 2. tokenizer cache
subprocess.run([str(lr / "lightrag-download-cache.exe"), "--cache-dir", str(ROOT / "models" / "tiktoken")], check=True)

# 3. MinerU models -> models/mineru/{pipeline,vlm}
cfg = ROOT / "config" / "mineru.download.json"
menv = {k: v for k, v in os.environ.items() if k != "MINERU_MODEL_SOURCE"}
menv["MINERU_TOOLS_CONFIG_JSON"] = str(cfg)
subprocess.run([str(mn / "mineru-models-download.exe"), "-s", "auto", "-m", "all"], env=menv, check=True)
dirs = json.loads(cfg.read_text(encoding="utf-8"))["models-dir"]
for kind in ("pipeline", "vlm"):
    dst = ROOT / "models" / "mineru" / kind
    if not dst.exists():
        shutil.copytree(dirs[kind], dst)

# 4. optional reranker
if "--with-rerank" in sys.argv:
    subprocess.run([str(mn / "python.exe"), "-c",
                    "from huggingface_hub import snapshot_download as d;"
                    f"d('BAAI/bge-reranker-v2-m3', local_dir r'{ROOT / 'models' / 'rerank' / 'bge-reranker-v2-m3'}')"
                    .replace("local_dir r", "local_dir=r")], check=True)
print("Models done. Run: python tools/doctor.py static")

# Models you download yourself (not in the package)

All paths are relative to the install folder (called ROOT, e.g. `D:\rag`).
Download on the ONLINE PC, copy to the same places on the offline PC.

| # | What | Needed for | Where it goes | Approx. size |
|---|------|-----------|---------------|--------------|
| 1 | Ollama `qwen3.5:9b` | answers, entity extraction, image/table analysis (vision) | `ROOT\models\ollama\` | 6.6 GB |
| 2 | Ollama `bge-m3` | embeddings (1024-dim, 8K context) | `ROOT\models\ollama\` | ~1.2 GB |
| 3 | MinerU **pipeline** models | OCR, layout, tables, formulas | `ROOT\models\mineru\pipeline\` | ~2-3 GB |
| 4 | MinerU **vlm** model (MinerU2.5) | hybrid mode only (optional) | `ROOT\models\mineru\vlm\` | ~2.5 GB |
| 5 | tiktoken cache | LightRAG tokenizer, server will NOT start offline without it | `ROOT\models\tiktoken\` | tiny |
| 6 | `BAAI/bge-reranker-v2-m3` (optional) | reranker, only if RERANK=on | `ROOT\models\rerank\bge-reranker-v2-m3\` | ~2.3 GB |
| alt | Ollama `qwen3.5:4b` | lighter LLM+VLM if 9B is too slow | `ROOT\models\ollama\` | ~3.4 GB |

Sizes are approximate except #1.

## Easiest: let the helper do 1-5 (online PC)
After `01_setup_online.bat`:  `scripts\02_fetch_models.bat`  (add `--with-rerank` for #6).

## Manual way
### 1-2. Ollama models  ->  ROOT\models\ollama\
The folder must end up containing `blobs\` and `manifests\`.
```
cd ROOT
set OLLAMA_HOST=127.0.0.1:11435
set OLLAMA_MODELS=ROOT\models\ollama
runtime\ollama\ollama.exe serve        (leave open, new window:)
runtime\ollama\ollama.exe pull qwen3.5:9b
runtime\ollama\ollama.exe pull bge-m3
```
Alternative: if you already pulled these with a normal Ollama, copy the `blobs` and `manifests`
folders from `C:\Users\<you>\.ollama\models\` into `ROOT\models\ollama\` (merging is fine).

### 3-4. MinerU models  ->  ROOT\models\mineru\pipeline  and  \vlm
```
runtime\venv_mineru\Scripts\mineru-models-download.exe -s huggingface -m all
```
(`-s modelscope` if Hugging Face is blocked). The command prints/writes the two folders it used
in `%USERPROFILE%\mineru.json` under `models-dir`. Copy the folder named under `pipeline` to
`ROOT\models\mineru\pipeline` and the one under `vlm` to `ROOT\models\mineru\vlm`
(copy the folder CONTENTS, so that e.g. `ROOT\models\mineru\pipeline\models\...` exists).
`scripts\30_apply_config.bat` writes `config\mineru.json` pointing there.

### 5. tiktoken cache  ->  ROOT\models\tiktoken
```
runtime\venv_lightrag\Scripts\lightrag-download-cache.exe --cache-dir ROOT\models\tiktoken
```

### 6. Reranker (optional)
```
runtime\venv_mineru\Scripts\python.exe -c "from huggingface_hub import snapshot_download as d; d('BAAI/bge-reranker-v2-m3', local_dir=r'ROOT\models\rerank\bge-reranker-v2-m3')"
```
Then set `RERANK=on` in `config\user_settings.env` and run `30_apply_config.bat`.

## Check
`python tools\doctor.py static` (or `scripts\60_doctor.bat`) lists every missing model.

## Changing models later
Edit `LLM_MODEL`, `VLM_MODEL` in `config\user_settings.env`. Do NOT change `EMBED_MODEL`/`EMBED_DIM`
after documents are indexed: delete `data\rag_storage` and re-index instead.

"""Builds docs/LocalAgent_Documentation.pdf (tables are generated from the live code, so they never drift)."""
import os
import sys
from xml.sax.saxutils import escape

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))

from reportlab.graphics.shapes import Drawing, Line, Polygon, Rect, String
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (KeepTogether, PageBreak, Paragraph, Preformatted, SimpleDocTemplate, Spacer, Table,
                                TableStyle)

from localagent import __version__
from localagent.config import Config, DEFAULT_PROFILES
from localagent.skills import SkillLibrary
from localagent.tools import build_registry

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "LocalAgent_Documentation.pdf")

NAVY, TEAL, GREY, LIGHT = colors.HexColor("#1b3a5c"), colors.HexColor("#1f7a8c"), colors.HexColor("#5a6572"), colors.HexColor("#eef2f6")
ss = getSampleStyleSheet()
BODY = ParagraphStyle("body", parent=ss["Normal"], fontName="Helvetica", fontSize=9.4, leading=13.2, spaceAfter=5)
SMALL = ParagraphStyle("small", parent=BODY, fontSize=8.2, leading=10.8, spaceAfter=0)
H1 = ParagraphStyle("h1", parent=ss["Heading1"], fontName="Helvetica-Bold", fontSize=16, leading=20, textColor=NAVY,
                    spaceBefore=6, spaceAfter=8, keepWithNext=1)
H2 = ParagraphStyle("h2", parent=ss["Heading2"], fontName="Helvetica-Bold", fontSize=11.5, leading=15, textColor=TEAL,
                    spaceBefore=9, spaceAfter=4, keepWithNext=1)
BUL = ParagraphStyle("bul", parent=BODY, leftIndent=12, bulletIndent=2, spaceAfter=2.5)
CODE = ParagraphStyle("code", fontName="Courier", fontSize=7.6, leading=9.6, textColor=colors.HexColor("#1d2733"))
TITLE = ParagraphStyle("title", parent=ss["Title"], fontName="Helvetica-Bold", fontSize=30, leading=36, textColor=NAVY,
                       alignment=TA_CENTER)
SUB = ParagraphStyle("sub", parent=BODY, fontSize=12, leading=17, alignment=TA_CENTER, textColor=GREY)


def P(t, s=BODY):
    return Paragraph(t, s)


def B(items):
    return [Paragraph(i, BUL, bulletText="-") for i in items]


def code(text):
    t = Table([[Preformatted(text.strip("\n"), CODE)]], colWidths=[170 * mm])
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), LIGHT), ("BOX", (0, 0), (-1, -1), 0.4, colors.HexColor("#c9d3dd")),
                           ("LEFTPADDING", (0, 0), (-1, -1), 6), ("TOPPADDING", (0, 0), (-1, -1), 5),
                           ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
    return [t, Spacer(1, 6)]


def table(rows, widths, header=True, small=True):
    st = SMALL if small else BODY
    data = []
    for i, r in enumerate(rows):
        data.append([Paragraph(("<b>%s</b>" % c) if (header and i == 0) else c, st) for c in r])
    t = Table(data, colWidths=[w * mm for w in widths], repeatRows=1 if header else 0)
    style = [("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#c9d3dd")), ("VALIGN", (0, 0), (-1, -1), "TOP"),
             ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
             ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]
    if header:
        style.append(("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#dbe6f0")))
    for i in range(2 if header else 1, len(rows), 2):
        style.append(("BACKGROUND", (0, i), (-1, i), colors.HexColor("#f7f9fb")))
    t.setStyle(TableStyle(style))
    return [t, Spacer(1, 7)]


def esc(s):
    return escape(str(s))


# ------------------------------------------------------------------ diagram
def box(d, x, y, w, h, lines, fill="#ffffff", stroke="#1b3a5c", size=7.2, bold=False):
    d.add(Rect(x, y, w, h, rx=3, ry=3, fillColor=colors.HexColor(fill), strokeColor=colors.HexColor(stroke), strokeWidth=0.8))
    n = len(lines)
    for i, ln in enumerate(lines):
        d.add(String(x + w / 2, y + h / 2 + (n - 1) * size * 0.55 - i * (size + 1.6) - size * 0.35, ln,
                     fontName="Helvetica-Bold" if (bold and i == 0) else "Helvetica", fontSize=size, textAnchor="middle",
                     fillColor=colors.HexColor("#1d2733")))


def arrow(d, x1, y1, x2, y2, dashed=False):
    ln = Line(x1, y1, x2, y2, strokeColor=colors.HexColor("#1b3a5c"), strokeWidth=0.9)
    if dashed:
        ln.strokeDashArray = [2, 2]
    d.add(ln)
    import math
    a = math.atan2(y2 - y1, x2 - x1)
    s = 4
    d.add(Polygon([x2, y2, x2 - s * math.cos(a - 0.45), y2 - s * math.sin(a - 0.45),
                   x2 - s * math.cos(a + 0.45), y2 - s * math.sin(a + 0.45)],
                  fillColor=colors.HexColor("#1b3a5c"), strokeColor=colors.HexColor("#1b3a5c"), strokeWidth=0.3))


def architecture():
    d = Drawing(500, 305)
    d.add(Rect(10, 62, 340, 128, rx=5, ry=5, fillColor=colors.HexColor("#f2f7fb"), strokeColor=colors.HexColor("#8aa6c1"),
               strokeDashArray=[3, 2]))
    d.add(String(18, 178, "EXECUTOR LOOP (one plan step)", fontName="Helvetica-Bold", fontSize=7.2, fillColor=NAVY))
    box(d, 110, 272, 140, 26, ["Task prompt"], "#dbe6f0", bold=True)
    box(d, 110, 232, 140, 28, ["Router", "picks 1-2 skills"], "#e6f3f1")
    box(d, 110, 194, 140, 28, ["Planner", "2-8 steps + checks"], "#e6f3f1")
    box(d, 20, 128, 100, 38, ["Context assembler", "slots, token budget"])
    box(d, 130, 128, 100, 38, ["LLM -> JSON action", "schema-constrained"], "#fff4d6")
    box(d, 240, 128, 100, 38, ["Tool registry", "sandbox + policy"])
    box(d, 240, 72, 100, 38, ["Observation", "compress / spill"])
    box(d, 130, 72, 100, 38, ["Verifier", "code check, judge"])
    box(d, 20, 72, 100, 38, ["Loop guards", "budgets, repeats"])
    box(d, 40, 8, 130, 38, ["Reflector", "lesson, retry / replan"], "#fde8e4")
    box(d, 200, 8, 140, 38, ["Final report", "episode saved"], "#e3f1e3")
    box(d, 375, 215, 115, 44, ["Skill library", "SKILL.md, scripts,", "references"], "#ece8f6")
    box(d, 375, 148, 115, 50, ["Memory (SQLite)", "lessons, knowledge,", "episodes (FTS5)"], "#ece8f6")
    box(d, 375, 82, 115, 44, ["Artifact store", "big outputs on disk"], "#ece8f6")
    box(d, 375, 18, 115, 44, ["Run state + trace", "state.json, JSONL"], "#ece8f6")
    arrow(d, 180, 272, 180, 260)
    arrow(d, 180, 232, 180, 222)
    arrow(d, 180, 194, 180, 190)
    arrow(d, 120, 147, 130, 147)
    arrow(d, 230, 147, 240, 147)
    arrow(d, 290, 128, 290, 110)
    arrow(d, 240, 91, 230, 91)
    arrow(d, 130, 91, 120, 91)
    arrow(d, 70, 110, 70, 128)
    arrow(d, 100, 62, 100, 46)
    arrow(d, 270, 62, 270, 46)
    for y in (237, 173, 104, 40):
        arrow(d, 375, y, 350, min(max(y, 70), 185), dashed=True)
    return d


# ------------------------------------------------------------------ page decor
def decor(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 7.5)
    canvas.setFillColor(GREY)
    if doc.page > 1:
        canvas.drawString(20 * mm, 287 * mm, "localagent %s - offline autonomous agent for small local LLMs" % __version__)
        canvas.drawRightString(190 * mm, 12 * mm, "Page %d" % doc.page)
        canvas.setStrokeColor(colors.HexColor("#c9d3dd"))
        canvas.line(20 * mm, 285 * mm, 190 * mm, 285 * mm)
    canvas.restoreState()


def build():
    reg = build_registry()
    lib = SkillLibrary(os.path.join(ROOT, "skills"))
    cfg = Config()
    S = []

    # ---------------------------------------------------------------- cover
    S += [Spacer(1, 70 * mm), P("localagent", TITLE), Spacer(1, 4),
          P("An offline, skill-driven autonomous agent<br/>for small local language models", SUB), Spacer(1, 14),
          P("Technical documentation &amp; user guide - version %s" % __version__, SUB), Spacer(1, 40 * mm),
          P("Target model: Gemma 9B 4-bit (profile <b>gemma-9b</b>) or Llama 8B 4-bit<br/>"
            "Inference: LM Studio or llama.cpp server - or any OpenAI-compatible endpoint<br/>"
            "Runtime: Python 3.9+, standard library only for the core, no internet", SUB), PageBreak()]

    # ---------------------------------------------------------------- 1 overview
    S += [P("1. Overview and design philosophy", H1),
          P("localagent turns one natural-language task into finished work using only a small local model. A 9B model with 4-bit "
            "quantisation is weak at long free-form reasoning, unreliable at tool calling, and loses focus quickly as the prompt "
            "grows. The design therefore assumes the model is <b>unreliable but useful in small doses</b>, and moves everything "
            "that does not need intelligence into deterministic Python."),
          P("The central rule: <b>the model never makes a hard decision.</b> It makes one small, schema-constrained decision per "
            "call. Routing, planning, state, memory, retries, safety and verification are code."),
          P("What the agent can do out of the box", H2)]
    S += table([["Capability", "Provided by"],
                ["Understand a task, choose skills, plan, execute, verify, recover", "Agent loop: router, planner, executor, verifier, reflector"],
                ["Read/write/edit/search files, copy/move/delete with approval", "file_ops skill + file tools"],
                ["Write, check, run, test and debug Python; inspect real library APIs", "python_dev skill + py_introspect"],
                ["Parse PDF, Word, PowerPoint, Excel, CSV, HTML, JSON, ZIP", "doc_parsing skill + parse_document"],
                ["Windows cmd/PowerShell and Linux bash with offline cheat-sheets", "shell_cmd skill + run_shell, search_docs"],
                ["Ping, traceroute, DNS, ports, interfaces, ARP, routes", "networking skill + net_diag, port_check"],
                ["Offline websites and small web apps (static, wsgi, Flask)", "web_dev skill + scaffold/validate/serve scripts"],
                ["Architecture documents with Mermaid diagrams", "system_architect skill + render_architecture.py"],
                ["Ada programs with GNAT compile-and-fix loop", "ada_dev skill + compile.py + Ada cheat-sheet"],
                ["LangGraph / LangChain development against installed versions", "langgraph_dev skill + check_env.py + py_introspect"],
                ["Remember lessons and offline documentation across runs", "SQLite memory (FTS5 / BM25)"]], [95, 75])

    # ---------------------------------------------------------------- 2 architecture
    S += [P("2. Architecture", H1),
          P("A run has four phases: <b>route</b> (choose skills), <b>plan</b> (split into steps with machine-checkable success "
            "criteria), <b>execute</b> (a tight act-observe-verify loop per step) and <b>recover</b> (reflect, learn a lesson, "
            "retry or replan). Every LLM call is stateless: a fresh prompt is assembled from named slots, so nothing accumulates "
            "and the prompt size is always bounded."),
          architecture(), Spacer(1, 4)]
    S += [P("Roles", H2)]
    S += table([["Role", "Task", "Output (JSON schema)", "Max tokens"],
                ["router", "Pick the best 1-2 skills from a keyword-prefiltered shortlist", "{skills: [enum]}", "120"],
                ["planner", "Split task into at most %d steps; each has goal, tool_hint, check" % cfg.max_plan_steps,
                 "{steps: [{goal, tool_hint(enum), check{kind(enum), arg}}]}", "900"],
                ["actor", "Choose ONE tool call for the current step, or finish_step",
                 "anyOf one object per allowed tool: {thought, tool(const), args}", "700 (profile)"],
                ["judge", "Only when no code check applies and the evidence looks suspicious", "{verdict: pass|fail|unsure, reason}", "150"],
                ["reflector", "Diagnose a failed step, store a lesson, choose retry/replan/skip/abort", "{error_class, lesson{trigger,advice}, next}", "300"],
                ["reporter", "Write the final report from recorded facts only", "plain text", "350"]], [20, 62, 68, 20])
    S += [P("Anatomy of one executor iteration", H2)]
    S += B(["<b>Assemble</b> the prompt from slots (task, plan, current step, facts, skill rules, lessons, tool cards, recent actions) under the token budget.",
            "<b>Ask</b> the model for a JSON action. The schema only allows tools that are valid for this step, so a made-up tool is impossible when the server enforces schemas; otherwise validation + repair catches it.",
            "<b>Execute</b> through the registry: arguments are coerced (\"5\" to 5), validated, and errors are returned as actionable text with the correct usage line. Tools never crash the loop.",
            "<b>Observe</b>: short results go inline; long results are saved as an artifact (A1, A2...) and the model sees head + tail + a handle it can read or grep.",
            "<b>Verify</b> when the model calls finish_step: run the step's code check; judge with the LLM only as a fallback.",
            "<b>Guard</b>: per-step and global action budgets, repeated-call detection, invalid-output strikes."])

    # ---------------------------------------------------------------- 3 reliability
    S += [P("3. Reliability techniques for a weak model", H1)]
    S += table([["Weakness of a small model", "Countermeasure", "Where"],
                ["Malformed JSON / invented tool names", "Schema-constrained decoding (json_schema / json_object / llama.cpp schema), anyOf per allowed tool, tolerant extraction, coercion, 2 repair retries with the exact error fed back", "llm/client.py, schema.py, jsonutil.py"],
                ["Gets lost in long prompts", "Stateless calls, hard token budget, priority slots, 2 full + older one-line observations", "context.py, agent.py"],
                ["Too many tools confuse it", "At most 12 tools per step: finish_step, the planner's hint, skill tools, core tools", "agent._allowed_tools"],
                ["Bad at big plans", "Plans of 2-8 steps with code-checkable success criteria; replan only the remaining work", "agent._plan"],
                ["Claims success falsely", "Code-first verification (file exists, text present, compiles, tests pass, last tool ok); judge fallback", "verify.py"],
                ["Repeats the same failing action", "Identical-call detection (note on 2nd, fail on 3rd), step budget, reflector with lesson", "agent._run_step"],
                ["Forgets between runs", "Lessons + offline knowledge in SQLite FTS5, injected only when relevant", "memory.py"],
                ["Hallucinates flags / APIs", "Offline cheat-sheets via search_docs; py_introspect shows the real installed API", "skills/*/reference, tools/shell.py"],
                ["Poor arithmetic", "calc tool (safe AST evaluator)", "tools/meta.py"],
                ["Rewrites whole files and breaks them", "edit_file exact search/replace, syntax warning after every .py write", "tools/files.py"],
                ["Huge tool outputs flood context", "Artifact spill + read_artifact / grep_artifact", "artifacts.py"]], [42, 96, 32])

    # ---------------------------------------------------------------- 4 context + memory
    S += [P("4. Context and memory management", H1), P("4.1 The context assembler", H2),
          P("Every prompt is built from <i>slots</i>. Each slot has a priority, an optional cap and a minimum. If the total exceeds "
            "the profile's budget (<b>%d tokens</b> for gemma-9b, leaving room inside an 8192 window for the %d-token reply), the "
            "lowest-priority slot is shrunk first, then dropped. The task, current step and instruction are never sacrificed. "
            "Token counts are estimated from characters (3.3 chars/token for Gemma, configurable), deliberately conservative."
            % (DEFAULT_PROFILES["gemma-9b"]["budget_tokens"], DEFAULT_PROFILES["gemma-9b"]["max_output_tokens"]))]
    S += table([["Actor slot", "Priority", "Cap (tokens)", "Trim"],
                ["INSTRUCTION", "10", "100", "-"], ["CURRENT STEP (goal, success check, earlier problems)", "10", "300", "tail"],
                ["TASK", "9", "450", "tail"], ["TOOLS (compact signature cards)", "8", "1100", "tail"],
                ["RECENT ACTIONS (last 2 full, older as one line)", "8", "2200", "keep newest"],
                ["FACTS (pinned with remember_fact)", "7", "300", "keep newest"], ["PLAN (with step results)", "6", "350", "middle"],
                ["SKILL RULES", "4", "600", "tail"], ["LESSONS (BM25 top 2)", "3", "250", "tail"], ["ENVIRONMENT", "3", "120", "tail"]],
               [86, 20, 28, 36])
    S += [P("4.2 Persistent memory (one SQLite file)", H2)]
    S += table([["Layer", "Content", "Written by", "Read by"],
                ["Working state", "Task, plan, step status/results, pinned facts, touched files, counters", "Agent loop, remember_fact", "Every prompt (compact views); saved to state.json after each action, so runs can be resumed"],
                ["Artifact store", "Full text of any tool output above %d chars" % cfg.tool_output_chars, "Observation compressor", "read_artifact, grep_artifact"],
                ["Lessons", "trigger / advice pairs learned from failures (deduplicated, use counter)", "Reflector, save_lesson", "Planner and actor prompts via BM25 on task + step + last error"],
                ["Knowledge", "Chunked offline docs: skill reference/, knowledge/ folder (pdf, docx, md, code...)", "Auto-index at start (hash-checked), <font face='Courier'>ingest</font> command", "search_docs"],
                ["Episodes", "One row per finished run: task, outcome, summary", "Agent loop", "Available for inspection / future use"]], [24, 54, 40, 52])
    S += [P("Retrieval is BM25 over SQLite FTS5, which needs no embedding model and is fast and predictable on a CPU-only offline machine. "
            "If FTS5 is missing, memory falls back to keyword counting. An embedding retriever can be added behind the same "
            "<font face='Courier'>search_knowledge</font> interface (see Section 10).")]

    # ---------------------------------------------------------------- 5 models
    S += [P("5. Model and inference abstraction", H1),
          P("Everything above <font face='Courier'>llm/</font> talks to an <font face='Courier'>LLMClient</font>; the client talks to a "
            "<font face='Courier'>LLMBackend</font>. Changing the model or the server is a configuration change.")]
    S += table([["Backend", "Use for", "Notes"],
                ["openai_compat", "LM Studio, llama.cpp llama-server, Ollama (/v1), vLLM", "HTTP via urllib (no dependencies). Negotiates structured-output mode automatically and remembers it."],
                ["llama_cpp_python", "In-process GGUF inference without a server", "Optional dependency; uses json_object + schema grammar."],
                ["ScriptedBackend", "Tests and demos", "Replays canned JSON per role; no model needed."]], [30, 58, 82])
    S += [P("Structured-output negotiation", H2),
          P("With <font face='Courier'>schema_mode: auto</font> the backend tries, in order: (1) OpenAI-style "
            "<font face='Courier'>response_format: json_schema</font> (LM Studio); (2) <font face='Courier'>json_object</font> with a "
            "<font face='Courier'>schema</font> field (llama.cpp); (3) llama.cpp's top-level <font face='Courier'>json_schema</font> "
            "parameter; (4) none (prompt only). A server error (HTTP 400/404/415/422/500/501) moves on to the next mode; the first "
            "mode that works is cached. Whatever the mode, the client validates every reply, coerces small slips and repairs."),
          P("Profiles", H2)]
    prow = [["Profile", "Window", "Prompt budget", "Max reply", "System role", "chars/token"]]
    for k, v in DEFAULT_PROFILES.items():
        prow.append([k, v["context_window"], v["budget_tokens"], v["max_output_tokens"], v["system_role"], v["chars_per_token"]])
    S += table([[str(c) for c in r] for r in prow], [30, 20, 30, 24, 28, 28])
    S += [P("<b>Gemma and the system role.</b> Gemma chat templates have no system turn, and some llama.cpp builds reject one. The "
            "<font face='Courier'>merge</font> setting folds the system text into the single user message. Because every call is one "
            "stateless user turn, role-alternation rules can never be violated.")]
    S += code("""
{ "backend": "openai_compat",
  "base_url": "http://127.0.0.1:1234/v1",     // llama-server: http://127.0.0.1:8080/v1
  "model": "gemma-2-9b-it",
  "profile": "gemma-9b",                       // or llama-8b, generic-small, or your own
  "profiles": { "my-llama": { "context_window": 8192, "budget_tokens": 6000,
                              "max_output_tokens": 700, "system_role": "native" } } }
""")

    # ---------------------------------------------------------------- 6 tools
    S += [P("6. Tool reference", H1),
          P("Tiers drive the permission model: <b>read</b> (no side effects), <b>write</b> (changes workspace files), <b>exec</b> (runs "
            "programs), <b>net</b> (network probes), <b>meta</b> (agent-internal). Table generated from the live registry.")]
    rows = [["Tool", "Tier", "Description"]]
    for n in reg.names():
        t = reg.get(n)
        rows.append(["<font face='Courier'>%s</font>" % n, t.tier, esc(t.desc)])
    S += table(rows, [34, 14, 122])

    # ---------------------------------------------------------------- 7 skills
    S += [P("7. Skills", H1),
          P("A skill is a folder. The router sees only its one-line description; the full rules are injected after selection "
            "(progressive disclosure keeps prompts small).")]
    S += code("""
skills/ada_dev/
  SKILL.md              frontmatter + ## Rules / ## Workflow / ## Notes
  scripts/compile.py    run with run_skill_script(skill, script, args)
  reference/ada_cheatsheet.md   indexed automatically for search_docs
""")
    S += code("""
---
name: ada_dev
description: Write, compile and fix Ada (GNAT) programs       # shown to the router
tools: [write_file, edit_file, read_file, run_skill_script, run_shell, search_docs]
keywords: [ada, gnat, adb, ads]                                # used for pre-filtering
max_steps: 8
plan_mode: guided          # guided = LLM plans using the workflow; fixed = workflow IS the plan
---
## Rules        (injected into every executor prompt)
## Workflow     (numbered; fixed mode reads "(tool: x)" and "(check: kind: arg)" tags)
""")
    S += [P("Bundled skills", H2)]
    rows = [["Skill", "Purpose", "Tools", "Scripts"]]
    for sk in lib.skills.values():
        rows.append(["<b>%s</b>" % sk.name, esc(sk.description), "<font face='Courier'>%s</font>" % esc(", ".join(sk.tools)),
                     esc(", ".join(sk.scripts()) or "-")])
    S += table(rows, [28, 50, 60, 32])
    S += [P("<b>fixed plan mode</b> makes a skill fully deterministic: no planner call, the model only fills the arguments of each "
            "step. Use it for repeatable workflows where the weak model's planning would be the main risk.")]

    # ---------------------------------------------------------------- 8 safety
    S += [P("8. Safety and autonomy", H1)]
    S += table([["Control", "Behaviour"],
                ["Workspace jail", "All writes must resolve inside the workspace folder (symlink-safe via resolve()). Reads are limited to the workspace plus skills, knowledge and data folders; autonomy=full also allows reads elsewhere."],
                ["Autonomy: readonly", "write and exec tools are removed from the model's choices entirely."],
                ["Autonomy: ask_risky (default)", "Known read-only commands run freely. Anything else (writes via shell, chained commands, unknown programs, deletes, Python that touches processes/network/deletion) asks the human. Non-interactive runs deny."],
                ["Autonomy: full (--yes)", "No prompts. The denylist still applies."],
                ["Always-denied patterns", "rm -rf on roots, mkfs, dd if=, format X:, diskpart, shutdown/reboot, reg delete, bcdedit, takeown, net user, cipher /w, fork bombs, recursive delete of drive roots."],
                ["Network", "local_http_get only reaches loopback/private addresses; the agent has no general internet tool."],
                ["Limits", "Timeouts on every command; output caps; global action budget (%d), per-step budget (%d), max replans (%d)." % (cfg.max_total_actions, cfg.max_actions_per_step, cfg.max_replans)],
                ["Audit", "Every prompt and reply is written to agent_data/runs/&lt;id&gt;/trace.jsonl; state.json after each action."]], [42, 128])
    S += [P("The shell policy is a safety net, not a security boundary: a determined model (or user) can still do harm with an approved "
            "command. Run the agent under an account that cannot damage anything you care about, especially with --yes.")]

    # ---------------------------------------------------------------- 9 install
    S += [P("9. Installation and usage (offline)", H1), P("9.1 Install", H2)]
    S += B(["Copy the <font face='Courier'>localagent_project</font> folder to the target machine. The core needs only Python 3.9+; no admin rights, no pip install.",
            "Optional libraries (PDF reading, pytest, pyflakes): on a connected machine run <font face='Courier'>pip download -r requirements.txt -d wheelhouse</font>, copy the wheelhouse over, then <font face='Courier'>python -m venv .venv</font> and <font face='Courier'>pip install --no-index --find-links wheelhouse -r requirements.txt</font>. Prefer pure-Python wheels.",
            "External programs are optional and detected at start-up: GNAT (Ada), Git, Node, Tesseract, LibreOffice, pdftotext."])
    S += [P("9.2 Start the inference server", H2)]
    S += B(["<b>LM Studio</b>: load the Gemma model, open the Developer tab, start the local server (default port 1234). Set the context length to 8192 or higher.",
            "<b>llama.cpp</b>: <font face='Courier'>llama-server -m gemma-2-9b-it-Q4_K_M.gguf -c 8192 -ngl 99 --port 8080</font>, then set base_url to <font face='Courier'>http://127.0.0.1:8080/v1</font>."])
    S += [P("9.3 Run", H2)]
    S += code("""
python run_agent.py init                       # writes config.json
python run_agent.py doctor                     # environment + server check
python run_agent.py run "Parse spec.docx and write all tables to tables.md"
python run_agent.py run --yes "Ping 192.168.1.1 and summarise connectivity"
python run_agent.py run --resume 20261115-101500-ab12      # continue an interrupted run
python run_agent.py ingest D:\\docs\\ada_rm                 # index offline manuals
python run_agent.py skills | tools | selftest
""")
    S += [P("9.4 Configuration reference", H2)]
    desc = {"backend": "openai_compat | llama_cpp_python", "base_url": "inference server /v1 URL", "model": "model name sent to the server",
            "profile": "model profile (budgets, system role)", "schema_mode": "auto | json_schema | json_object | llama_schema | none",
            "workspace": "only place the agent may write", "data_dir": "memory.db, runs, artifacts, traces",
            "skills_dir": "skills folder", "knowledge_dir": "offline docs to index", "autonomy": "readonly | ask_risky | full",
            "max_plan_steps": "steps per plan", "max_actions_per_step": "tool calls allowed per step",
            "max_replans": "replans before giving up", "max_step_retries": "retries of the same step",
            "max_total_actions": "tool calls per run", "max_tools_per_step": "tools shown to the model",
            "shell_timeout": "seconds per shell command", "python_timeout": "seconds per Python run",
            "tool_output_chars": "inline limit before spilling to an artifact", "recent_full_observations": "recent results kept in full",
            "trace": "write trace.jsonl", "request_timeout": "seconds to wait for the model"}
    rows = [["Key", "Default", "Meaning"]]
    for k, m in desc.items():
        rows.append(["<font face='Courier'>%s</font>" % k, esc(getattr(cfg, k)), m])
    S += table(rows, [48, 38, 84])

    # ---------------------------------------------------------------- 10 extending
    S += [P("10. Extending the agent", H1)]
    S += [P("Add a tool", H2)]
    S += code('''
# localagent/tools/mytools.py
from .base import Param, Tool, ToolError
def word_count(ctx, path):                       # ctx has sandbox, state, memory, artifacts, cfg
    p = ctx.sandbox.resolve(path)                # always resolve paths through the sandbox
    return "%d words" % len(p.read_text(encoding="utf-8").split())
def register(reg):
    reg.register(Tool("word_count", "Count words in a text file.", [Param("path")], word_count, "read"))
# then call mytools.register(reg) in tools/__init__.py (build_registry)
# and add the tool name to the tools: line of a SKILL.md
''')
    S += B(["<b>Add a skill</b>: create the folder (Section 7). No code needed; restart or run <font face='Courier'>skills</font> to check it loads.",
            "<b>Add knowledge</b>: drop files into knowledge/ (Ada Reference Manual, your LangGraph docs snapshot, project specs). They are chunked and searchable on the next run.",
            "<b>Add a model profile</b>: add an entry under <font face='Courier'>profiles</font> in config.json.",
            "<b>Add a backend</b>: subclass LLMBackend (implement chat and health) and add it to llm/__init__.create_backend.",
            "<b>Embeddings</b>: implement a retriever with the same signature as Memory.search_knowledge (for example ONNX bge-small + numpy cosine) and combine its ranking with BM25.",
            "<b>Parallel sub-agents</b>: not included; steps run sequentially because a single local GPU serves one request at a time."])

    # ---------------------------------------------------------------- 11 tuning
    S += [P("11. Tuning for a weak model", H1),
          P("After the first real run, open <font face='Courier'>agent_data/runs/&lt;id&gt;/trace.jsonl</font>: it holds every prompt and reply. "
            "The statistics line printed after each run (LLM calls, repairs) is the quickest health indicator.")]
    S += table([["Symptom", "Likely cause", "Fix"],
                ["Many repairs for actor calls", "Server ignores schema, or prompt too long", "Run doctor; set schema_mode explicitly; lower budget_tokens; reduce max_tools_per_step"],
                ["Plans with too many or vague steps", "Task too broad, or skill guidance too long", "Lower max_plan_steps; use plan_mode: fixed for the skill; shorten Rules"],
                ["Model ignores tool results", "Observations too long", "Lower tool_output_chars; keep recent_full_observations at 1-2"],
                ["Wrong tool chosen", "Too many tools or unclear descriptions", "Narrow the skill's tools list; sharpen tool descriptions and examples"],
                ["Slow runs", "Large prompts each call (no cache reuse)", "Shorten rules, lower budget; enable prompt caching in the server if available"],
                ["Fails on a recurring situation", "Missing knowledge", "Add a reference doc to the skill or knowledge/; or add a fixed-plan skill"],
                ["Loops", "Verification impossible or ambiguous", "Give the planner a code check (file_exists, output_contains); make the goal concrete"]], [46, 52, 72])

    # ---------------------------------------------------------------- 12 status
    S += [P("12. Test status and known limits", H1),
          P("<b>Verified in this build (33 automated tests, all passing, no model required):</b>")]
    S += B(["JSON extraction, schema validation and coercion; context budgeting; memory (FTS5 lessons and knowledge, hash-based re-indexing); artifact store; skill loading and routing.",
            "All file, shell, Python, calculator, document-parser (docx/pptx/xlsx built from raw XML), network-safety and skill-script tools, including sandbox escape and dangerous-command blocking.",
            "The HTTP backend against a fake server: structured-output fallback and caching, repair loop, unreachable-server error, Gemma system-role merge.",
            "The full agent loop with a scripted model: happy path, false-success caught by verification, loop detection + reflection + replan with lesson storage, invalid model output, blocked destructive command, fixed-plan skills, artifact spill and search, resume.",
            "The complete CLI over real HTTP against a fake OpenAI-compatible server."])
    S += [P("<b>Not yet verified (needs your machine):</b>")]
    S += B(["Behaviour with a real Gemma 9B / Llama 8B model. The prompts are short and schema-constrained by design, but the first real runs will show where wording needs adjustment; use trace.jsonl and Section 11.",
            "GNAT, PDF libraries and LM Studio / llama.cpp structured-output support in your exact builds (run <font face='Courier'>doctor</font>).",
            "Windows-specific paths of the shell and network tools were written for cmd.exe but tested here on Linux."])
    S += [P("<b>Known limits:</b>")]
    S += B(["A 9B 4-bit model will still fail on genuinely hard reasoning or large codebases; the scaffolding raises the floor, not the ceiling.",
            "Legacy .doc/.ppt/.xls need conversion first; scanned PDFs need OCR (Tesseract is detected but no OCR tool is wired in yet).",
            "No embedding retrieval or multi-agent parallelism in this version.",
            "The shell policy is heuristic (Section 8)."])
    S += [P("Appendix A - what a run looks like", H1)]
    S += code("""
Run 20261115-101500-ab12 | model profile gemma-9b | skills dir: 9 skills
Skills: doc_parsing
Plan: 1. Find spec.docx | 2. Parse and extract the tables | 3. Write tables.md
Step 1/3: Find spec.docx
   + find_files(pattern='spec.docx') -> spec.docx
  step 1 done: spec.docx is in the workspace root
Step 2/3: Parse and extract the tables
   + parse_document(path='spec.docx') -> OK: # Section 1 ... [full output saved as A1, 212 lines]
   + grep_artifact(id='A1', pattern='^\\|') -> 41| | Field | Byte | Lane 1 | ...
  step 2 done: 3 tables found (lines 41-58, 77-90, 120-171)
Step 3/3: Write tables.md
   + write_file(path='tables.md', content='...') -> Wrote tables.md (2290 chars, mode=create).
  step 3 done: tables.md written
=== DONE ===
Extracted 3 tables from spec.docx into tables.md ...
(run id: 20261115-101500-ab12 | LLM calls: 11, repairs: 0, 5 actions)
""")
    return S


def main():
    doc = SimpleDocTemplate(OUT, pagesize=A4, leftMargin=20 * mm, rightMargin=20 * mm, topMargin=20 * mm, bottomMargin=20 * mm,
                            title="localagent - Documentation", author="localagent")
    doc.build(build(), onFirstPage=decor, onLaterPages=decor)
    print("wrote", OUT)


if __name__ == "__main__":
    main()

# localagent - offline autonomous agent for small local LLMs

Runs a planner/executor/verifier loop on a weak model (Gemma 9B 4-bit, Llama 8B 4-bit...) served by
**LM Studio** or **llama.cpp (llama-server)**, with skills, tools, persistent memory and strict context management.
Pure Python, standard library only for the core. No internet needed at runtime.

## Quick start
1. Start your inference server (LM Studio: Developer -> Start Server, default `http://127.0.0.1:1234/v1`;
   llama.cpp: `llama-server -m gemma-2-9b-it-Q4_K_M.gguf -c 8192 --port 8080`).
2. `python run_agent.py init` -> edit `config.json` (`base_url`, `model`, `profile`).
3. `python run_agent.py doctor`   - checks Python, optional libs, skills, and the server connection.
4. `python run_agent.py run "Parse spec.docx in the workspace and write the tables to tables.md"`
   (add `--yes` for full autonomy, otherwise risky actions ask for approval).

Other commands: `skills`, `tools`, `ingest <path>`, `run --resume <run_id>`, `selftest` (no model needed).

## Swapping the model / server
Edit `config.json` only: `backend`, `base_url`, `model`, `profile`. A profile (see `config.py`) holds context size,
prompt budget, output limit, system-role handling. Add your own under `"profiles"`. No code changes.

## Layout
    localagent/          engine (agent loop, llm/, tools/, memory, context, skills loader, verify)
    skills/<name>/       SKILL.md (+ scripts/, reference/)   <- add your own skills here
    knowledge/           offline docs to index for search_docs
    workspace/           the only place the agent may write
    agent_data/          memory.db, run states, traces, artifacts
    tests/               33 tests, run with: python run_agent.py selftest

## Add a skill
Create `skills/my_skill/SKILL.md` with frontmatter (name, description, tools, keywords) and `## Rules` / `## Workflow`
sections; optional `scripts/*.py` and `reference/*.md`. It is discovered automatically. See docs for the format.

Full documentation: `docs/LocalAgent_Documentation.pdf`.

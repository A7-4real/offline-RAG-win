Drop offline reference material here (manuals, API docs, cheat-sheets: .md .txt .pdf .docx .pptx .xlsx .html .py .ads .adb ...).
It is chunked and indexed (SQLite FTS5) automatically on the next run, and the agent finds it with the search_docs tool.
Changed files are re-indexed; unchanged files are skipped.  Manual indexing:  python run_agent.py ingest knowledge
Suggested content: Ada Reference Manual, LangGraph/LangChain docs snapshot (version matching your install), your own project specs.

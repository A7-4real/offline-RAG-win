# Web development notes (offline)

## HTML skeleton
`<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>..</title></head><body>..</body></html>`

## CSS layout
- Centered column: `main { max-width: 56rem; margin: 0 auto; padding: 1rem; }`
- Flex row: `.row { display: flex; gap: 1rem; flex-wrap: wrap; }`
- Grid cards: `.grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(14rem, 1fr)); gap: 1rem; }`
- Dark mode: `@media (prefers-color-scheme: dark) { body { background: #111; color: #eee; } }`

## JavaScript
- Select: `document.querySelector('#id')`. Events: `el.addEventListener('click', fn)`.
- Fetch JSON from own server: `fetch('/api/hello').then(r => r.json()).then(d => console.log(d))`.
- Form without reload: `form.addEventListener('submit', e => { e.preventDefault(); ... })`.
- Local persistence: `localStorage.setItem('k', JSON.stringify(v))`.

## Python servers
- Static only: `python -m http.server 8000`.
- stdlib JSON API: wsgiref (see scaffold wsgi). Flask: `@app.route('/x', methods=['POST'])`, `request.get_json()`, `jsonify(...)`.
- Always bind to 127.0.0.1 for local testing.

## Common bugs
- Blank page: JS error -> check script tag path and the browser console; the file name is case-sensitive on Linux.
- CSS not applied: wrong `href`, or file saved in another folder.
- Flask 404 for static files: files must be inside the `static` folder.

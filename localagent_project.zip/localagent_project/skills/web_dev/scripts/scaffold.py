"""Create a web project skeleton.  usage: scaffold.py <static|wsgi|flask> <folder>"""
import sys
from pathlib import Path

kind = sys.argv[1] if len(sys.argv) > 1 else "static"
root = Path(sys.argv[2] if len(sys.argv) > 2 else "site")
root.mkdir(parents=True, exist_ok=True)

INDEX = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>My Site</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header><h1>My Site</h1><nav><a href="#about">About</a> <a href="#contact">Contact</a></nav></header>
  <main>
    <section id="about"><h2>About</h2><p>Replace this text.</p></section>
    <section id="contact"><h2>Contact</h2><button id="btn">Click me</button><p id="out"></p></section>
  </main>
  <footer><small>Generated offline.</small></footer>
  <script src="app.js"></script>
</body>
</html>
"""
CSS = """* { box-sizing: border-box; }
body { margin: 0; font-family: system-ui, Arial, sans-serif; line-height: 1.5; color: #222; }
header, main, footer { max-width: 56rem; margin: 0 auto; padding: 1rem; }
header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; }
nav a { margin-left: 1rem; color: #0b5cad; }
button { padding: .5rem 1rem; border: 0; border-radius: .3rem; background: #0b5cad; color: #fff; cursor: pointer; }
@media (max-width: 600px) { header { flex-direction: column; } }
"""
JS = """document.getElementById('btn').addEventListener('click', function () {
  document.getElementById('out').textContent = 'Clicked at ' + new Date().toLocaleTimeString();
});
"""
WSGI = '''"""Zero-dependency web app (standard library only). Run: python app.py  -> http://127.0.0.1:8000"""
import json
from pathlib import Path
from wsgiref.simple_server import make_server

STATIC = Path(__file__).parent / "static"
TYPES = {".html": "text/html", ".css": "text/css", ".js": "application/javascript"}


def app(environ, start_response):
    path = environ.get("PATH_INFO", "/")
    if path == "/api/hello":
        body = json.dumps({"message": "hello"}).encode()
        start_response("200 OK", [("Content-Type", "application/json")])
        return [body]
    name = "index.html" if path == "/" else path.lstrip("/")
    f = (STATIC / name).resolve()
    if STATIC.resolve() in f.parents and f.is_file():
        start_response("200 OK", [("Content-Type", TYPES.get(f.suffix, "text/plain"))])
        return [f.read_bytes()]
    start_response("404 Not Found", [("Content-Type", "text/plain")])
    return [b"not found"]


if __name__ == "__main__":
    with make_server("127.0.0.1", 8000, app) as srv:
        print("Serving on http://127.0.0.1:8000")
        srv.serve_forever()
'''
FLASK = '''from flask import Flask, jsonify, send_from_directory

app = Flask(__name__, static_folder="static")


@app.route("/")
def home():
    return send_from_directory(app.static_folder, "index.html")


@app.route("/api/hello")
def hello():
    return jsonify(message="hello")


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000)
'''
if kind == "static":
    files = {"index.html": INDEX, "style.css": CSS, "app.js": JS}
else:
    files = {"static/index.html": INDEX, "static/style.css": CSS, "static/app.js": JS,
             "app.py": WSGI if kind == "wsgi" else FLASK}
for rel, text in files.items():
    p = root / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding="utf-8")
print("Created %s scaffold in %s" % (kind, root.resolve()))
for rel in files:
    print(" ", rel)

"""Basic HTML validator (unclosed/mismatched tags, missing basics). usage: validate_html.py <file.html>"""
import sys
from html.parser import HTMLParser
from pathlib import Path

VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}


class V(HTMLParser):
    def __init__(self):
        super().__init__()
        self.stack, self.problems, self.seen = [], [], set()

    def handle_starttag(self, tag, attrs):
        self.seen.add(tag)
        if tag not in VOID:
            self.stack.append((tag, self.getpos()[0]))
        a = dict(attrs)
        if tag == "img" and "alt" not in a:
            self.problems.append("line %d: <img> without alt" % self.getpos()[0])
        for k, v in attrs:
            if k in ("src", "href") and v and v.startswith(("http://", "https://", "//")):
                self.problems.append("line %d: external resource %s (offline use will fail)" % (self.getpos()[0], v))

    def handle_endtag(self, tag):
        if tag in VOID:
            return
        if not self.stack:
            self.problems.append("line %d: stray </%s>" % (self.getpos()[0], tag))
            return
        if self.stack[-1][0] == tag:
            self.stack.pop()
        else:
            names = [t for t, _ in self.stack]
            if tag in names:
                while self.stack and self.stack[-1][0] != tag:
                    t, ln = self.stack.pop()
                    self.problems.append("line %d: <%s> opened here is never closed" % (ln, t))
                self.stack.pop()
            else:
                self.problems.append("line %d: </%s> has no matching opening tag" % (self.getpos()[0], tag))


p = Path(sys.argv[1])
v = V()
v.feed(p.read_text(encoding="utf-8", errors="replace"))
for t, ln in v.stack:
    v.problems.append("line %d: <%s> never closed" % (ln, t))
for need in ("html", "head", "title", "body"):
    if need not in v.seen:
        v.problems.append("missing <%s>" % need)
if v.problems:
    print("HTML problems in %s:" % p)
    print("\n".join(" - " + x for x in v.problems[:25]))
    sys.exit(1)
print("HTML OK:", p)

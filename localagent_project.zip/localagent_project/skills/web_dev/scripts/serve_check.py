"""Serve a folder briefly and GET a path. usage: serve_check.py <folder> [path=/] [port=8765]
For apps with their own server: serve_check.py --app <app.py> [path] [port]  (starts it, requests, stops it)"""
import functools
import http.server
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path

args = sys.argv[1:]
app_mode = bool(args and args[0] == "--app")
if app_mode:
    args = args[1:]
target = args[0] if args else "."
path = args[1] if len(args) > 1 else "/"
port = int(args[2]) if len(args) > 2 else 8765


def fetch():
    for _ in range(25):
        try:
            with urllib.request.urlopen("http://127.0.0.1:%d%s" % (port, path), timeout=3) as r:
                body = r.read(600).decode("utf-8", "replace")
                print("HTTP %d %s\n%s" % (r.status, r.headers.get("content-type"), body))
                return 0
        except Exception as e:  # noqa: BLE001
            last = e
            time.sleep(0.4)
    print("Server did not answer:", last)
    return 1


if app_mode:
    proc = subprocess.Popen([sys.executable, target], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    try:
        rc = fetch()
        if rc and proc.poll() is not None:
            print((proc.stdout.read() or b"").decode("utf-8", "replace")[-800:])
    finally:
        proc.terminate()
    sys.exit(rc)
handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(Path(target)))
srv = http.server.ThreadingHTTPServer(("127.0.0.1", port), handler)
threading.Thread(target=srv.serve_forever, daemon=True).start()
rc = fetch()
srv.shutdown()
sys.exit(rc)

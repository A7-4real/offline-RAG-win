---
name: web_dev
description: Build and test small websites and web apps (HTML, CSS, JavaScript, Flask or standard-library Python servers) that work fully offline
tools: [write_file, edit_file, read_file, make_dir, list_dir, run_skill_script, run_python, local_http_get, find_files, search_docs]
keywords: [website, web page, html, css, javascript, js, flask, web app, landing page, frontend, backend, server, dashboard, form, http, api endpoint, webpage, site]
max_steps: 8
---
## Rules
- Offline only: NO CDN links, NO external fonts or images. Inline CSS/JS or local files.
- Start from the scaffold: run_skill_script(skill="web_dev", script="scaffold.py", args="static mysite") (kinds: static, wsgi, flask).
- Keep files small: index.html, style.css, app.js. Semantic HTML (header, main, section, footer), responsive CSS (flex/grid, max-width, media query).
- After writing HTML run validate_html.py on it. After writing a server run serve_check.py to prove it answers.
- Use edit_file for changes. Never rewrite a working file without need.
## Workflow
1. Create the project skeleton (tool: run_skill_script)
2. Write or adjust HTML structure (tool: write_file)
3. Style and add behaviour (tool: write_file)
4. Validate the HTML (tool: run_skill_script)
5. Serve and test it (tool: run_skill_script)
## Notes
Flask is only usable if installed (check with py_introspect module=flask); the wsgi kind has zero dependencies.

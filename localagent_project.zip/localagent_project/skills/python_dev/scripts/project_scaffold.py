"""Create a minimal Python project skeleton.  usage: project_scaffold.py <name>"""
import sys
from pathlib import Path

name = sys.argv[1] if len(sys.argv) > 1 else "myproject"
root = Path(name)
(root / name).mkdir(parents=True, exist_ok=True)
(root / "tests").mkdir(exist_ok=True)
(root / name / "__init__.py").write_text('"""%s package."""\n__version__ = "0.1.0"\n' % name, encoding="utf-8")
(root / name / "main.py").write_text('def main():\n    print("hello from %s")\n\n\nif __name__ == "__main__":\n    main()\n' % name, encoding="utf-8")
(root / "tests" / "test_smoke.py").write_text('import unittest\n\n\nclass Smoke(unittest.TestCase):\n    def test_import(self):\n        import %s\n        self.assertTrue(%s.__version__)\n\n\nif __name__ == "__main__":\n    unittest.main()\n' % (name, name), encoding="utf-8")
(root / "README.md").write_text("# %s\n\nDescribe the project here.\n" % name, encoding="utf-8")
print("Created project skeleton in", root.resolve())
for p in sorted(root.rglob("*")):
    if p.is_file():
        print(" ", p.relative_to(root))

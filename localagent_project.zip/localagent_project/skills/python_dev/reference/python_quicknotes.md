# Python quick notes (offline)

## Reading errors
- `ModuleNotFoundError: No module named 'x'` -> package not installed on this offline machine. Use the standard library or ask the user to add the wheel.
- `IndentationError` / `SyntaxError` -> run python_check; look at the line shown and the line before it (missing colon/bracket).
- `KeyError: 'k'` -> dict lacks the key; use `d.get("k")` or check `"k" in d`.
- `TypeError: ... NoneType` -> a function returned None; check for missing `return`.
- `FileNotFoundError` -> path relative to the working directory (the workspace); print `Path.cwd()`.
- `UnicodeDecodeError` on Windows -> open with `encoding="utf-8"` (or `"cp1252"` for old Windows files).

## Patterns
- Read file: `Path("a.txt").read_text(encoding="utf-8")`. Write: `Path("a.txt").write_text(text, encoding="utf-8")`.
- CSV: `import csv; rows = list(csv.DictReader(open("a.csv", newline="", encoding="utf-8")))`.
- JSON: `json.loads(text)`, `json.dumps(obj, indent=2)`.
- CLI args: `argparse.ArgumentParser()`; `parser.add_argument("--n", type=int, default=1)`.
- Run a command: `subprocess.run(["cmd", "arg"], capture_output=True, text=True, timeout=30)`.
- Unit test: `class T(unittest.TestCase): def test_x(self): self.assertEqual(f(1), 2)`; run with `python -m unittest`.
- Dataclass: `@dataclass class P: x: int; y: int = 0`.
- Sorting by key: `sorted(items, key=lambda r: r["score"], reverse=True)`.
- Regex: `re.findall(r"\d+", text)`; named group `(?P<id>\d+)`.
- Date/time: `datetime.now().strftime("%Y-%m-%d %H:%M")`.

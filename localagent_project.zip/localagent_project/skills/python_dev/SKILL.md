---
name: python_dev
description: Write, run, test and debug Python scripts, modules and small programs
tools: [write_file, edit_file, read_file, run_python, python_check, run_tests, py_introspect, grep, find_files, run_shell]
keywords: [python, script, function, class, module, pytest, unittest, debug, bug, traceback, program, code, algorithm, refactor, py]
max_steps: 7
---
## Rules
- Write small files. One responsibility per function. Add a short docstring.
- After EVERY write_file/edit_file on a .py file run python_check before running it.
- If you are unsure about a library API, call py_introspect(module, name) instead of guessing.
- Read the traceback bottom-up: the last line is the error, the line above it is where.
- Fix with edit_file (small exact change), then re-run. Do not rewrite the whole file for a one-line bug.
- Write a test file (test_*.py) for non-trivial logic and run it with run_tests.
## Workflow
1. Inspect existing code or requirements (tool: read_file)
2. Write or change the code (tool: write_file)
3. Syntax and lint check (tool: python_check)
4. Run it with a sample input (tool: run_python)
5. Test and fix until it works (tool: run_tests)
## Notes
Standard library first. Third-party packages must already be installed (offline machine): check with py_introspect.

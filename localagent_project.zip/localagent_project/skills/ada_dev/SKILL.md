---
name: ada_dev
description: Write, compile and fix Ada (GNAT) programs and packages, including Ada 2012 features, tasking and generics
tools: [write_file, edit_file, read_file, run_skill_script, run_shell, search_docs, os_info, list_dir]
keywords: [ada, gnat, gnatmake, adb, ads, spark, ada 2012, tasking, protected object, package body, ada program]
max_steps: 8
---
## Rules
- The main procedure name must equal the file name: procedure Hello -> hello.adb. A package Foo -> foo.ads (spec) and foo.adb (body). File names are lower case.
- Ada is strongly typed: convert explicitly (Float (I), Integer (X)). No implicit mixing of Integer and Float.
- Assignment is `:=`, equality `=`, inequality `/=`. Every block ends with `end Name;`.
- Always compile with compile.py after writing; fix the FIRST reported error first (later ones are often consequences).
- If syntax is unclear, search_docs(query="ada <topic>") for the cheat-sheet. Do not invent library units: Ada.Text_IO, Ada.Integer_Text_IO, Ada.Float_Text_IO, Ada.Strings.Unbounded, Ada.Containers.Vectors are real.
- Write to the workspace; run with compile.py --run.
## Workflow
1. Check the GNAT toolchain exists (tool: os_info)
2. Write the .ads/.adb sources (tool: write_file)
3. Compile and read the errors (tool: run_skill_script)
4. Fix the first error with a small edit (tool: edit_file)
5. Recompile and run until clean (tool: run_skill_script)
## Notes
compile.py prints "file:line:col: message" lines. If GNAT is missing it says so (exit 3): then only write code and tell the user it could not be compiled.

# Ada cheat-sheet (Ada 2012, GNAT)

## Hello world and file naming
```ada
with Ada.Text_IO; use Ada.Text_IO;
procedure Hello is          -- file must be hello.adb
begin
   Put_Line ("Hello, world");
end Hello;
```
Package `Stack` = `stack.ads` (specification) + `stack.adb` (body). Names are case-insensitive, files lower case.

## Declarations and types
```ada
Count  : Integer := 0;
Ratio  : Float := 0.5;
Name   : constant String := "Alice";      -- String is a fixed-length array of Character
Flag   : Boolean := True;
subtype Small is Integer range 1 .. 10;
type Color is (Red, Green, Blue);          -- enumeration; Color'Succ (Red) = Green
type Celsius is digits 6 range -100.0 .. 100.0;
type Point is record X, Y : Float := 0.0; end record;
type Vec is array (1 .. 10) of Integer;
type Matrix is array (1 .. 3, 1 .. 3) of Float;
type Int_Array is array (Positive range <>) of Integer;   -- unconstrained
```
Attributes: `A'First A'Last A'Length A'Range`, `Integer'Image (5)` (has a leading space), `Integer'Value ("42")`, `Color'Pos (Red)`.

## Operators
`:=` assign, `=` `/=` `<` `<=` compare, `and or xor not`, short-circuit `and then` / `or else`, `+ - * /`, `mod rem abs **`, concatenation `&`. Integer division `/` truncates; mixing Integer and Float is a compile error: use `Float (I) * X`.

## Control flow
```ada
if A > B then ... elsif A = B then ... else ... end if;
case Day is when Mon .. Fri => Work; when Sat | Sun => Rest; when others => null; end case;
for I in 1 .. 10 loop ... end loop;     for I in reverse 1 .. 10 loop ... end loop;
while N > 0 loop N := N - 1; end loop;
loop ... exit when Done; end loop;
```
Ada 2012: `X := (if A > B then A else B);` and `for E of My_Array loop ... end loop;`.

## Subprograms
```ada
procedure Swap (A, B : in out Integer) is
   T : constant Integer := A;
begin
   A := B; B := T;
end Swap;

function Square (X : Integer) return Integer is (X * X);      -- expression function
function Max (A, B : Integer) return Integer is
begin
   if A > B then return A; else return B; end if;
end Max;
```
Parameter modes: `in` (default), `out`, `in out`. Named association: `Plot (X => 1.0, Y => 2.0)`.

## Packages
```ada
-- stack.ads
package Stack is
   procedure Push (X : Integer);
   function Pop return Integer;
   function Is_Empty return Boolean;
end Stack;

-- stack.adb
package body Stack is
   Data : array (1 .. 100) of Integer;
   Top  : Natural := 0;
   procedure Push (X : Integer) is begin Top := Top + 1; Data (Top) := X; end Push;
   function Pop return Integer is begin Top := Top - 1; return Data (Top + 1); end Pop;
   function Is_Empty return Boolean is (Top = 0);
end Stack;
```
Use it: `with Stack;` then `Stack.Push (3);` (or add `use Stack;`).

## Text I/O
```ada
with Ada.Text_IO;         use Ada.Text_IO;
with Ada.Integer_Text_IO; use Ada.Integer_Text_IO;
with Ada.Float_Text_IO;   use Ada.Float_Text_IO;
Put ("text"); Put_Line ("line"); New_Line;
Put (42, Width => 5);                 -- Integer_Text_IO
Put (3.14159, Fore => 1, Aft => 2, Exp => 0);   -- Float_Text_IO prints 3.14
Get (N);                              -- read Integer
Line : String := Get_Line;            -- read a whole line (Ada.Text_IO function form)
```
Number to string without the leading space: `Ada.Strings.Fixed.Trim (Integer'Image (X), Ada.Strings.Left)`.
Dynamic strings: `with Ada.Strings.Unbounded; use Ada.Strings.Unbounded;` `S : Unbounded_String := To_Unbounded_String ("abc");` `To_String (S)`, `Length (S)`, `Append (S, "x")`.
File I/O: `F : File_Type; Open (F, In_File, "a.txt"); while not End_Of_File (F) loop Put_Line (Get_Line (F)); end loop; Close (F);` (modes In_File, Out_File, Append_File; `Create (F, Out_File, "a.txt")`).

## Exceptions
```ada
begin
   X := A / B;
exception
   when Constraint_Error => Put_Line ("range or division error");
   when Ada.Text_IO.Data_Error => Put_Line ("bad input");
   when others => Put_Line ("unexpected"); raise;
end;
-- define and raise your own:
Not_Found : exception;   ...   raise Not_Found;
```
Predefined: Constraint_Error, Program_Error, Storage_Error, Tasking_Error, End_Error, Name_Error, Data_Error.

## Generics
```ada
generic
   type T is private;
procedure Generic_Swap (A, B : in out T);
procedure Generic_Swap (A, B : in out T) is Tmp : constant T := A; begin A := B; B := Tmp; end Generic_Swap;
procedure Swap_Int is new Generic_Swap (Integer);
```

## Containers
```ada
with Ada.Containers.Vectors;
package Int_Vectors is new Ada.Containers.Vectors (Index_Type => Positive, Element_Type => Integer);
V : Int_Vectors.Vector;   V.Append (5);   Natural (V.Length);   V.Element (1);
```
Also `Ada.Containers.Ordered_Maps`, `Ada.Containers.Indefinite_Vectors`, `Doubly_Linked_Lists`.

## Tasking
```ada
task type Worker (Id : Integer);
task body Worker is begin Put_Line ("worker" & Integer'Image (Id)); end Worker;
W1 : Worker (1);      -- starts automatically; main waits for it to finish

protected type Counter is
   procedure Increment;
   function Value return Integer;
private
   N : Integer := 0;
end Counter;
protected body Counter is
   procedure Increment is begin N := N + 1; end Increment;
   function Value return Integer is (N);
end Counter;
```
Rendezvous: `task T is entry Go (X : Integer); end T;` body: `accept Go (X : Integer) do ... end Go;`. `delay 1.0;` waits one second.

## Contracts (Ada 2012 / SPARK)
`function Sqrt_Floor (X : Natural) return Natural with Pre => X >= 0, Post => Sqrt_Floor'Result ** 2 <= X;`
Type invariant: `subtype Even is Integer with Dynamic_Predicate => Even mod 2 = 0;`

## Common compile errors and fixes
- `file name does not match unit name, should be "hello.adb"` -> rename the file to the lower-case unit name.
- `"X" is not visible` / `undefined` -> missing `with Package;` or `use`, or misspelled; qualify as `Ada.Text_IO.Put_Line`.
- `expected type "Standard.Float" ... found type "Standard.Integer"` -> convert: `Float (I)`.
- `missing ";"` / `"end if;" expected` -> unbalanced block; every `if/loop/case` needs its own `end`.
- `no candidate interpretations match the actuals` for Put -> missing `with Ada.Integer_Text_IO; use ...` (or Float_Text_IO) for that type.
- `string length mismatch / wrong length for array` -> `String (1 .. 5) := "Alice"` must match exactly; prefer `constant String`.
- `"Name" misspelling of "NAME"`-style or `end Name;` mismatch -> the name after `end` must equal the unit name.
- `warning: variable "X" is assigned but never referenced` -> harmless; remove if unused.
- `object is read-only` -> assigning to a constant or `in` parameter; change mode to `in out`.
- Runtime `CONSTRAINT_ERROR ... range check failed` -> value outside the subtype range; check loop bounds and array indices.

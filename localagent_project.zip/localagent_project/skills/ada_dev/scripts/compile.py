"""Compile (and optionally run) an Ada program with GNAT.
usage: compile.py <main.adb> [--run] [--args "a b"]   (object files go to ./.ada_build)"""
import os
import shutil
import subprocess
import sys
from pathlib import Path

argv = sys.argv[1:]
if not argv:
    print("usage: compile.py <main.adb> [--run] [--args \"...\"]")
    sys.exit(2)
src = Path(argv[0])
run = "--run" in argv
prog_args = argv[argv.index("--args") + 1].split() if "--args" in argv else []
if not src.exists():
    print("source not found:", src)
    sys.exit(2)
tool = shutil.which("gnatmake")
if not tool:
    print("GNAT (gnatmake) not found on PATH. Install an Ada toolchain (GNAT Community/FSF GNAT/Alire) and add it to PATH.")
    print("Without it the code cannot be compiled; deliver the source files and say so.")
    sys.exit(3)
build = Path(".ada_build")
build.mkdir(exist_ok=True)
exe = build / src.stem
cmd = [tool, "-gnat2012", "-gnatwa", "-gnatq", "-D", str(build), "-o", str(exe), str(src)]
cp = subprocess.run(cmd, capture_output=True, text=True)
out = (cp.stdout + cp.stderr).strip()
lines = [l for l in out.splitlines() if l.strip()]
errors = [l for l in lines if ": error" in l or l.count(":") >= 3 and "error" in l.lower()]
warnings = [l for l in lines if "warning:" in l]
if cp.returncode != 0:
    print("COMPILE FAILED (%d error lines). Fix the FIRST one first:" % len(errors))
    print("\n".join((errors or lines)[:12]))
    sys.exit(1)
print("Compiled OK -> %s (%d warnings)" % (exe, len(warnings)))
if warnings:
    print("\n".join(warnings[:6]))
if run:
    exe_path = str(exe) + (".exe" if os.name == "nt" else "")
    r = subprocess.run([exe_path] + prog_args, capture_output=True, text=True, timeout=60)
    print("--- program output (exit %d) ---" % r.returncode)
    print((r.stdout + r.stderr)[:3000])
    sys.exit(r.returncode)

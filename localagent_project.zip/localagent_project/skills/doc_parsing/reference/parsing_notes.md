# Document parsing notes
- docx: headings become `#`, bullet lists become `- `, tables become markdown tables. Merged header cells show as an empty cell after the text (gridSpan) - read the header rows together to understand them.
- pptx: output is split by `--- slide N ---`; speaker notes are prefixed `[notes]`.
- xlsx: one block per sheet; only the first 300 rows are shown. For more, use run_python with `csv`/`zipfile`.
- pdf: `--- page N ---` markers. Two-column layouts may interleave columns; check with grep_artifact around the keyword.
- Cross references ("see section 4.2"): search the artifact for the number with grep_artifact, then read that range.
- Large documents: never read everything. Outline first (grep_artifact pattern "^#|^[0-9]+\.[0-9]* "), then read only the needed sections.

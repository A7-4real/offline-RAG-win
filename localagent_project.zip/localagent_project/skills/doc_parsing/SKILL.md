---
name: doc_parsing
description: Extract text, tables and data from PDF, Word, PowerPoint, Excel, CSV, HTML and JSON files and turn it into notes, summaries or structured output
tools: [parse_document, read_artifact, grep_artifact, write_file, read_file, find_files, calc, search_docs, run_python]
keywords: [pdf, docx, word, powerpoint, pptx, excel, xlsx, csv, table, extract, parse, document, summarise, summarize, report, spreadsheet, slides, convert]
max_steps: 6
---
## Rules
- Always start with parse_document(path). Big documents are saved as an artifact (A1, A2...): then use grep_artifact to find the part you need and read_artifact for line ranges. Never guess document content.
- For PDFs use pages="1-3" to limit work. Tables appear as markdown tables.
- Copy numbers exactly from the document. Use calc for any arithmetic.
- Write results to a new file (markdown, csv or json) with write_file, then confirm with read_file.
- If a document has no text (scanned), say so; do not invent content.
## Workflow
1. Find the document (tool: find_files)
2. Parse it (tool: parse_document)
3. Locate the needed sections or values (tool: grep_artifact)
4. Write the extracted result to an output file (tool: write_file)
## Notes
docx/pptx/xlsx are parsed with the standard library; PDF needs pypdf, pdfplumber or PyMuPDF installed. Legacy .doc/.ppt/.xls must be converted first.

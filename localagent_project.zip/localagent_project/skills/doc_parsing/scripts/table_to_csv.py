"""Convert the markdown tables found in a text file to CSV files.
usage: table_to_csv.py <input.txt|md> <output_prefix>"""
import csv
import re
import sys
from pathlib import Path

src, prefix = Path(sys.argv[1]), sys.argv[2]
tables, cur = [], []
for line in src.read_text(encoding="utf-8", errors="replace").splitlines():
    if line.strip().startswith("|"):
        cur.append(line)
    elif cur:
        tables.append(cur)
        cur = []
if cur:
    tables.append(cur)
for i, t in enumerate(tables, 1):
    rows = []
    for ln in t:
        cells = [c.strip().replace("\\|", "|") for c in re.split(r"(?<!\\)\|", ln.strip().strip("|"))]
        if all(re.fullmatch(r"-{3,}", c) or c == "" for c in cells) and any(cells):
            continue
        rows.append(cells)
    out = Path("%s_%d.csv" % (prefix, i))
    with open(out, "w", newline="", encoding="utf-8") as fh:
        csv.writer(fh).writerows(rows)
    print("wrote", out, "(%d rows)" % len(rows))
print("%d table(s) found" % len(tables))

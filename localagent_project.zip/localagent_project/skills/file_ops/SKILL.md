---
name: file_ops
description: Create, read, edit, search, copy, move and organise files and folders in the workspace
tools: [list_dir, find_files, grep, read_file, write_file, edit_file, make_dir, copy_path, move_path, delete_path, file_info]
keywords: [file, folder, directory, rename, move, copy, organise, organize, sort, search in files, rewrite, edit, text file, log]
max_steps: 6
---
## Rules
- Look before you act: list_dir / find_files first, read_file before edit_file.
- Change part of a file with edit_file (exact text). Use write_file mode=overwrite only for whole-file rewrites.
- Never delete or overwrite something the task did not ask you to touch.
- After writing, confirm with read_file or file_info.
## Workflow
1. Locate the relevant files (tool: find_files)
2. Read the parts that matter (tool: read_file)
3. Make the change (tool: edit_file) 
4. Confirm the result (tool: read_file)
## Notes
Paths are relative to the workspace. Hidden folders (.scratch) are ignored by listings.

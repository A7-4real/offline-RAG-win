"""Render a design spec (JSON) to a markdown architecture document with a Mermaid diagram.
usage: render_architecture.py <design.json> [output.md]"""
import json
import re
import sys
from pathlib import Path

src = Path(sys.argv[1])
out = Path(sys.argv[2]) if len(sys.argv) > 2 else src.with_suffix(".md")
spec = json.loads(src.read_text(encoding="utf-8"))
comps = spec.get("components", [])
names = {c["name"] for c in comps}
problems = []
for i in spec.get("interfaces", []):
    for end in ("from", "to"):
        if i.get(end) not in names:
            problems.append("interface %s -> %s: unknown component %r" % (i.get("from"), i.get("to"), i.get(end)))
if not comps:
    problems.append("no components defined")


def nid(n):
    return re.sub(r"\W", "_", n)


L = ["# %s" % spec.get("name", "System design"), "", spec.get("summary", ""), ""]
if spec.get("requirements"):
    L += ["## Requirements"] + ["- %s" % r for r in spec["requirements"]] + [""]
L += ["## Architecture diagram", "", "```mermaid", "flowchart LR"]
for c in comps:
    L.append('    %s["%s"]' % (nid(c["name"]), c["name"]))
for i in spec.get("interfaces", []):
    if i.get("from") in names and i.get("to") in names:
        L.append('    %s -->|"%s"| %s' % (nid(i["from"]), i.get("protocol", ""), nid(i["to"])))
L += ["```", "", "## Components", "", "| Component | Responsibility | Technology |", "|---|---|---|"]
for c in comps:
    L.append("| %s | %s | %s |" % (c["name"], c.get("responsibility", ""), c.get("tech", "")))
if spec.get("interfaces"):
    L += ["", "## Interfaces", "", "| From | To | Protocol | Data |", "|---|---|---|---|"]
    for i in spec["interfaces"]:
        L.append("| %s | %s | %s | %s |" % (i.get("from"), i.get("to"), i.get("protocol", ""), i.get("data", "")))
for f in spec.get("flows", []):
    L += ["", "## Flow: %s" % f.get("name", "")] + ["%d. %s" % (n, s) for n, s in enumerate(f.get("steps", []), 1)]
if spec.get("risks"):
    L += ["", "## Risks", "", "| Risk | Mitigation |", "|---|---|"]
    L += ["| %s | %s |" % (r.get("risk"), r.get("mitigation")) for r in spec["risks"]]
if spec.get("decisions"):
    L += ["", "## Decisions"]
    for d in spec["decisions"]:
        L += ["", "### %s" % d.get("title"), "**Decision:** %s" % d.get("decision"), "", "**Why:** %s" % d.get("rationale")]
out.write_text("\n".join(L) + "\n", encoding="utf-8")
print("Rendered", out, "| components:", len(comps), "| interfaces:", len(spec.get("interfaces", [])))
if problems:
    print("PROBLEMS:\n- " + "\n- ".join(problems))
    sys.exit(1)

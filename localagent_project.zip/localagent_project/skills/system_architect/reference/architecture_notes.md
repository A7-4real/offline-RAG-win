# Architecture notes

## Requirement questions
Functional (what it does), quality (latency, throughput, availability, security, offline operation), constraints (OS, hardware, no internet, language), users and scale, integrations, data (volume, retention, formats).

## Common styles
- Layered (UI / logic / data): simple apps. - Pipeline (stages with queues/files): batch processing, ETL, document processing.
- Client-server / REST: multi-user tools. - Event-driven / message bus: loosely coupled components, real-time.
- Plugin architecture: extensible tools (core + plugins). - Agent architecture: planner + tools + memory + verifier.

## Design checklist
1. Single responsibility per component. 2. Explicit interfaces (data shape, protocol, errors). 3. Where is state stored and who owns it?
4. Failure modes and retries. 5. Security boundary and input validation. 6. Logging and observability. 7. Testing strategy. 8. Deployment (offline install, versions pinned).

## Decision record format (ADR)
Title, Context, Decision, Consequences (good and bad), Alternatives considered.

## Database design
Entities and relations first; primary keys; foreign keys; index the columns used in WHERE/JOIN; normalise to 3NF unless performance demands otherwise. SQLite is enough for single-machine apps.

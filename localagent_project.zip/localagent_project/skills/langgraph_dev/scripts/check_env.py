"""Report installed LangChain/LangGraph-related package versions and key exports."""
import importlib
import importlib.metadata as md

PKGS = ["langgraph", "langgraph-checkpoint", "langgraph-prebuilt", "langchain", "langchain-core", "langchain-community",
        "langchain-openai", "langchain-ollama", "langchain-text-splitters", "ollama", "openai", "pydantic",
        "llama-cpp-python", "chromadb", "faiss-cpu", "sentence-transformers"]
print("Installed packages:")
for p in PKGS:
    try:
        print("  %-26s %s" % (p, md.version(p)))
    except md.PackageNotFoundError:
        print("  %-26s -" % p)
for mod, names in [("langgraph.graph", ["StateGraph", "START", "END", "MessagesState", "add_messages"]),
                   ("langgraph.checkpoint.memory", ["MemorySaver", "InMemorySaver"]),
                   ("langgraph.prebuilt", ["create_react_agent", "ToolNode", "tools_condition"]),
                   ("langchain_core.prompts", ["ChatPromptTemplate", "PromptTemplate"]),
                   ("langchain_core.output_parsers", ["StrOutputParser", "JsonOutputParser"]),
                   ("langchain_core.tools", ["tool", "StructuredTool"]),
                   ("langchain_core.messages", ["HumanMessage", "AIMessage", "SystemMessage", "ToolMessage"]),
                   ("langchain_openai", ["ChatOpenAI"]), ("langchain_ollama", ["ChatOllama"])]:
    try:
        m = importlib.import_module(mod)
    except Exception as e:  # noqa: BLE001
        print("\n%s: NOT importable (%s)" % (mod, type(e).__name__))
        continue
    have = [n for n in names if hasattr(m, n)]
    miss = [n for n in names if not hasattr(m, n)]
    print("\n%s: present=%s missing=%s" % (mod, have, miss))

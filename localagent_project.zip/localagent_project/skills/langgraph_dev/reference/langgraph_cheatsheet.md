# LangGraph / LangChain cheat-sheet (verify every name with py_introspect first!)

## Minimal graph
```python
from typing import TypedDict
from langgraph.graph import StateGraph, START, END

class State(TypedDict):
    text: str
    count: int

def shout(state: State) -> dict:
    return {"text": state["text"].upper(), "count": state["count"] + 1}

g = StateGraph(State)
g.add_node("shout", shout)
g.add_edge(START, "shout")
g.add_edge("shout", END)
app = g.compile()
print(app.invoke({"text": "hi", "count": 0}))
```
A node receives the whole state and returns ONLY the keys it updates.

## Conditional routing
```python
def route(state: State) -> str:
    return "again" if state["count"] < 3 else "stop"

g.add_conditional_edges("shout", route, {"again": "shout", "stop": END})
```

## Reducers (append instead of overwrite)
```python
import operator
from typing import Annotated, TypedDict
class State(TypedDict):
    log: Annotated[list, operator.add]     # nodes return {"log": ["entry"]}
```
Chat history: `from langgraph.graph import MessagesState` (has a `messages` key with the add_messages reducer).

## Checkpointing / memory across calls
```python
from langgraph.checkpoint.memory import MemorySaver
app = g.compile(checkpointer=MemorySaver())
cfg = {"configurable": {"thread_id": "session-1"}}
app.invoke({"text": "hi", "count": 0}, config=cfg)
app.get_state(cfg)
```
Persistent on disk: look for a sqlite checkpointer package (langgraph-checkpoint-sqlite) with py_introspect; not always installed.

## Streaming
`for chunk in app.stream(inputs, stream_mode="updates"): print(chunk)`

## Human-in-the-loop / interrupts
`app = g.compile(checkpointer=MemorySaver(), interrupt_before=["risky_node"])` then resume with `app.invoke(None, config=cfg)`. (Newer versions also offer `interrupt()` - check py_introspect.)

## Prebuilt ReAct agent
`from langgraph.prebuilt import create_react_agent` ; `agent = create_react_agent(llm, tools)`; `agent.invoke({"messages": [("user", "question")]})`. Needs a chat model that supports tool calling - small local models often do not: prefer your own graph with JSON-parsed actions.

## LangChain core (LCEL)
```python
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
prompt = ChatPromptTemplate.from_messages([("system", "You are concise."), ("user", "{question}")])
chain = prompt | llm | StrOutputParser()
chain.invoke({"question": "What is Ada?"})
```
Tools: `from langchain_core.tools import tool` ; `@tool def add(a: int, b: int) -> int: """Add two numbers."""; return a + b` ; `add.invoke({"a": 1, "b": 2})`.
Structured output: `llm.with_structured_output(MyPydanticModel)` (needs model/server support; otherwise parse JSON yourself).

## Local models
- OpenAI-compatible server (LM Studio / llama.cpp): `from langchain_openai import ChatOpenAI; llm = ChatOpenAI(base_url="http://localhost:1234/v1", api_key="x", model="local-model", temperature=0)`.
- Ollama: `from langchain_ollama import ChatOllama; llm = ChatOllama(model="gemma2:9b", temperature=0)` (older installs: `langchain_community.chat_models.ChatOllama`).
- Messages: `from langchain_core.messages import HumanMessage, SystemMessage`; the reply text is `resp.content`.

## Common errors
- `ImportError: cannot import name X` -> API moved; run check_env.py and py_introspect on the parent module.
- `InvalidUpdateError: ... multiple values for key` -> two nodes wrote the same key in one step; add a reducer (Annotated) or serialise nodes.
- `ValueError: Found edge starting at unknown node` -> add_node must come before add_edge.
- Graph never ends -> a conditional route never returns END; add a counter or `recursion_limit` in config: `app.invoke(x, config={"recursion_limit": 25})`.
- `Checkpointer requires thread_id` -> pass config with configurable.thread_id.

---
name: langgraph_dev
description: Develop LangGraph and LangChain applications (graphs, nodes, state, routing, checkpoints, chains, tools, local models) against the versions installed offline
tools: [write_file, edit_file, read_file, py_introspect, run_python, python_check, run_skill_script, search_docs, find_files]
keywords: [langgraph, langchain, stategraph, graph, node, edge, chain, lcel, runnable, ollama, agent graph, workflow graph, checkpointer, react agent, prompt template, langchain_core]
max_steps: 8
---
## Rules
- LangChain/LangGraph APIs change between versions and your memory of them is unreliable. FIRST run check_env.py, THEN py_introspect (module, name) for every class or function you are about to use.
- Import only names that py_introspect confirmed exist. If an import fails, search the module listing for the new location.
- Graph recipe: define the State (TypedDict) -> write node functions that return a dict of updates -> StateGraph(State) -> add_node/add_edge/add_conditional_edges -> compile() -> invoke(). Start with the smallest graph that runs, then extend.
- Routing functions return a string key; map keys to node names (or END).
- Test with a fake/trivial node before connecting a real model. For local models use the OpenAI-compatible endpoint (base_url=http://localhost:1234/v1, api_key="x") or the Ollama integration, whichever is installed.
- Run python_check, then run_python, and read the traceback fully.
## Workflow
1. Check installed versions and exports (tool: run_skill_script)
2. Confirm the exact APIs needed (tool: py_introspect)
3. Write the graph file (tool: write_file)
4. Syntax check (tool: python_check)
5. Run it with a sample input and fix errors (tool: run_python)
## Notes
Cheat-sheet in reference/langgraph_cheatsheet.md describes widely used patterns; verify names against the installed version.

# Networking cheat-sheet

## Core commands (Windows | Linux)
- IP config: `ipconfig /all` | `ip addr` (or `ifconfig`). Look for IPv4 Address, Subnet Mask, Default Gateway.
- Ping: `ping -n 4 host` | `ping -c 4 host`. Fields: time=ms latency, TTL, loss %.
- Trace route: `tracert -d host` | `traceroute -n host`. `* * *` = hop does not answer ICMP (not always a fault).
- DNS lookup: `nslookup name` | `nslookup name` / `dig name`. "Server UnKnown" = reverse lookup of DNS server missing; harmless.
- Connections: `netstat -ano` (PID column) | `ss -tunap`. Listening only: `netstat -an | findstr LISTENING` | `ss -tuln`.
- ARP table: `arp -a` | `ip neigh`.
- Routing: `route print` | `ip route`.
- Flush DNS cache (Windows): `ipconfig /flushdns`. Renew DHCP: `ipconfig /release` then `/renew` (needs admin).
- Wi-Fi profiles (Windows): `netsh wlan show profiles`. Firewall state: `netsh advfirewall show allprofiles`.
- PowerShell: `Test-NetConnection host -Port 443`, `Get-NetIPAddress`, `Resolve-DnsName name`.

## Diagnosis order
1. Link/interface up and has an IP (169.254.x.x = DHCP failed).
2. Default gateway pings.
3. Another LAN host pings.
4. Name resolution works (nslookup).
5. TCP port connects (port_check).

## Common ports
20/21 FTP, 22 SSH, 23 Telnet, 25 SMTP, 53 DNS, 67/68 DHCP, 80 HTTP, 110 POP3, 123 NTP, 135/139/445 Windows RPC/NetBIOS/SMB, 143 IMAP, 161 SNMP, 389 LDAP, 443 HTTPS, 502 Modbus, 1433 SQL Server, 3306 MySQL, 3389 RDP, 5432 PostgreSQL, 8080 alt HTTP.

## Subnets
/24 = 255.255.255.0 (254 hosts), /16 = 255.255.0.0, /8 = 255.0.0.0, /30 = 2 hosts. Private ranges: 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16. Loopback 127.0.0.1.

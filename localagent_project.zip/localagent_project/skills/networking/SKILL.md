---
name: networking
description: Diagnose and inspect networks with ping, traceroute, DNS, ports, interfaces, ARP and routing (local/offline network)
tools: [net_diag, port_check, local_http_get, run_shell, os_info, search_docs, write_file]
keywords: [network, ping, traceroute, tracert, dns, nslookup, port, ip address, ipconfig, ifconfig, netstat, arp, route, firewall, lan, connectivity, latency, socket, tcp, udp, subnet]
max_steps: 6
---
## Rules
- Use net_diag(kind=...) first: ping, traceroute, dns, interfaces, connections, listening, arp, routes. It picks the right command for Windows or Linux.
- This machine may be offline: failures to reach the internet are normal. Test the LAN gateway and localhost instead.
- Diagnose in layers: interface/IP -> gateway ping -> target ping -> DNS -> port. Report where it first fails.
- Port scanning other hosts is out of scope; use port_check only for hosts the user named.
- Explain results in plain words: packet loss %, latency in ms, open/closed ports.
## Workflow
1. Show local interfaces and IP (tool: net_diag)
2. Ping the gateway or target (tool: net_diag)
3. Check DNS or the required port (tool: port_check)
4. Summarise where the problem is (tool: finish_step)
## Notes
local_http_get only reaches localhost/private addresses.

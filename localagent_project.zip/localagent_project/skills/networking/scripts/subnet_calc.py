"""Subnet calculator.  usage: subnet_calc.py 192.168.1.10/24"""
import ipaddress
import sys

net = ipaddress.ip_network(sys.argv[1], strict=False)
hosts = list(net.hosts())
print("Network   :", net.network_address)
print("Netmask   :", net.netmask)
print("Broadcast :", net.broadcast_address)
print("Hosts     :", net.num_addresses - 2 if net.num_addresses > 2 else net.num_addresses)
if hosts:
    print("Range     :", hosts[0], "-", hosts[-1])
print("Private   :", net.is_private)

---
name: shell_cmd
description: Use Windows cmd/PowerShell and Linux bash commands to inspect and manage the system, files, processes and environment
tools: [run_shell, os_info, search_docs, read_file, list_dir, find_files, write_file]
keywords: [command, cmd, powershell, bash, shell, terminal, process, tasklist, kill, environment variable, path, disk, service, batch, bat, script, windows, linux, system info, cli]
max_steps: 6
---
## Rules
- Call os_info first to learn the OS. Then use commands for THAT OS (dir vs ls, type vs cat, tasklist vs ps).
- Not sure about syntax or flags? search_docs(query="<command>") returns the offline cheat-sheet. Do not guess flags.
- One command per call. No chaining (&&, |, ;) unless needed. Quote paths with spaces: "C:\My Folder\a.txt".
- Prefer read-only commands. Destructive ones (del, rm, format, kill) need user approval and may be blocked.
- Read the exit code in the output: 0 = success.
## Workflow
1. Detect the OS and shell (tool: os_info)
2. Look up the exact command syntax (tool: search_docs)
3. Run the command (tool: run_shell)
4. Interpret the output and report (tool: finish_step)
## Notes
Batch/PowerShell/bash scripts can be created with write_file and then run with run_shell.

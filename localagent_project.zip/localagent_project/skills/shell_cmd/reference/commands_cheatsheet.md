# Command cheat-sheet: Windows cmd | PowerShell | Linux bash

## List files
- cmd: `dir`, `dir /s /b *.py` (recursive, bare). PowerShell: `Get-ChildItem -Recurse -Filter *.py`. bash: `ls -la`, `find . -name "*.py"`.

## Show file content
- cmd: `type file.txt`, `more file.txt`. PowerShell: `Get-Content file.txt -TotalCount 20`. bash: `cat file.txt`, `head -n 20 file.txt`, `tail -n 20 file.txt`.

## Search text
- cmd: `findstr /i /n "word" *.txt`. PowerShell: `Select-String -Path *.txt -Pattern word`. bash: `grep -rin "word" .`.

## Copy / move / delete / make folder
- cmd: `copy a b`, `xcopy src dst /E /I`, `move a b`, `del file`, `rmdir /s /q dir`, `mkdir dir`.
- bash: `cp a b`, `cp -r src dst`, `mv a b`, `rm file`, `rm -r dir`, `mkdir -p dir`.

## Environment variables
- cmd: `set` (list), `set NAME` (show), `echo %NAME%`, `setx NAME value` (persist). bash: `printenv`, `echo $NAME`, `export NAME=value`.

## Processes
- cmd: `tasklist`, `tasklist /fi "imagename eq python.exe"`, `taskkill /pid 1234 /f`. bash: `ps aux`, `ps aux | grep name`, `kill 1234`.

## System info
- cmd: `systeminfo`, `ver`, `hostname`, `whoami`, `wmic cpu get name`, `wmic logicaldisk get size,freespace,caption`. bash: `uname -a`, `lscpu`, `free -h`, `df -h`, `whoami`, `hostname`.

## Disk usage
- cmd: `dir /s` (sizes at the end). PowerShell: `Get-ChildItem -Recurse | Measure-Object Length -Sum`. bash: `du -sh *`.

## Services (Windows) and (Linux)
- cmd: `sc query`, `sc query servicename`, `net start`, `net stop name`. Linux: `systemctl status name`, `systemctl list-units --type=service`.

## Archives
- Windows 10+: `tar -a -c -f out.zip folder`, `tar -xf in.zip`. PowerShell: `Compress-Archive`, `Expand-Archive`. Linux: `zip -r out.zip dir`, `unzip in.zip`, `tar czf out.tgz dir`, `tar xzf in.tgz`.

## Exit codes and chaining
- cmd: `%ERRORLEVEL%`; `a && b` (b only if a ok); `a & b`. bash: `$?`; `a && b`; `a ; b`.
- Redirect: `> file` overwrite, `>> file` append, `2>&1` merge errors.

## Batch / script basics
- cmd .bat: `@echo off`, `set X=5`, `if exist file (echo yes) else (echo no)`, `for %%f in (*.txt) do echo %%f`, `call other.bat`, `exit /b 0`.
- bash: `#!/bin/bash`, `X=5`, `if [ -f file ]; then echo yes; fi`, `for f in *.txt; do echo "$f"; done`.

## Python from the shell
- `python --version`, `python script.py arg`, `python -m pip list`, `python -m venv .venv`, `python -m http.server 8000`.

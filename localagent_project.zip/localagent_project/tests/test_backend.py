import json
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer

from localagent.llm import LLMError, LLMFormatError
from localagent.llm.base import prepare_messages
from localagent.llm.client import LLMClient
from localagent.llm.openai_compat import OpenAICompatBackend

SCHEMA = {"type": "object", "properties": {"x": {"type": "integer"}}, "required": ["x"]}


def serve(handler_fn):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_GET(self):
            self._send(200, {"data": [{"id": "fake-model"}]})

        def do_POST(self):
            body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            code, payload = handler_fn(body)
            self._send(code, payload)

        def _send(self, code, payload):
            raw = json.dumps(payload).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

    srv = HTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


def ok(text):
    return 200, {"choices": [{"message": {"content": text}}], "usage": {"prompt_tokens": 7, "completion_tokens": 3}}


class BackendTests(unittest.TestCase):
    def test_schema_mode_negotiation_falls_back(self):
        seen = []

        def handler(body):
            seen.append(body)
            if "response_format" in body and body["response_format"]["type"] == "json_schema":
                return 400, {"error": "json_schema unsupported"}
            return ok('{"x": "3"}')       # string -> coerced to int by the client

        srv = serve(handler)
        try:
            be = OpenAICompatBackend("http://127.0.0.1:%d/v1" % srv.server_port, "m", schema_mode="auto")
            cl = LLMClient(be, {"temperature": 0.0, "max_output_tokens": 100})
            self.assertEqual(cl.json("t", "sys", "user", SCHEMA), {"x": 3})
            self.assertEqual(seen[-1]["response_format"]["type"], "json_object")   # llama.cpp style
            n = len(seen)
            cl.json("t", "sys", "user", SCHEMA)
            self.assertEqual(len(seen), n + 1)             # mode remembered: single request now
            self.assertTrue(be.health()[0])
        finally:
            srv.shutdown(); srv.server_close()

    def test_repair_loop(self):
        replies = ["I think the answer is 5", '{"x": 5}']
        srv = serve(lambda body: ok(replies.pop(0)))
        try:
            be = OpenAICompatBackend("http://127.0.0.1:%d/v1" % srv.server_port, "m", schema_mode="none")
            cl = LLMClient(be, {"temperature": 0.0})
            self.assertEqual(cl.json("t", "s", "u", SCHEMA), {"x": 5})
            self.assertEqual(cl.stats["repairs"], 1)
        finally:
            srv.shutdown(); srv.server_close()

    def test_gives_up_with_format_error(self):
        srv = serve(lambda body: ok("nonsense"))
        try:
            be = OpenAICompatBackend("http://127.0.0.1:%d/v1" % srv.server_port, "m", schema_mode="none")
            with self.assertRaises(LLMFormatError):
                LLMClient(be, {}).json("t", "s", "u", SCHEMA, retries=1)
        finally:
            srv.shutdown(); srv.server_close()

    def test_unreachable_server_message(self):
        be = OpenAICompatBackend("http://127.0.0.1:9/v1", "m", timeout=2)
        with self.assertRaises(LLMError) as cm:
            be.chat([{"role": "user", "content": "hi"}])
        self.assertIn("Cannot reach", str(cm.exception))

    def test_gemma_system_merge(self):
        msgs = prepare_messages([{"role": "system", "content": "SYS"}, {"role": "user", "content": "U"}], "merge")
        self.assertEqual(len(msgs), 1)
        self.assertTrue(msgs[0]["content"].startswith("SYS") and msgs[0]["content"].endswith("U"))
        self.assertEqual(len(prepare_messages([{"role": "system", "content": "S"}, {"role": "user", "content": "U"}], "native")), 2)


if __name__ == "__main__":
    unittest.main()

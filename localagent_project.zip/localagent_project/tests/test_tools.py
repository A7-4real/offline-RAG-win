import tempfile
import unittest
from pathlib import Path

from localagent.artifacts import ArtifactStore
from localagent.config import Config
from localagent.memory import Memory
from localagent.skills import SkillLibrary
from localagent.state import TaskState
from localagent.tools import ToolContext, build_registry
from localagent.tools.docparse import parse_document_file
from localagent.tools.sandbox import Sandbox
from localagent.ui import SilentUI
from tests.helpers import ROOT, make_cfg, make_docx, make_pptx, make_xlsx


class ToolTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        t = Path(self.tmp.name)
        self.cfg = make_cfg(t)
        self.sb = Sandbox(self.cfg.workspace_path, "ask_risky", SilentUI().confirm, [ROOT / "skills"])
        self.ctx = ToolContext(self.cfg, self.sb, TaskState("t"), Memory(t / "data"),
                               ArtifactStore(t / "art"), SkillLibrary(ROOT / "skills"), SilentUI())
        self.reg = build_registry()

    def tearDown(self):
        self.tmp.cleanup()

    def run_tool(self, _tool, **args):
        return self.reg.execute(_tool, args, self.ctx)

    def test_write_read_edit_cycle(self):
        r = self.run_tool("write_file", path="a/hello.py", content="print('hi')\n")
        self.assertTrue(r.ok, r.output)
        self.assertFalse(self.run_tool("write_file", path="a/hello.py", content="x").ok)       # exists
        self.assertTrue(self.run_tool("write_file", path="a/hello.py", content="x=1\n", mode="overwrite").ok)
        e = self.run_tool("edit_file", path="a/hello.py", search="x=1", replace="x=2")
        self.assertTrue(e.ok, e.output)
        self.assertIn("x=2", self.run_tool("read_file", path="a/hello.py").output)
        bad = self.run_tool("edit_file", path="a/hello.py", search="nothere", replace="y")
        self.assertFalse(bad.ok)
        self.assertIn("a/hello.py", self.ctx.state.touched_files)

    def test_syntax_warning_on_write(self):
        r = self.run_tool("write_file", path="bad.py", content="def f(:\n")
        self.assertIn("syntax error", r.output.lower())

    def test_sandbox_escape_blocked(self):
        self.assertFalse(self.run_tool("write_file", path="../evil.txt", content="x").ok)
        self.assertFalse(self.run_tool("write_file", path="/tmp/evil.txt", content="x").ok)

    def test_bad_args_get_helpful_error(self):
        r = self.run_tool("read_file")
        self.assertFalse(r.ok)
        self.assertIn("Usage", r.output)
        self.assertTrue(self.run_tool("write_file", path="n.txt", content=5).ok)  # int coerced to str

    def test_shell_policy(self):
        self.assertFalse(self.run_tool("run_shell", command="rm -rf /").ok)
        self.assertIn("Blocked", self.run_tool("run_shell", command="rm -rf /").output)
        self.assertTrue(self.run_tool("run_shell", command="echo hello").ok)
        r = self.run_tool("run_shell", command="touch x.txt")            # needs approval, SilentUI says no
        self.assertFalse(r.ok)
        self.assertIn("approve", r.output)

    def test_python_tools(self):
        r = self.run_tool("run_python", code="print(2+3)")
        self.assertTrue(r.ok and "5" in r.output)
        self.assertFalse(self.run_tool("run_python", code="import os\nos.remove('x')").ok)   # risky -> gated
        self.assertFalse(self.run_tool("run_python", code="raise ValueError('boom')").ok)
        self.run_tool("write_file", path="m.py", content="def f(:\n")
        self.assertFalse(self.run_tool("python_check", path="m.py").ok)
        info = self.run_tool("py_introspect", module="json", name="dumps")
        self.assertIn("indent", info.output)

    def test_calc(self):
        self.assertEqual(self.run_tool("calc", expression="(12*7.5)/3").output, "30.0")
        self.assertFalse(self.run_tool("calc", expression="__import__('os')").ok)
        self.assertFalse(self.run_tool("calc", expression="9**99999").ok)

    def test_document_parsers(self):
        ws = self.cfg.workspace_path
        make_docx(ws / "s.docx"); make_xlsx(ws / "d.xlsx"); make_pptx(ws / "p.pptx")
        d = parse_document_file(ws / "s.docx")
        self.assertIn("# Spec Title", d)
        self.assertIn("| voltage | 28 |", d)
        self.assertIn("alice", parse_document_file(ws / "d.xlsx"))
        self.assertIn("bullet one", parse_document_file(ws / "p.pptx"))
        r = self.run_tool("parse_document", path="s.docx")
        self.assertTrue(r.ok)
        self.assertFalse(self.run_tool("parse_document", path="missing.pdf").ok)

    def test_artifacts_and_facts(self):
        aid = self.ctx.artifacts.save("alpha\nbeta voltage 28\ngamma")
        self.assertIn("voltage", self.run_tool("grep_artifact", id=aid, pattern="voltage").output)
        self.run_tool("remember_fact", key="v", value="28")
        self.assertEqual(self.ctx.state.facts["v"], "28")

    def test_skill_script_and_network(self):
        r = self.run_tool("run_skill_script", skill="networking", script="subnet_calc.py", args="192.168.1.10/24")
        self.assertTrue(r.ok and "255.255.255.0" in r.output, r.output)
        self.assertFalse(self.run_tool("run_skill_script", skill="networking", script="../x.py").ok)
        self.assertFalse(self.run_tool("local_http_get", url="http://example.com/").ok)   # not local
        self.assertFalse(self.run_tool("net_diag", kind="ping", target="a;b").ok)          # injection rejected

    def test_architect_script(self):
        import json
        spec = {"name": "Demo", "summary": "s", "components": [{"name": "UI"}, {"name": "API"}],
                "interfaces": [{"from": "UI", "to": "API", "protocol": "HTTP"}, {"from": "UI", "to": "DB"}]}
        (self.cfg.workspace_path / "d.json").write_text(json.dumps(spec), encoding="utf-8")
        r = self.run_tool("run_skill_script", skill="system_architect", script="render_architecture.py", args="d.json d.md")
        self.assertFalse(r.ok)                       # dangling interface detected
        self.assertIn("unknown component", r.output)
        self.assertIn("flowchart", (self.cfg.workspace_path / "d.md").read_text(encoding="utf-8"))

    def test_web_scripts(self):
        self.assertTrue(self.run_tool("run_skill_script", skill="web_dev", script="scaffold.py", args="static site").ok)
        r = self.run_tool("run_skill_script", skill="web_dev", script="validate_html.py", args="site/index.html")
        self.assertTrue(r.ok, r.output)
        r = self.run_tool("run_skill_script", skill="web_dev", script="serve_check.py", args="site / 8791")
        self.assertTrue(r.ok and "HTTP 200" in r.output, r.output)


if __name__ == "__main__":
    unittest.main()

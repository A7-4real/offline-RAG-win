"""Whole stack through the real CLI + HTTP path against a fake OpenAI-compatible server
(system prompt merged into the user turn, as for Gemma)."""
import contextlib
import io
import json
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

from localagent.cli import main
from tests.helpers import ROOT, act, plan

ACTIONS = [act("write_file", path="hello.txt", content="hi"), act("finish_step", success=True, result="written")]
REQUESTS = []


class Fake(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        self._reply({"data": [{"id": "gemma-fake"}]})

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        REQUESTS.append(body)
        text = "\n".join(m["content"] for m in body["messages"])
        if "You are the ROUTER" in text:
            out = {"skills": ["file_ops"]}
        elif "You are the PLANNER" in text:
            out = plan(("Create hello.txt", "write_file", "file_exists", "hello.txt"))
        elif "You are the EXECUTOR" in text:
            out = ACTIONS.pop(0)
        else:
            out = None
        content = json.dumps(out) if out is not None else "Created hello.txt with the text hi."
        self._reply({"choices": [{"message": {"content": content}}], "usage": {"prompt_tokens": 1, "completion_tokens": 1}})

    def _reply(self, payload):
        raw = json.dumps(payload).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)


class CliHttp(unittest.TestCase):
    def test_run_via_cli(self):
        srv = HTTPServer(("127.0.0.1", 0), Fake)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        try:
            with tempfile.TemporaryDirectory() as d:
                d = Path(d)
                cfg = {"base_url": "http://127.0.0.1:%d/v1" % srv.server_port, "model": "gemma-fake", "profile": "gemma-9b",
                       "workspace": str(d / "ws"), "data_dir": str(d / "data"), "skills_dir": str(ROOT / "skills"),
                       "knowledge_dir": str(d / "kb")}
                (d / "config.json").write_text(json.dumps(cfg), encoding="utf-8")
                buf = io.StringIO()
                with contextlib.redirect_stdout(buf):
                    rc = main(["run", "--config", str(d / "config.json"), "create a file hello.txt containing hi", "--yes"])
                out = buf.getvalue()
                self.assertEqual(rc, 0, out)
                self.assertEqual((d / "ws" / "hello.txt").read_text(encoding="utf-8"), "hi")
                self.assertIn("DONE", out)
                # Gemma profile: no 'system' role ever sent to the server
                self.assertTrue(all(m["role"] != "system" for r in REQUESTS for m in r["messages"]))
                # structured output was requested for JSON roles
                self.assertTrue(any("response_format" in r for r in REQUESTS))
        finally:
            srv.shutdown()
            srv.server_close()


if __name__ == "__main__":
    unittest.main()

import json
import tempfile
import unittest
from pathlib import Path

from localagent.llm import ScriptedBackend
from tests.helpers import act, make_agent, plan


class AgentE2E(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.t = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_happy_path_write_check_run(self):
        handlers = {
            "router": [{"skills": ["python_dev"]}],
            "planner": [plan(("Write hello.py that prints hi", "write_file", "file_exists", "hello.py"),
                             ("Run hello.py", "run_python", "output_contains", "hi"))],
            "actor": [
                act("write_file", path="hello.py", content="print('hi')\n"),
                act("python_check", path="hello.py"),
                act("finish_step", success=True, result="hello.py written"),
                act("run_python", path="hello.py"),
                act("finish_step", success=True, result="prints hi"),
            ],
            "reporter": "Created hello.py and ran it; it prints hi.",
        }
        agent, be, cfg = make_agent(self.t, handlers)
        st = agent.run("write a python script hello.py that prints hi and run it")
        self.assertEqual(st.status, "done", st.final)
        self.assertEqual([s.status for s in st.plan], ["done", "done"])
        self.assertTrue((cfg.workspace_path / "hello.py").exists())
        self.assertIn("hello.py", st.touched_files)
        self.assertEqual(st.actions_used, 3)
        self.assertIn("hello.py", st.final)
        run_dir = cfg.data_path / "runs" / st.run_id
        self.assertTrue((run_dir / "state.json").exists())
        self.assertTrue((run_dir / "trace.jsonl").exists())
        # actor prompts stay inside the token budget
        prof = cfg.profile_params()
        for c in be.calls:
            if c["role"] == "actor":
                size = sum(len(m["content"]) for m in c["messages"]) / prof["chars_per_token"]
                self.assertLess(size, prof["budget_tokens"] + 600)
        # the actor only ever sees allowed tools
        schema = [c for c in be.calls if c["role"] == "actor"][0]["schema"]
        names = {b["properties"]["tool"]["const"] for b in schema["anyOf"]}
        self.assertIn("run_python", names)
        self.assertNotIn("net_diag", names)

    def test_verification_catches_false_success(self):
        handlers = {
            "router": [{"skills": ["file_ops"]}],
            "planner": [plan(("Create notes.txt", "write_file", "file_exists", "notes.txt"))],
            "actor": [
                act("finish_step", success=True, result="done (but nothing was written)"),
                act("write_file", path="notes.txt", content="hello"),
                act("finish_step", success=True, result="written"),
            ],
            "reporter": "ok",
        }
        agent, be, cfg = make_agent(self.t, handlers)
        st = agent.run("create a text file notes.txt in the folder")
        self.assertEqual(st.status, "done", st.final)
        actor_prompts = [c["messages"][-1]["content"] for c in be.calls if c["role"] == "actor"]
        self.assertIn("VERIFICATION FAILED", actor_prompts[1])

    def test_loop_detection_reflect_and_replan(self):
        handlers = {
            "router": [{"skills": ["file_ops"]}],
            "planner": [plan(("Read missing.txt", "read_file", "last_tool_ok", "")),
                        plan(("Create missing.txt", "write_file", "file_exists", "missing.txt"))],
            "actor": [act("read_file", path="missing.txt")] * 3
                     + [act("write_file", path="missing.txt", content="x"),
                        act("finish_step", success=True, result="created")],
            "reflector": [{"error_class": "wrong_tool", "lesson": {"trigger": "file is missing", "advice": "create it with write_file"},
                           "next": "replan"}],
            "reporter": "recovered",
        }
        agent, be, cfg = make_agent(self.t, handlers)
        st = agent.run("read missing.txt")
        self.assertEqual(st.status, "done", st.final)
        self.assertEqual(st.replans, 1)
        self.assertEqual([s.status for s in st.plan], ["failed", "done"])
        self.assertTrue(agent.memory.search_lessons("file missing create"))      # lesson persisted
        planner_prompts = [c["messages"][-1]["content"] for c in be.calls if c["role"] == "planner"]
        self.assertIn("WHY IT FAILED", planner_prompts[1])

    def test_invalid_model_output_is_survived_then_aborts_step(self):
        handlers = {
            "router": [{"skills": ["file_ops"]}],
            "planner": [plan(("List files", "list_dir", "last_tool_ok", ""))],
            "actor": ["garbage", "more garbage", "still garbage", "nope", "no", "never"],
            "reflector": [{"error_class": "impossible", "lesson": {"trigger": "model output invalid", "advice": "simplify"},
                           "next": "abort"}],
            "reporter": "failed",
        }
        agent, be, cfg = make_agent(self.t, handlers)
        st = agent.run("list the files")
        self.assertEqual(st.status, "failed")
        self.assertGreaterEqual(agent.client.stats["repairs"], 2)

    def test_dangerous_command_blocked_even_when_model_asks(self):
        handlers = {
            "router": [{"skills": ["shell_cmd"]}],
            "planner": [plan(("Wipe disk", "run_shell", "last_tool_ok", ""))],
            "actor": [act("run_shell", command="rm -rf /"), act("finish_step", success=False, result="blocked")],
            "reflector": [{"error_class": "impossible", "lesson": {"trigger": "destructive command", "advice": "do not"}, "next": "abort"}],
            "reporter": "refused",
        }
        agent, be, cfg = make_agent(self.t, handlers)
        st = agent.run("delete everything with the shell")
        self.assertEqual(st.status, "failed")
        prompts = [c["messages"][-1]["content"] for c in be.calls if c["role"] == "actor"]
        self.assertIn("Blocked by safety policy", prompts[1])

    def test_fixed_plan_skill_skips_planner(self):
        sk = self.t / "skills" / "greeter"
        sk.mkdir(parents=True)
        (sk / "SKILL.md").write_text(
            "---\nname: greeter\ndescription: write greeting files\ntools: [write_file]\nkeywords: [greeting]\nplan_mode: fixed\n---\n"
            "## Workflow\n1. Write greeting.txt (tool: write_file) (check: file_exists: greeting.txt)\n", encoding="utf-8")
        handlers = {"actor": [act("write_file", path="greeting.txt", content="hi"),
                              act("finish_step", success=True, result="ok")], "reporter": "done"}
        agent, be, cfg = make_agent(self.t, handlers, skills_dir=str(self.t / "skills"))
        st = agent.run("make a greeting")
        self.assertEqual(st.status, "done", st.final)
        self.assertNotIn("planner", [c["role"] for c in be.calls])

    def test_big_output_spills_to_artifact_and_can_be_searched(self):
        big = "\n".join("row %d" % i if i != 77 else "row 77 SECRET=42" for i in range(1, 400))
        handlers = {
            "router": [{"skills": ["python_dev"]}],
            "planner": [plan(("Find the secret", "run_python", "none", ""))],
            "actor": [act("run_python", code="print(%r)" % big),
                      act("grep_artifact", id="A1", pattern="SECRET"),
                      act("finish_step", success=True, result="SECRET=42")],
            "judge": [{"verdict": "pass", "reason": "found"}],
            "reporter": "found",
        }
        agent, be, cfg = make_agent(self.t, handlers, autonomy="full")
        st = agent.run("run a python script and find the secret in its output")
        self.assertEqual(st.status, "done", st.final)
        prompts = [c["messages"][-1]["content"] for c in be.calls if c["role"] == "actor"]
        self.assertIn("saved as A1", prompts[1])
        self.assertIn("SECRET=42", prompts[2])

    def test_resume_state_roundtrip(self):
        from localagent.state import TaskState
        handlers = {"router": [{"skills": ["file_ops"]}], "planner": [plan(("List files", "list_dir", "last_tool_ok", ""))],
                    "actor": [act("list_dir"), act("finish_step", success=True, result="listed")], "reporter": "ok"}
        agent, be, cfg = make_agent(self.t, handlers)
        st = agent.run("list files")
        loaded = TaskState.load(cfg.data_path / "runs" / st.run_id / "state.json")
        self.assertEqual(loaded.status, "done")
        self.assertEqual(loaded.plan[0].status, "done")


if __name__ == "__main__":
    unittest.main()

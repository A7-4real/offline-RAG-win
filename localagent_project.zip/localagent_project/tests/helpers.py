import json
import tempfile
import zipfile
from pathlib import Path

from localagent.bootstrap import build_agent
from localagent.config import Config
from localagent.llm import ScriptedBackend
from localagent.ui import SilentUI

ROOT = Path(__file__).resolve().parent.parent


def make_cfg(tmp: Path, **over) -> Config:
    cfg = Config()
    cfg.base_dir = str(tmp)
    cfg.workspace = str(tmp / "ws")
    cfg.data_dir = str(tmp / "data")
    cfg.skills_dir = str(ROOT / "skills")
    cfg.knowledge_dir = str(tmp / "kb")
    cfg.backend = "scripted"
    for k, v in over.items():
        setattr(cfg, k, v)
    return cfg


def make_agent(tmp: Path, handlers, ui=None, **over):
    cfg = make_cfg(tmp, **over)
    be = ScriptedBackend(handlers)
    agent = build_agent(cfg, backend=be, ui=ui or SilentUI())
    return agent, be, cfg


def act(tool, thought="ok", **args):
    return {"thought": thought, "tool": tool, "args": args}


def plan(*steps):
    return {"steps": [{"goal": g, "tool_hint": t, "check": {"kind": k, "arg": a}} for g, t, k, a in steps]}


# ---- tiny OOXML builders (no third-party libs) --------------------------------
def make_docx(path: Path):
    ns = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"'
    body = ('<w:p><w:pPr><w:pStyle w:val="Heading1"/></w:pPr><w:r><w:t>Spec Title</w:t></w:r></w:p>'
            '<w:p><w:r><w:t>Intro paragraph.</w:t></w:r></w:p>'
            '<w:tbl>'
            '<w:tr><w:tc><w:tcPr><w:gridSpan w:val="2"/></w:tcPr><w:p><w:r><w:t>Group</w:t></w:r></w:p></w:tc></w:tr>'
            '<w:tr><w:tc><w:p><w:r><w:t>Field</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>Value</w:t></w:r></w:p></w:tc></w:tr>'
            '<w:tr><w:tc><w:p><w:r><w:t>voltage</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>28</w:t></w:r></w:p></w:tc></w:tr>'
            '</w:tbl>')
    xml = '<?xml version="1.0" encoding="UTF-8"?><w:document %s><w:body>%s</w:body></w:document>' % (ns, body)
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("word/document.xml", xml)


def make_xlsx(path: Path):
    ns = 'xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"'
    rns = 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"'
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("xl/workbook.xml", '<workbook %s %s><sheets><sheet name="Data" sheetId="1" r:id="rId1"/></sheets></workbook>' % (ns, rns))
        z.writestr("xl/_rels/workbook.xml.rels", '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Target="worksheets/sheet1.xml"/></Relationships>')
        z.writestr("xl/sharedStrings.xml", '<sst %s><si><t>name</t></si><si><t>alice</t></si></sst>' % ns)
        z.writestr("xl/worksheets/sheet1.xml", '<worksheet %s><sheetData><row r="1"><c r="A1" t="s"><v>0</v></c><c r="B1" t="s"><v>1</v></c></row><row r="2"><c r="A2"><v>42</v></c></row></sheetData></worksheet>' % ns)


def make_pptx(path: Path):
    p = 'xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"'
    slide = '<p:sld %s><p:cSld><p:spTree><p:sp><p:txBody><a:p><a:r><a:t>Slide Title</a:t></a:r></a:p><a:p><a:r><a:t>bullet one</a:t></a:r></a:p></p:txBody></p:sp></p:spTree></p:cSld></p:sld>' % p
    with zipfile.ZipFile(path, "w") as z:
        z.writestr("ppt/slides/slide1.xml", slide)

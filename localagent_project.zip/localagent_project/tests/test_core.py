import tempfile
import unittest
from pathlib import Path

from localagent.artifacts import ArtifactStore
from localagent.context import ContextAssembler, Slot, truncate
from localagent.jsonutil import JSONExtractError, extract_json
from localagent.memory import Memory
from localagent.schema import coerce, validate
from localagent.skills import SkillLibrary
from tests.helpers import ROOT


class JsonTests(unittest.TestCase):
    def test_extract_variants(self):
        self.assertEqual(extract_json('```json\n{"a": 1}\n```'), {"a": 1})
        self.assertEqual(extract_json('Sure! {"a": [1,2,],} thanks'), {"a": [1, 2]})
        self.assertEqual(extract_json("{'a': True}"), {"a": True})
        with self.assertRaises(JSONExtractError):
            extract_json("no json here")

    def test_validate_and_coerce(self):
        schema = {"anyOf": [
            {"type": "object", "properties": {"tool": {"const": "t"}, "args": {"type": "object", "properties": {"n": {"type": "integer"}}, "required": ["n"]}}, "required": ["tool", "args"]},
            {"type": "object", "properties": {"tool": {"const": "u"}}, "required": ["tool"]}]}
        obj = coerce({"tool": "t", "args": {"n": "5"}}, schema)
        self.assertEqual(obj["args"]["n"], 5)
        self.assertEqual(validate(obj, schema), [])
        errs = validate({"tool": "t", "args": {}}, schema)
        self.assertTrue(any("n: required" in e for e in errs), errs)
        self.assertTrue(validate({"tool": "zzz"}, schema))


class ContextTests(unittest.TestCase):
    def test_budget_and_priority(self):
        a = ContextAssembler(250, 3.3)
        text, rep = a.assemble([Slot("LOW", "x" * 4000, 1), Slot("HIGH", "keep me", 9, min_tokens=2),
                                Slot("TASK", "do it", 10, min_tokens=2)])
        self.assertIn("keep me", text)
        self.assertIn("do it", text)
        self.assertLessEqual(sum(rep.values()), 250)
        self.assertLess(rep.get("LOW", 0), 250)

    def test_truncate_modes(self):
        s = "a" * 100 + "b" * 100
        self.assertTrue(truncate(s, 50, "tail").startswith("a"))
        self.assertTrue(truncate(s, 50, "head").rstrip().endswith("b"))
        self.assertIn("omitted", truncate(s, 50, "middle"))


class MemoryTests(unittest.TestCase):
    def test_lessons_and_knowledge(self):
        with tempfile.TemporaryDirectory() as d:
            m = Memory(Path(d))
            m.add_lesson("run_shell", "dir command fails on linux", "use ls instead of dir")
            m.add_lesson("run_shell", "dir command fails on linux", "use ls instead of dir")  # dedupe
            self.assertEqual(m.stats()["lessons"], 1)
            hit = m.search_lessons("list directory with dir on linux")
            self.assertTrue(hit and "ls" in hit[0]["advice"])
            m.ingest_text("s", "ping", "ping -n 4 host windows\n\nping -c 4 host linux")
            self.assertTrue(m.search_knowledge("windows ping"))
            f = Path(d) / "x.md"
            f.write_text("# Ada\nwith Ada.Text_IO;", encoding="utf-8")
            self.assertGreater(m.ingest_file(f, "kb"), 0)
            self.assertEqual(m.ingest_file(f, "kb"), 0)   # unchanged -> skipped

    def test_artifacts(self):
        with tempfile.TemporaryDirectory() as d:
            a = ArtifactStore(Path(d))
            aid = a.save("\n".join("line %d voltage" % i if i == 7 else "line %d" % i for i in range(1, 50)))
            self.assertIn("line 7 voltage", a.grep(aid, "voltage"))
            self.assertIn("5| line 5", a.read(aid, 5, 6))
            with self.assertRaises(KeyError):
                a.read("A99")


class SkillTests(unittest.TestCase):
    def test_all_skills_load_and_route(self):
        lib = SkillLibrary(ROOT / "skills")
        self.assertEqual(lib.errors, [])
        self.assertGreaterEqual(len(lib.skills), 9)
        self.assertEqual(lib.candidates("compile this Ada program with gnat")[0].name, "ada_dev")
        self.assertEqual(lib.candidates("ping the gateway and check dns")[0].name, "networking")
        self.assertEqual(lib.candidates("extract tables from the pdf")[0].name, "doc_parsing")
        self.assertEqual(lib.candidates("build a langgraph workflow")[0].name, "langgraph_dev")


if __name__ == "__main__":
    unittest.main()

"""Code-first verification of step results. LLM judging is only the fallback."""
from __future__ import annotations

import subprocess
import sys
from typing import List, Optional, Tuple

from .tools.base import ToolError, ToolResult

CHECK_KINDS = ["none", "file_exists", "file_contains", "output_contains", "last_tool_ok",
               "python_compiles", "tests_pass"]


def run_check(kind: str, arg: str, ctx, results: List[ToolResult]) -> Tuple[Optional[bool], str]:
    """Return (True|False|None, reason). None = cannot decide in code."""
    arg = (arg or "").strip()
    try:
        if kind == "file_exists":
            if not arg:
                return None, "no path given"
            p = ctx.sandbox.resolve(arg)
            return (p.exists(), "%s %s" % (arg, "exists" if p.exists() else "does not exist"))
        if kind == "file_contains":
            if "::" not in arg:
                return None, "arg must be 'path::text'"
            path, text = arg.split("::", 1)
            p = ctx.sandbox.resolve(path.strip())
            if not p.exists():
                return False, "%s does not exist" % path
            found = text.strip().lower() in p.read_text(encoding="utf-8", errors="replace").lower()
            return found, "%s %s %r" % (path, "contains" if found else "does not contain", text.strip())
        if kind == "output_contains":
            if not arg:
                return None, "no text given"
            hit = any(arg.lower() in r.output.lower() for r in results)
            return hit, "expected text %r %s in tool output" % (arg, "found" if hit else "NOT found")
        if kind == "last_tool_ok":
            if not results:
                return False, "no tool was run in this step"
            return results[-1].ok, "last tool %s" % ("succeeded" if results[-1].ok else "failed: " + results[-1].output[:150])
        if kind == "python_compiles":
            if not arg:
                return None, "no path given"
            p = ctx.sandbox.resolve(arg)
            if not p.exists():
                return False, "%s does not exist" % arg
            try:
                compile(p.read_text(encoding="utf-8", errors="replace"), str(p), "exec")
                return True, "%s compiles" % arg
            except SyntaxError as e:
                return False, "%s has a syntax error line %s: %s" % (arg, e.lineno, e.msg)
        if kind == "tests_pass":
            target = ctx.sandbox.resolve(arg or ".")
            cp = subprocess.run([sys.executable, "-m", "pytest", "-x", "-q", str(target)], cwd=str(ctx.sandbox.workspace),
                                capture_output=True, timeout=ctx.cfg.python_timeout)
            if cp.returncode == 5 or b"No module named pytest" in cp.stderr:
                cp = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", str(target)],
                                    cwd=str(ctx.sandbox.workspace), capture_output=True, timeout=ctx.cfg.python_timeout)
            return cp.returncode == 0, "tests %s" % ("pass" if cp.returncode == 0 else
                                                      "FAIL: " + (cp.stdout + cp.stderr).decode("utf-8", "replace")[-300:])
    except ToolError as e:
        return False, str(e)
    except Exception as e:  # noqa: BLE001
        return None, "check error: %s" % e
    return None, "no code check"

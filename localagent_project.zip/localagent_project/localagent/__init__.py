"""localagent - an offline, skill-driven autonomous agent for small local LLMs."""
__version__ = "0.1.0"

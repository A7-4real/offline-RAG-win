"""Configuration + model profiles.

Everything model-specific lives in a *profile* (context size, prompt budget,
system-role handling...). Swapping the model or the inference server means
editing config.json only; no code changes.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict

DEFAULT_PROFILES: Dict[str, Dict[str, Any]] = {
    # Gemma has no native system role in its chat template -> merge into user turn.
    "gemma-9b": {
        "context_window": 8192, "budget_tokens": 5600, "max_output_tokens": 700,
        "temperature": 0.0, "system_role": "merge", "chars_per_token": 3.3,
    },
    "llama-8b": {
        "context_window": 8192, "budget_tokens": 6000, "max_output_tokens": 700,
        "temperature": 0.0, "system_role": "native", "chars_per_token": 3.5,
    },
    # Safe fallback for any other small model.
    "generic-small": {
        "context_window": 4096, "budget_tokens": 2800, "max_output_tokens": 500,
        "temperature": 0.0, "system_role": "merge", "chars_per_token": 3.2,
    },
    # Larger / more capable model: relax the budgets.
    "generic-large": {
        "context_window": 32768, "budget_tokens": 20000, "max_output_tokens": 1500,
        "temperature": 0.0, "system_role": "native", "chars_per_token": 3.6,
    },
}


@dataclass
class Config:
    # ---- inference ----------------------------------------------------
    backend: str = "openai_compat"          # openai_compat | llama_cpp_python | mock
    base_url: str = "http://127.0.0.1:1234/v1"   # LM Studio: 1234, llama.cpp server: 8080
    model: str = "gemma-2-9b-it"
    api_key: str = "not-needed"
    profile: str = "gemma-9b"
    schema_mode: str = "auto"               # auto | json_schema | json_object | llama_schema | none
    request_timeout: int = 900
    llama_cpp_model_path: str = ""          # only for backend=llama_cpp_python
    llama_cpp_n_gpu_layers: int = -1
    # ---- locations (relative paths resolve against the config file dir) ----
    workspace: str = "./workspace"
    data_dir: str = "./agent_data"
    skills_dir: str = "./skills"
    knowledge_dir: str = "./knowledge"
    # ---- behaviour ----------------------------------------------------
    autonomy: str = "ask_risky"             # readonly | ask_risky | full
    max_plan_steps: int = 8
    max_actions_per_step: int = 8
    max_replans: int = 2
    max_step_retries: int = 1
    max_total_actions: int = 60
    max_tools_per_step: int = 12
    shell_timeout: int = 60
    python_timeout: int = 120
    tool_output_chars: int = 1800           # inline cap before spilling to an artifact
    recent_full_observations: int = 2
    trace: bool = True
    profiles: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    base_dir: str = "."                     # set by load()

    # ------------------------------------------------------------------
    def profile_params(self) -> Dict[str, Any]:
        merged = dict(DEFAULT_PROFILES)
        for k, v in (self.profiles or {}).items():
            merged[k] = {**merged.get(k, DEFAULT_PROFILES["generic-small"]), **v}
        if self.profile not in merged:
            raise ValueError("Unknown profile %r. Known: %s" % (self.profile, ", ".join(sorted(merged))))
        return dict(merged[self.profile])

    def path(self, value: str) -> Path:
        p = Path(value).expanduser()
        if not p.is_absolute():
            p = Path(self.base_dir) / p
        return p.resolve()

    @property
    def workspace_path(self) -> Path:
        return self.path(self.workspace)

    @property
    def data_path(self) -> Path:
        return self.path(self.data_dir)

    @property
    def skills_path(self) -> Path:
        return self.path(self.skills_dir)

    @property
    def knowledge_path(self) -> Path:
        return self.path(self.knowledge_dir)

    # ------------------------------------------------------------------
    @classmethod
    def load(cls, path: str | None = None) -> "Config":
        cfg = cls()
        if path and os.path.exists(path):
            with open(path, "r", encoding="utf-8") as fh:
                raw = json.load(fh)
            known = {f for f in cls.__dataclass_fields__}  # type: ignore[attr-defined]
            for k, v in raw.items():
                if k in known:
                    setattr(cfg, k, v)
            cfg.base_dir = str(Path(path).resolve().parent)
        else:
            cfg.base_dir = os.getcwd()
        return cfg

    def save(self, path: str) -> None:
        data = asdict(self)
        data.pop("base_dir", None)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2)

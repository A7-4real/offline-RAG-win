"""In-process backend using llama-cpp-python (optional dependency)."""
from __future__ import annotations

from typing import Tuple

from .base import LLMBackend, LLMError, LLMResponse, prepare_messages


class LlamaCppPythonBackend(LLMBackend):
    name = "llama_cpp_python"
    enforces_schema = True

    def __init__(self, model_path: str, n_ctx: int = 8192, n_gpu_layers: int = -1, system_role: str = "merge"):
        try:
            from llama_cpp import Llama  # type: ignore
        except ImportError as e:  # pragma: no cover
            raise LLMError("llama-cpp-python is not installed (pip install llama-cpp-python)") from e
        if not model_path:
            raise LLMError("config.llama_cpp_model_path is empty")
        self._llm = Llama(model_path=str(model_path), n_ctx=n_ctx, n_gpu_layers=n_gpu_layers, verbose=False)
        self.system_role = system_role

    def chat(self, messages, *, schema=None, schema_name="response", temperature=0.0,
             max_tokens=512, stop=None, role="") -> LLMResponse:  # pragma: no cover
        kwargs = {}
        if schema:
            kwargs["response_format"] = {"type": "json_object", "schema": schema}
        out = self._llm.create_chat_completion(
            messages=prepare_messages(messages, self.system_role), temperature=temperature,
            max_tokens=max_tokens, stop=stop, **kwargs)
        usage = out.get("usage", {})
        return LLMResponse(text=out["choices"][0]["message"]["content"] or "",
                           prompt_tokens=usage.get("prompt_tokens", 0),
                           completion_tokens=usage.get("completion_tokens", 0), mode="llama_cpp_python")

    def health(self) -> Tuple[bool, str]:  # pragma: no cover
        return True, "in-process model loaded"

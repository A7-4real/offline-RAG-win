"""OpenAI-compatible HTTP backend (LM Studio, llama.cpp server, Ollama /v1, vLLM...).

Structured output is negotiated automatically: the first mode the server accepts is
remembered. If none works the client-side validate/repair loop still protects us.
"""
from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Dict, List, Optional, Tuple

from .base import LLMBackend, LLMError, LLMResponse, prepare_messages

_MODES = ("json_schema", "json_object", "llama_schema", "none")


class OpenAICompatBackend(LLMBackend):
    name = "openai_compat"

    def __init__(self, base_url: str, model: str, api_key: str = "not-needed",
                 timeout: int = 900, schema_mode: str = "auto", system_role: str = "native"):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.api_key = api_key
        self.timeout = timeout
        self.schema_mode = schema_mode
        self.system_role = system_role
        self._good_mode: Optional[str] = None
        self._bad_modes: set = set()

    @property
    def enforces_schema(self) -> bool:  # type: ignore[override]
        if self.schema_mode in ("json_schema", "json_object", "llama_schema"):
            return True
        return self._good_mode in ("json_schema", "json_object", "llama_schema")

    # -- http -----------------------------------------------------------
    def _request(self, method: str, path: str, payload: Optional[dict] = None) -> dict:
        url = self.base_url + path
        data = json.dumps(payload).encode("utf-8") if payload is not None else None
        req = urllib.request.Request(url, data=data, method=method)
        req.add_header("Content-Type", "application/json")
        if self.api_key:
            req.add_header("Authorization", "Bearer " + self.api_key)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read().decode("utf-8", "replace"))
        except urllib.error.HTTPError as e:
            body = ""
            try:
                body = e.read().decode("utf-8", "replace")[:500]
            except Exception:
                pass
            err = LLMError("HTTP %s from %s: %s" % (e.code, url, body))
            err.http_status = e.code  # type: ignore[attr-defined]
            raise err
        except urllib.error.URLError as e:
            raise LLMError("Cannot reach inference server at %s (%s). Is LM Studio / llama-server "
                           "running with its local server enabled?" % (self.base_url, e.reason))

    def health(self) -> Tuple[bool, str]:
        try:
            data = self._request("GET", "/models")
            ids = [m.get("id", "?") for m in data.get("data", [])]
            return True, "models: " + (", ".join(ids[:5]) or "(none listed)")
        except LLMError as e:
            return False, str(e)

    # -- chat -------------------------------------------------------------
    def _modes_to_try(self, schema: Optional[dict]) -> List[str]:
        if not schema:
            return ["none"]
        if self.schema_mode != "auto":
            return [self.schema_mode]
        if self._good_mode:
            return [self._good_mode]
        return [m for m in _MODES if m not in self._bad_modes]

    @staticmethod
    def _apply_mode(body: dict, mode: str, schema: Optional[dict], name: str) -> None:
        if mode == "json_schema":
            body["response_format"] = {"type": "json_schema",
                                       "json_schema": {"name": name, "strict": True, "schema": schema}}
        elif mode == "json_object":
            body["response_format"] = {"type": "json_object", "schema": schema}
        elif mode == "llama_schema":
            body["json_schema"] = schema

    def chat(self, messages, *, schema=None, schema_name="response", temperature=0.0,
             max_tokens=512, stop=None, role="") -> LLMResponse:
        msgs = prepare_messages(messages, self.system_role)
        last_err: Optional[Exception] = None
        for mode in self._modes_to_try(schema):
            body: Dict = {"model": self.model, "messages": msgs, "temperature": temperature,
                          "max_tokens": max_tokens, "stream": False}
            if stop:
                body["stop"] = stop
            self._apply_mode(body, mode, schema, schema_name)
            try:
                data = self._request("POST", "/chat/completions", body)
            except LLMError as e:
                status = getattr(e, "http_status", None)
                if schema and mode != "none" and status in (400, 404, 415, 422, 500, 501):
                    self._bad_modes.add(mode)
                    last_err = e
                    continue
                raise
            try:
                text = data["choices"][0]["message"].get("content") or ""
            except (KeyError, IndexError, TypeError):
                raise LLMError("Unexpected server reply: %s" % str(data)[:300])
            usage = data.get("usage") or {}
            if schema and self.schema_mode == "auto" and self._good_mode is None:
                self._good_mode = mode
            return LLMResponse(text=text, prompt_tokens=usage.get("prompt_tokens", 0),
                               completion_tokens=usage.get("completion_tokens", 0), mode=mode, raw=data)
        raise LLMError("No structured-output mode accepted by the server: %s" % last_err)

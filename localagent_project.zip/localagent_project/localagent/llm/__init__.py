from __future__ import annotations

from typing import Any, Callable, Dict, Optional

from ..config import Config
from .base import LLMBackend, LLMError, LLMResponse
from .client import LLMClient, LLMFormatError
from .mock import ScriptedBackend
from .openai_compat import OpenAICompatBackend


def create_backend(cfg: Config) -> LLMBackend:
    prof = cfg.profile_params()
    sysrole = prof.get("system_role", "native")
    if cfg.backend == "openai_compat":
        return OpenAICompatBackend(cfg.base_url, cfg.model, cfg.api_key, cfg.request_timeout,
                                   cfg.schema_mode, sysrole)
    if cfg.backend == "llama_cpp_python":
        from .llama_cpp_python import LlamaCppPythonBackend
        mp = cfg.path(cfg.llama_cpp_model_path) if cfg.llama_cpp_model_path else ""
        return LlamaCppPythonBackend(str(mp), prof.get("context_window", 8192), cfg.llama_cpp_n_gpu_layers, sysrole)
    raise LLMError("Unknown backend %r (use openai_compat or llama_cpp_python)" % cfg.backend)


def create_client(cfg: Config, backend: Optional[LLMBackend] = None,
                  trace: Optional[Callable[[Dict[str, Any]], None]] = None) -> LLMClient:
    return LLMClient(backend or create_backend(cfg), cfg.profile_params(), trace)

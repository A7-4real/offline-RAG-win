"""Scripted backend for tests and offline demos (no model needed)."""
from __future__ import annotations

import json
from typing import Any, Dict, List

from .base import LLMBackend, LLMResponse


class ScriptedBackend(LLMBackend):
    """handlers: role -> list (consumed in order) | callable(messages, schema) | str | dict."""
    name = "scripted"
    enforces_schema = True

    def __init__(self, handlers: Dict[str, Any], default: Any = None):
        self.handlers = handlers
        self.default = default
        self.calls: List[Dict[str, Any]] = []

    def chat(self, messages, *, schema=None, schema_name="response", temperature=0.0,
             max_tokens=512, stop=None, role="") -> LLMResponse:
        self.calls.append({"role": role, "messages": messages, "schema": schema})
        h = self.handlers.get(role, self.default)
        if isinstance(h, list):
            if not h:
                raise AssertionError("ScriptedBackend: no more scripted replies for role %r" % role)
            h = h.pop(0)
        if callable(h):
            h = h(messages, schema)
        if h is None:
            raise AssertionError("ScriptedBackend: no handler for role %r" % role)
        text = h if isinstance(h, str) else json.dumps(h)
        return LLMResponse(text=text, mode="scripted")

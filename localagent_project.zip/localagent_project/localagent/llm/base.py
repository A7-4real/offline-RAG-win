"""Backend interface. Everything above this layer is model/server agnostic."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class LLMResponse:
    text: str
    prompt_tokens: int = 0
    completion_tokens: int = 0
    mode: str = ""          # which structured-output mode actually worked
    raw: Any = None


class LLMError(RuntimeError):
    pass


def prepare_messages(messages: List[Dict[str, str]], system_role: str) -> List[Dict[str, str]]:
    """Gemma-style templates reject a system role: merge it into the first user turn."""
    if system_role != "merge":
        return messages
    out: List[Dict[str, str]] = []
    pending = ""
    for m in messages:
        if m["role"] == "system":
            pending += (m["content"] + "\n\n")
        elif m["role"] == "user" and pending:
            out.append({"role": "user", "content": pending + m["content"]})
            pending = ""
        else:
            out.append(m)
    if pending:
        out.insert(0, {"role": "user", "content": pending.strip()})
    return out


class LLMBackend:
    name = "base"
    enforces_schema = False

    def chat(self, messages: List[Dict[str, str]], *, schema: Optional[dict] = None,
             schema_name: str = "response", temperature: float = 0.0, max_tokens: int = 512,
             stop: Optional[List[str]] = None, role: str = "") -> LLMResponse:
        raise NotImplementedError

    def health(self) -> Tuple[bool, str]:
        return True, "n/a"

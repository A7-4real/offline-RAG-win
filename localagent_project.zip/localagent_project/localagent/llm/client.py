"""LLMClient: the only thing the agent talks to.

* applies the model profile (temperature, token limits)
* validates structured replies, coerces small slips, runs a repair loop
* records usage statistics and an optional JSONL trace
"""
from __future__ import annotations

import time
from typing import Any, Callable, Dict, Optional

from ..jsonutil import JSONExtractError, extract_json
from ..schema import coerce, validate
from .base import LLMBackend, LLMError


class LLMFormatError(LLMError):
    pass


class LLMClient:
    def __init__(self, backend: LLMBackend, profile: Dict[str, Any],
                 trace: Optional[Callable[[Dict[str, Any]], None]] = None):
        self.backend = backend
        self.profile = profile
        self._trace = trace
        self.stats = {"calls": 0, "repairs": 0, "prompt_tokens": 0, "completion_tokens": 0, "seconds": 0.0}

    def set_trace(self, fn: Optional[Callable[[Dict[str, Any]], None]]) -> None:
        self._trace = fn

    # ------------------------------------------------------------------
    def _call(self, role: str, system: str, user: str, schema: Optional[dict],
              max_tokens: Optional[int], schema_name: str):
        messages = [{"role": "system", "content": system}, {"role": "user", "content": user}]
        t0 = time.time()
        resp = self.backend.chat(
            messages, schema=schema, schema_name=schema_name,
            temperature=self.profile.get("temperature", 0.0),
            max_tokens=max_tokens or self.profile.get("max_output_tokens", 600), role=role)
        dt = time.time() - t0
        self.stats["calls"] += 1
        self.stats["seconds"] += dt
        self.stats["prompt_tokens"] += resp.prompt_tokens
        self.stats["completion_tokens"] += resp.completion_tokens
        if self._trace:
            self._trace({"ts": time.time(), "role": role, "seconds": round(dt, 2),
                         "system": system, "user": user, "reply": resp.text, "mode": resp.mode,
                         "tokens": [resp.prompt_tokens, resp.completion_tokens]})
        return resp

    def text(self, role: str, system: str, user: str, max_tokens: Optional[int] = None) -> str:
        return self._call(role, system, user, None, max_tokens, "text").text.strip()

    def json(self, role: str, system: str, user: str, schema: dict, *, max_tokens: Optional[int] = None,
             retries: int = 2, schema_name: str = "response") -> Any:
        extra = ""
        if not getattr(self.backend, "enforces_schema", False):
            extra = "\n\nReply with ONE JSON object only, no prose, no code fences."
        prompt = user + extra
        last_problem = ""
        for _ in range(retries + 1):
            resp = self._call(role, system, prompt, schema, max_tokens, schema_name)
            try:
                obj = extract_json(resp.text)
                obj = coerce(obj, schema)
                errs = validate(obj, schema)
                if not errs:
                    return obj
                last_problem = "; ".join(errs[:4])
            except JSONExtractError as e:
                last_problem = str(e)
            self.stats["repairs"] += 1
            prompt = (user + extra + "\n\n[Your previous reply was rejected: %s]\n[Previous reply: %s]\n"
                      "Reply again with corrected JSON only." % (last_problem, resp.text[:300].replace("\n", " ")))
        raise LLMFormatError("Model did not produce valid JSON for role %r: %s" % (role, last_problem))

"""Command line interface."""
from __future__ import annotations

import argparse
import importlib.util
import os
import shutil
import sqlite3
import sys
from pathlib import Path

from .bootstrap import build_agent, ingest_knowledge
from .config import Config
from .llm import LLMError, create_backend
from .memory import Memory
from .skills import SkillLibrary
from .state import TaskState
from .tools import build_registry
from .ui import ConsoleUI


def _cfg(args) -> Config:
    path = args.config if os.path.exists(args.config) else None
    cfg = Config.load(path)
    for attr in ("model", "base_url", "backend", "profile", "workspace", "autonomy", "schema_mode"):
        v = getattr(args, attr, None)
        if v:
            setattr(cfg, attr, v)
    if getattr(args, "yes", False):
        cfg.autonomy = "full"
    if getattr(args, "max_actions", None):
        cfg.max_total_actions = args.max_actions
    return cfg


def cmd_run(args) -> int:
    cfg = _cfg(args)
    ui = ConsoleUI(interactive=not args.yes and sys.stdin.isatty(), quiet=args.quiet)
    try:
        agent = build_agent(cfg, ui=ui)
    except LLMError as e:
        print("Backend error:", e)
        return 2
    resume = None
    if args.resume:
        sp = cfg.data_path / "runs" / args.resume / "state.json"
        if not sp.exists():
            print("No saved run %s" % args.resume)
            return 2
        resume = TaskState.load(sp)
        task = resume.task
    else:
        task = " ".join(args.task).strip()
        if not task:
            print("Give a task, e.g.: python run_agent.py run \"Summarise spec.pdf into notes.md\"")
            return 2
    state = agent.run(task, resume)
    print("\n=== %s ===\n%s" % (state.status.upper(), state.final))
    print("\n(run id: %s | LLM calls: %d, repairs: %d, %d actions)" % (
        state.run_id, agent.client.stats["calls"], agent.client.stats["repairs"], state.actions_used))
    return 0 if state.status == "done" else 1


def cmd_ingest(args) -> int:
    cfg = _cfg(args)
    mem = Memory(cfg.data_path)
    root = Path(args.path)
    if root.is_file():
        from .bootstrap import _reader
        n = mem.ingest_file(root, args.source, _reader)
    else:
        n = ingest_knowledge(mem, root, args.source)
    print("Indexed %d new chunks. Memory: %s" % (n, mem.stats()))
    return 0


def cmd_skills(args) -> int:
    cfg = _cfg(args)
    lib = SkillLibrary(cfg.skills_path)
    for sk in lib.skills.values():
        print("%-18s %s\n%18s tools: %s | scripts: %s" % (sk.name, sk.description, "", ", ".join(sk.tools),
                                                         ", ".join(sk.scripts()) or "-"))
    for e in lib.errors:
        print("SKILL ERROR:", e)
    return 0


def cmd_tools(args) -> int:
    reg = build_registry()
    for n in reg.names():
        t = reg.get(n)
        print("%-16s [%-5s] %s" % (n, t.tier, t.desc))
    return 0


def cmd_init(args) -> int:
    if os.path.exists(args.config) and not args.force:
        print("%s already exists (use --force to overwrite)" % args.config)
        return 1
    Config().save(args.config)
    print("Wrote %s - edit base_url/model/profile for your inference server." % args.config)
    return 0


def cmd_doctor(args) -> int:
    cfg = _cfg(args)
    ok = True
    print("Python %s on %s" % (sys.version.split()[0], sys.platform))
    try:
        c = sqlite3.connect(":memory:")
        c.execute("CREATE VIRTUAL TABLE t USING fts5(a)")
        print("[ok] SQLite FTS5 available (%s)" % sqlite3.sqlite_version)
    except sqlite3.OperationalError:
        print("[warn] SQLite FTS5 missing: memory search falls back to slower LIKE matching")
    for mod, why in [("pypdf", "PDF text"), ("pdfplumber", "PDF tables"), ("fitz", "PDF (PyMuPDF)"),
                     ("pytest", "run_tests"), ("pyflakes", "lint"), ("llama_cpp", "in-process model")]:
        print("[%s] %-11s %s" % ("ok" if importlib.util.find_spec(mod) else "--", mod, why))
    for exe in ("gnatmake", "gprbuild", "git", "node", "pdftotext", "soffice", "tesseract"):
        print("[%s] %-11s %s" % ("ok" if shutil.which(exe) else "--", exe, "on PATH"))
    lib = SkillLibrary(cfg.skills_path)
    print("[ok] %d skills loaded from %s" % (len(lib.skills), cfg.skills_path))
    for e in lib.errors:
        ok = False
        print("[FAIL] skill error:", e)
    print("Profile %s: %s" % (cfg.profile, cfg.profile_params()))
    if cfg.backend == "mock":
        return 0
    try:
        b = create_backend(cfg)
        good, msg = b.health()
        print("[%s] backend %s @ %s -> %s" % ("ok" if good else "FAIL", cfg.backend, cfg.base_url, msg))
        ok = ok and good
    except LLMError as e:
        print("[FAIL] backend:", e)
        ok = False
    return 0 if ok else 1


def cmd_selftest(args) -> int:
    import unittest
    root = Path(__file__).resolve().parent.parent / "tests"
    suite = unittest.defaultTestLoader.discover(str(root), top_level_dir=str(root.parent))
    res = unittest.TextTestRunner(verbosity=1).run(suite)
    return 0 if res.wasSuccessful() else 1


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="localagent", description="Offline autonomous agent for small local LLMs")
    ap.add_argument("--config", default="config.json")
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--config", default=argparse.SUPPRESS, help="path to config.json (default ./config.json)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    r = sub.add_parser("run", help="run a task", parents=[common])
    r.add_argument("task", nargs="*")
    r.add_argument("--resume", metavar="RUN_ID")
    r.add_argument("--yes", action="store_true", help="full autonomy: no confirmation prompts (denylist still applies)")
    r.add_argument("--quiet", action="store_true")
    r.add_argument("--max-actions", type=int, dest="max_actions")
    for opt in ("model", "base-url", "backend", "profile", "workspace", "autonomy", "schema-mode"):
        r.add_argument("--" + opt)
    r.set_defaults(fn=cmd_run)

    i = sub.add_parser("ingest", help="index offline docs (md/txt/pdf/docx/code) for search_docs", parents=[common])
    i.add_argument("path")
    i.add_argument("--source", default="kb")
    i.set_defaults(fn=cmd_ingest)

    sub.add_parser("skills", help="list skills", parents=[common]).set_defaults(fn=cmd_skills)
    sub.add_parser("tools", help="list tools", parents=[common]).set_defaults(fn=cmd_tools)
    sub.add_parser("doctor", help="check environment + inference server", parents=[common]).set_defaults(fn=cmd_doctor)
    sub.add_parser("selftest", help="run the offline test-suite (no model needed)").set_defaults(fn=cmd_selftest)
    n = sub.add_parser("init", help="write a default config.json", parents=[common])
    n.add_argument("--force", action="store_true")
    n.set_defaults(fn=cmd_init)

    args = ap.parse_args(argv)
    return args.fn(args)


if __name__ == "__main__":
    sys.exit(main())

"""Context management: token estimation, truncation, priority-based prompt assembly."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple


def est_tokens(text: str, chars_per_token: float = 3.3) -> int:
    return int(len(text) / chars_per_token) + 1


def truncate(text: str, max_chars: int, mode: str = "tail") -> str:
    """Shorten *text* to roughly max_chars. mode: tail (keep start), head (keep end), middle."""
    if max_chars <= 0:
        return ""
    if len(text) <= max_chars:
        return text
    omitted = len(text) - max_chars
    mark = "\n...[%d chars omitted]...\n" % omitted
    if mode == "head":
        return "...[%d chars omitted]...\n" % omitted + text[-max_chars:]
    if mode == "middle":
        h = max_chars // 2
        return text[:h] + mark + text[-(max_chars - h):]
    return text[:max_chars] + "\n...[%d chars omitted]..." % omitted


@dataclass
class Slot:
    name: str
    text: str
    priority: int = 5            # higher = kept longer
    max_tokens: Optional[int] = None
    min_tokens: int = 0          # never shrunk below this (unless dropped when min_tokens == 0)
    trim: str = "tail"           # tail | head | middle


class ContextAssembler:
    """Builds one prompt from named slots under a hard token budget."""

    def __init__(self, budget_tokens: int, chars_per_token: float = 3.3):
        self.budget = budget_tokens
        self.cpt = chars_per_token

    def _tok(self, s: str) -> int:
        return est_tokens(s, self.cpt) if s else 0

    def assemble(self, slots: List[Slot]) -> Tuple[str, Dict[str, int]]:
        work = [Slot(s.name, s.text or "", s.priority, s.max_tokens, s.min_tokens, s.trim) for s in slots]
        for s in work:                                   # per-slot caps
            if s.max_tokens is not None and self._tok(s.text) > s.max_tokens:
                s.text = truncate(s.text, int(s.max_tokens * self.cpt), s.trim)
        guard = 0
        while sum(self._tok(s.text) + 4 for s in work if s.text) > self.budget and guard < 200:
            guard += 1
            total = sum(self._tok(s.text) + 4 for s in work if s.text)
            over = total - self.budget
            shrinkable = [s for s in work if s.text and self._tok(s.text) > max(s.min_tokens, 8)]
            if shrinkable:
                victim = min(shrinkable, key=lambda s: s.priority)
                cur = self._tok(victim.text)
                new_tokens = max(victim.min_tokens, 8, cur - max(over, cur // 4))
                victim.text = truncate(victim.text, int(new_tokens * self.cpt), victim.trim)
                continue
            droppable = [s for s in work if s.text and s.min_tokens == 0]
            if not droppable:
                break
            min(droppable, key=lambda s: s.priority).text = ""
        parts, report = [], {}
        for s in work:
            if s.text:
                parts.append("## %s\n%s" % (s.name, s.text.strip()))
                report[s.name] = self._tok(s.text)
        return "\n\n".join(parts), report

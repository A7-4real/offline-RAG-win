"""Tiny dependency-free JSON-schema subset: validate + lenient coercion.

Supported keywords: type, enum, const, properties, required, items, anyOf, oneOf,
minLength, maxLength, minItems, maxItems, minimum, maximum, additionalProperties(False).
"""
from __future__ import annotations

from typing import Any, List

_TYPES = {
    "string": str, "boolean": bool, "array": list, "object": dict, "null": type(None),
}


def _type_ok(inst: Any, t: str) -> bool:
    if t == "integer":
        return isinstance(inst, int) and not isinstance(inst, bool)
    if t == "number":
        return isinstance(inst, (int, float)) and not isinstance(inst, bool)
    if t == "boolean":
        return isinstance(inst, bool)
    return isinstance(inst, _TYPES[t])


def validate(inst: Any, schema: dict, path: str = "$") -> List[str]:
    errs: List[str] = []
    if not isinstance(schema, dict) or not schema:
        return errs
    for key in ("anyOf", "oneOf"):
        if key in schema:
            branches = schema[key]
            best: List[str] | None = None
            for br in branches:
                e = validate(inst, br, path)
                if not e:
                    return errs
                # prefer the branch whose discriminator ("tool") matches
                if isinstance(inst, dict) and isinstance(br.get("properties"), dict):
                    disc = br["properties"].get("tool", {}).get("const")
                    if disc is not None and disc == inst.get("tool"):
                        best = e
                        break
                if best is None or len(e) < len(best):
                    best = e
            return (best or ["%s: matches none of the allowed shapes" % path])
    if "const" in schema and inst != schema["const"]:
        errs.append("%s: must be %r" % (path, schema["const"]))
        return errs
    if "enum" in schema and inst not in schema["enum"]:
        errs.append("%s: must be one of %s" % (path, schema["enum"]))
        return errs
    t = schema.get("type")
    if t:
        types = t if isinstance(t, list) else [t]
        if not any(_type_ok(inst, x) for x in types):
            errs.append("%s: expected %s, got %s" % (path, "/".join(types), type(inst).__name__))
            return errs
    if isinstance(inst, str):
        if "minLength" in schema and len(inst) < schema["minLength"]:
            errs.append("%s: too short" % path)
        if "maxLength" in schema and len(inst) > schema["maxLength"]:
            errs.append("%s: too long (max %d chars)" % (path, schema["maxLength"]))
    if isinstance(inst, (int, float)) and not isinstance(inst, bool):
        if "minimum" in schema and inst < schema["minimum"]:
            errs.append("%s: must be >= %s" % (path, schema["minimum"]))
        if "maximum" in schema and inst > schema["maximum"]:
            errs.append("%s: must be <= %s" % (path, schema["maximum"]))
    if isinstance(inst, list):
        if "minItems" in schema and len(inst) < schema["minItems"]:
            errs.append("%s: needs at least %d items" % (path, schema["minItems"]))
        if "maxItems" in schema and len(inst) > schema["maxItems"]:
            errs.append("%s: at most %d items" % (path, schema["maxItems"]))
        item_schema = schema.get("items")
        if item_schema:
            for i, it in enumerate(inst):
                errs.extend(validate(it, item_schema, "%s[%d]" % (path, i)))
    if isinstance(inst, dict):
        props = schema.get("properties", {})
        for r in schema.get("required", []):
            if r not in inst:
                errs.append("%s.%s: required" % (path, r))
        for k, v in inst.items():
            if k in props:
                errs.extend(validate(v, props[k], "%s.%s" % (path, k)))
            elif schema.get("additionalProperties") is False:
                errs.append("%s.%s: unknown field" % (path, k))
    return errs


def coerce(inst: Any, schema: dict) -> Any:
    """Best-effort fix of common small-model slips (numbers as strings, etc.)."""
    if not isinstance(schema, dict):
        return inst
    for key in ("anyOf", "oneOf"):
        if key in schema:
            for br in schema[key]:
                if isinstance(inst, dict) and isinstance(br.get("properties"), dict):
                    disc = br["properties"].get("tool", {}).get("const")
                    if disc is not None and disc == inst.get("tool"):
                        return coerce(inst, br)
            return inst
    t = schema.get("type")
    if t == "integer" and isinstance(inst, (str, float)) and not isinstance(inst, bool):
        try:
            f = float(inst)
            if f == int(f):
                return int(f)
        except (ValueError, TypeError):
            return inst
    if t == "number" and isinstance(inst, str):
        try:
            return float(inst)
        except ValueError:
            return inst
    if t == "boolean" and isinstance(inst, str):
        low = inst.strip().lower()
        if low in ("true", "yes", "1"):
            return True
        if low in ("false", "no", "0"):
            return False
    if t == "string" and isinstance(inst, (int, float)) and not isinstance(inst, bool):
        return str(inst)
    if t == "array" and not isinstance(inst, list) and inst is not None:
        return [coerce(inst, schema.get("items", {}))]
    if isinstance(inst, dict):
        props = schema.get("properties", {})
        return {k: coerce(v, props[k]) if k in props else v for k, v in inst.items()}
    if isinstance(inst, list) and schema.get("items"):
        return [coerce(x, schema["items"]) for x in inst]
    return inst

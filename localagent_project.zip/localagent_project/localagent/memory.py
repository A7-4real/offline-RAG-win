"""Persistent memory in one SQLite file (stdlib only).

* episodes  - one row per finished run
* lessons   - short "when X happens do Y" notes, retrieved by BM25 (FTS5) at planning/acting time
* knowledge - chunked offline documents (cheat-sheets, manuals, skill references) for search_docs
"""
from __future__ import annotations

import hashlib
import re
import sqlite3
import time
from pathlib import Path
from typing import Dict, Iterable, List, Optional

_TOKEN = re.compile(r"[A-Za-z0-9_]{2,}")
_STOP = set("the and for with that this from into are was not you your have has can will use using then than "
            "what when how why who all any but its out get set make".split())


def _tokens(text: str, limit: int = 14) -> List[str]:
    seen, out = set(), []
    for t in _TOKEN.findall(text.lower()):
        if t in _STOP or t in seen:
            continue
        seen.add(t)
        out.append(t)
        if len(out) >= limit:
            break
    return out


def chunk_text(text: str, size: int = 900) -> List[str]:
    """Split on headings / blank lines into ~size-char chunks."""
    blocks = re.split(r"\n(?=#{1,4} )|\n\s*\n", text)
    chunks, cur = [], ""
    for b in blocks:
        b = b.strip("\n")
        if not b.strip():
            continue
        if len(cur) + len(b) + 2 <= size:
            cur = (cur + "\n\n" + b) if cur else b
        else:
            if cur:
                chunks.append(cur)
            while len(b) > size:
                chunks.append(b[:size])
                b = b[size:]
            cur = b
    if cur:
        chunks.append(cur)
    return chunks


class Memory:
    def __init__(self, data_dir: Path):
        data_dir = Path(data_dir)
        data_dir.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(str(data_dir / "memory.db"), check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.fts = self._init()

    def _init(self) -> bool:
        c = self.db
        c.executescript("""
        CREATE TABLE IF NOT EXISTS episodes(id INTEGER PRIMARY KEY, ts REAL, task TEXT, outcome TEXT, summary TEXT);
        CREATE TABLE IF NOT EXISTS lessons(id INTEGER PRIMARY KEY, ts REAL, tool TEXT, trigger TEXT, advice TEXT, uses INTEGER DEFAULT 1);
        CREATE TABLE IF NOT EXISTS knowledge(id INTEGER PRIMARY KEY, source TEXT, title TEXT, text TEXT);
        CREATE TABLE IF NOT EXISTS sources(source TEXT PRIMARY KEY, path TEXT, hash TEXT, ts REAL);
        """)
        try:
            c.executescript("""
            CREATE VIRTUAL TABLE IF NOT EXISTS lessons_fts USING fts5(tool, trigger, advice);
            CREATE VIRTUAL TABLE IF NOT EXISTS knowledge_fts USING fts5(title, text, source UNINDEXED);
            """)
            c.commit()
            return True
        except sqlite3.OperationalError:
            c.commit()
            return False

    # ---- episodes ------------------------------------------------------
    def add_episode(self, task: str, outcome: str, summary: str) -> None:
        self.db.execute("INSERT INTO episodes(ts,task,outcome,summary) VALUES(?,?,?,?)",
                        (time.time(), task, outcome, summary))
        self.db.commit()

    def recent_episodes(self, k: int = 5) -> List[Dict]:
        return [dict(r) for r in self.db.execute("SELECT * FROM episodes ORDER BY id DESC LIMIT ?", (k,))]

    # ---- lessons ---------------------------------------------------------
    def add_lesson(self, tool: str, trigger: str, advice: str) -> int:
        trigger, advice = trigger.strip()[:200], advice.strip()[:300]
        if not trigger or not advice:
            return 0
        row = self.db.execute("SELECT id FROM lessons WHERE tool=? AND trigger=? AND advice=?",
                              (tool, trigger, advice)).fetchone()
        if row:
            self.db.execute("UPDATE lessons SET uses=uses+1 WHERE id=?", (row["id"],))
            self.db.commit()
            return row["id"]
        cur = self.db.execute("INSERT INTO lessons(ts,tool,trigger,advice) VALUES(?,?,?,?)",
                              (time.time(), tool, trigger, advice))
        if self.fts:
            self.db.execute("INSERT INTO lessons_fts(rowid,tool,trigger,advice) VALUES(?,?,?,?)",
                            (cur.lastrowid, tool, trigger, advice))
        self.db.commit()
        return cur.lastrowid

    def search_lessons(self, query: str, k: int = 3) -> List[Dict]:
        toks = _tokens(query)
        if not toks:
            return []
        if self.fts:
            q = " OR ".join('"%s"' % t for t in toks)
            try:
                rows = self.db.execute(
                    "SELECT l.*, bm25(lessons_fts) AS r FROM lessons_fts JOIN lessons l ON l.id=lessons_fts.rowid "
                    "WHERE lessons_fts MATCH ? ORDER BY r LIMIT ?", (q, k)).fetchall()
                return [dict(r) for r in rows]
            except sqlite3.OperationalError:
                pass
        scored = []
        for r in self.db.execute("SELECT * FROM lessons"):
            blob = (r["tool"] + " " + r["trigger"] + " " + r["advice"]).lower()
            s = sum(1 for t in toks if t in blob)
            if s:
                scored.append((s, dict(r)))
        scored.sort(key=lambda x: -x[0])
        return [d for _, d in scored[:k]]

    # ---- knowledge -------------------------------------------------------
    def clear_source(self, source: str) -> None:
        ids = [r["id"] for r in self.db.execute("SELECT id FROM knowledge WHERE source=?", (source,))]
        for i in ids:
            if self.fts:
                self.db.execute("DELETE FROM knowledge_fts WHERE rowid=?", (i,))
        self.db.execute("DELETE FROM knowledge WHERE source=?", (source,))
        self.db.commit()

    def ingest_text(self, source: str, title: str, text: str, chunk_chars: int = 900) -> int:
        n = 0
        for ch in chunk_text(text, chunk_chars):
            cur = self.db.execute("INSERT INTO knowledge(source,title,text) VALUES(?,?,?)", (source, title, ch))
            if self.fts:
                self.db.execute("INSERT INTO knowledge_fts(rowid,title,text,source) VALUES(?,?,?,?)",
                                (cur.lastrowid, title, ch, source))
            n += 1
        self.db.commit()
        return n

    def ingest_file(self, path: Path, source: str, reader=None) -> int:
        """(Re)index one file if its content hash changed. *reader(path)->str* handles pdf/docx..."""
        path = Path(path)
        key = "%s::%s" % (source, path.name)
        raw = path.read_bytes()
        h = hashlib.sha1(raw).hexdigest()
        row = self.db.execute("SELECT hash FROM sources WHERE source=?", (key,)).fetchone()
        if row and row["hash"] == h:
            return 0
        text = reader(path) if reader else raw.decode("utf-8", "replace")
        self.clear_source(key)
        n = self.ingest_text(key, path.name, text)
        self.db.execute("INSERT OR REPLACE INTO sources(source,path,hash,ts) VALUES(?,?,?,?)",
                        (key, str(path), h, time.time()))
        self.db.commit()
        return n

    def search_knowledge(self, query: str, k: int = 4) -> List[Dict]:
        toks = _tokens(query)
        if not toks:
            return []
        if self.fts:
            q = " OR ".join('"%s"' % t for t in toks)
            try:
                rows = self.db.execute(
                    "SELECT title, text, source, bm25(knowledge_fts, 4.0, 1.0, 0.0) AS r FROM knowledge_fts "
                    "WHERE knowledge_fts MATCH ? ORDER BY r LIMIT ?", (q, k)).fetchall()
                return [dict(r) for r in rows]
            except sqlite3.OperationalError:
                pass
        scored = []
        for r in self.db.execute("SELECT title,text,source FROM knowledge"):
            blob = (r["title"] + " " + r["text"]).lower()
            s = sum(blob.count(t) for t in toks)
            if s:
                scored.append((s, dict(r)))
        scored.sort(key=lambda x: -x[0])
        return [d for _, d in scored[:k]]

    def stats(self) -> Dict[str, int]:
        q = lambda t: self.db.execute("SELECT COUNT(*) FROM %s" % t).fetchone()[0]
        return {"episodes": q("episodes"), "lessons": q("lessons"), "knowledge_chunks": q("knowledge"),
                "fts5": int(self.fts)}

"""Wire everything together."""
from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

from .agent import Agent
from .config import Config
from .llm import LLMBackend, create_client
from .memory import Memory
from .skills import SkillLibrary
from .tools import build_registry
from .tools.docparse import parse_document_file
from .tools.sandbox import Sandbox
from .ui import ConsoleUI

KB_EXT = {".md", ".txt", ".rst", ".py", ".ads", ".adb", ".ada", ".json", ".csv", ".html", ".htm",
          ".docx", ".pdf", ".pptx", ".xlsx", ".c", ".h", ".cpp", ".js", ".yaml", ".yml", ".toml", ".ini", ".cfg"}


def _reader(path: Path) -> str:
    return parse_document_file(path)


def ingest_knowledge(memory: Memory, root: Path, source: str = "kb") -> int:
    n = 0
    if not root.exists():
        return 0
    for f in sorted(root.rglob("*")):
        if f.is_file() and f.suffix.lower() in KB_EXT and f.name.lower() != "readme.md":
            try:
                n += memory.ingest_file(f, source, _reader)
            except Exception as e:  # noqa: BLE001
                print("  (skipped %s: %s)" % (f.name, e))
    return n


def build_agent(cfg: Config, backend: Optional[LLMBackend] = None, ui: Any = None) -> Agent:
    ui = ui or ConsoleUI()
    data = cfg.data_path
    data.mkdir(parents=True, exist_ok=True)
    memory = Memory(data)
    library = SkillLibrary(cfg.skills_path)
    library.index_references(memory, _reader)
    ingest_knowledge(memory, cfg.knowledge_path)
    sandbox = Sandbox(cfg.workspace_path, cfg.autonomy, ui.confirm,
                      read_roots=[cfg.skills_path, cfg.knowledge_path, data])
    registry = build_registry()
    client = create_client(cfg, backend)
    return Agent(cfg, client, memory, library, registry, ui, sandbox)

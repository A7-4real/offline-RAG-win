"""Console UI: progress output, confirmations, questions."""
from __future__ import annotations

import sys
from typing import Any, Optional


def _safe(s: str) -> str:
    enc = getattr(sys.stdout, "encoding", None) or "utf-8"
    return s.encode(enc, "replace").decode(enc, "replace")


class ConsoleUI:
    def __init__(self, interactive: Optional[bool] = None, quiet: bool = False):
        self.interactive = sys.stdin.isatty() if interactive is None else interactive
        self.quiet = quiet

    def say(self, msg: str) -> None:
        if not self.quiet:
            print(_safe(msg), flush=True)

    def action(self, tool: str, args: dict, res: Any) -> None:
        if self.quiet:
            return
        a = ", ".join("%s=%s" % (k, repr(v)[:40]) for k, v in list(args.items())[:3])
        first = (res.output.strip().splitlines() or [""])[0][:110]
        print(_safe("   %s %s(%s) -> %s" % ("+" if res.ok else "x", tool, a, first)), flush=True)

    def confirm(self, prompt: str) -> bool:
        if not self.interactive:
            return False
        try:
            return input(_safe("\n[approval needed] %s\nAllow? [y/N] " % prompt)).strip().lower() in ("y", "yes")
        except EOFError:
            return False

    def ask(self, question: str) -> Optional[str]:
        if not self.interactive:
            return None
        try:
            return input(_safe("\n[agent asks] %s\n> " % question)).strip()
        except EOFError:
            return None


class SilentUI(ConsoleUI):
    def __init__(self, answers=None, approve: bool = False):
        super().__init__(interactive=False, quiet=True)
        self.answers = list(answers or [])
        self.approve = approve

    def confirm(self, prompt: str) -> bool:
        return self.approve

    def ask(self, question: str):
        return self.answers.pop(0) if self.answers else None

"""Workspace jail + command policy + confirmation gate."""
from __future__ import annotations

import os
import re
import shlex
from pathlib import Path
from typing import Callable, List, Optional

from .base import ToolError

_DENY = [
    r"\brm\s+(-[a-z]*\s+)*-[a-z]*[rf][a-z]*\s+(/|~|\*|\.\.|[a-z]:)",
    r"\bmkfs\b", r"\bdd\s+if=", r">\s*/dev/sd", r"\bformat\s+[a-z]:", r"\bdiskpart\b",
    r"\bshutdown\b", r"\breboot\b", r"\bpoweroff\b", r"\bhalt\b", r"\breg\s+delete\b",
    r"\bbcdedit\b", r"\btakeown\b", r"\bcipher\s+/w", r"\bnet\s+user\b", r":\(\)\s*\{",
    r"\bdel\s+(/[a-z]\s+)*[a-z]:\\?\s*$", r"\b(rd|rmdir)\s+(/[a-z]\s+)*[a-z]:\\?\s*$",
    r"remove-item\s+.*-recurse.*\b[a-z]:\\?\s*$", r"\bchmod\s+-r\s+777\s+/", r"\bchown\s+-r\s+.*\s+/\s*$",
]
_DENY_RX = [re.compile(p, re.I) for p in _DENY]

# first tokens that are read-only enough to run without asking
_SAFE_FIRST = set("""dir type echo cd where whoami hostname ipconfig ping tracert nslookup netstat arp route
systeminfo tasklist ver findstr tree more sort date time vol getmac pathping nbtstat
ls cat pwd grep find head tail wc ip ss traceroute tracepath uname df du ps which dig host id env printenv
lsblk lscpu free uptime stat file sort uniq cut tr basename dirname realpath ifconfig hostname
python python3 pip pip3 gnat gnatmake gnatls gcc node npm git""".split())
_SAFE_GIT = {"status", "log", "diff", "show", "branch", "--version"}
_CHAIN = re.compile(r"[&|;<>`]|\$\(")


class Sandbox:
    def __init__(self, workspace: Path, autonomy: str = "ask_risky",
                 confirm: Optional[Callable[[str], bool]] = None, read_roots: Optional[List[Path]] = None):
        self.workspace = Path(workspace).resolve()
        self.workspace.mkdir(parents=True, exist_ok=True)
        (self.workspace / ".scratch").mkdir(exist_ok=True)
        self.autonomy = autonomy
        self._confirm = confirm
        self.read_roots = [Path(p).resolve() for p in (read_roots or [])]

    # -- paths ------------------------------------------------------------
    @staticmethod
    def _inside(p: Path, root: Path) -> bool:
        try:
            p.relative_to(root)
            return True
        except ValueError:
            return False

    def resolve(self, path: str, write: bool = False) -> Path:
        if not path or not str(path).strip():
            raise ToolError("path is empty")
        p = Path(os.path.expandvars(os.path.expanduser(str(path))))
        if not p.is_absolute():
            p = self.workspace / p
        p = p.resolve()
        if self._inside(p, self.workspace):
            return p
        if not write and any(self._inside(p, r) for r in self.read_roots):
            return p
        if not write and self.autonomy == "full":
            return p
        raise ToolError("Path %s is outside the workspace (%s). Use a path inside the workspace%s."
                        % (p, self.workspace, "" if write else " or one of the read-only roots"))

    def rel(self, p: Path) -> str:
        try:
            return str(p.relative_to(self.workspace)).replace("\\", "/")
        except ValueError:
            return str(p)

    # -- commands ------------------------------------------------------
    def command_verdict(self, cmd: str) -> str:
        """deny | allow | ask"""
        for rx in _DENY_RX:
            if rx.search(cmd):
                return "deny"
        stripped = cmd.replace("2>&1", "")
        if _CHAIN.search(stripped):
            return "ask"
        try:
            toks = shlex.split(stripped, posix=(os.name != "nt"))
        except ValueError:
            return "ask"
        if not toks:
            return "deny"
        first = os.path.basename(toks[0]).lower()
        first = re.sub(r"\.(exe|cmd|bat)$", "", first)
        if first == "git":
            return "allow" if len(toks) > 1 and toks[1] in _SAFE_GIT else "ask"
        if first in ("pip", "pip3", "npm"):
            return "allow" if any(t in ("list", "--version", "show", "freeze") for t in toks[1:]) else "ask"
        if first == "find" and any(t in ("-delete", "-exec", "-execdir") for t in toks):
            return "ask"
        if first in _SAFE_FIRST:
            return "allow"
        return "ask"

    def gate(self, what: str, verdict: str = "ask") -> None:
        """Raise ToolError unless the action is permitted under the autonomy setting."""
        if verdict == "deny":
            raise ToolError("Blocked by safety policy: %s" % what)
        if verdict == "allow":
            return
        if self.autonomy == "full":
            return
        if self.autonomy == "readonly":
            raise ToolError("Autonomy is 'readonly': %s is not permitted." % what)
        if self._confirm is not None and self._confirm(what):
            return
        raise ToolError("Not permitted (user did not approve): %s. Choose a safer way or ask_user." % what)

"""Agent-internal tools: memory, artifacts, calculator, user questions, documents, skill scripts."""
from __future__ import annotations

import ast
import math
import operator
import shlex
import subprocess
import sys
from pathlib import Path

from .base import Param, Tool, ToolError, ToolRegistry, ToolResult
from .docparse import parse_document_file, parse_page_spec
from .shell import _fmt, _run

_BIN = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv,
        ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod, ast.Pow: operator.pow}
_UN = {ast.USub: operator.neg, ast.UAdd: operator.pos}
_FUN = {k: getattr(math, k) for k in ("sqrt", "sin", "cos", "tan", "asin", "acos", "atan", "log", "log10", "log2",
                                       "exp", "floor", "ceil", "factorial", "gcd", "radians", "degrees", "hypot")}
_FUN.update({"abs": abs, "round": round, "min": min, "max": max, "sum": sum, "int": int, "float": float, "pow": pow})
_CONST = {"pi": math.pi, "e": math.e}


def _eval(node):
    if isinstance(node, ast.Expression):
        return _eval(node.body)
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in _BIN:
        a, b = _eval(node.left), _eval(node.right)
        if isinstance(node.op, ast.Pow) and abs(b) > 10000:
            raise ToolError("exponent too large")
        return _BIN[type(node.op)](a, b)
    if isinstance(node, ast.UnaryOp) and type(node.op) in _UN:
        return _UN[type(node.op)](_eval(node.operand))
    if isinstance(node, ast.Name) and node.id in _CONST:
        return _CONST[node.id]
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in _FUN and not node.keywords:
        return _FUN[node.func.id](*[_eval(a) for a in node.args])
    if isinstance(node, (ast.Tuple, ast.List)):
        return [_eval(x) for x in node.elts]
    raise ToolError("unsupported expression element: %s" % type(node).__name__)


def calc(ctx, expression: str) -> str:
    try:
        return str(_eval(ast.parse(expression.strip(), mode="eval")))
    except ToolError:
        raise
    except ZeroDivisionError:
        raise ToolError("division by zero")
    except (SyntaxError, ValueError, TypeError, OverflowError) as e:
        raise ToolError("cannot evaluate %r: %s" % (expression, e))


def remember_fact(ctx, key: str, value: str) -> str:
    ctx.state.facts[key.strip()[:60]] = value.strip()[:300]
    return "Saved fact %s." % key


def read_artifact(ctx, id: str, start_line: int = 1, end_line: int = 0) -> str:
    try:
        return ctx.artifacts.read(id, start_line, end_line or None)
    except KeyError as e:
        raise ToolError(str(e))


def grep_artifact(ctx, id: str, pattern: str) -> str:
    try:
        return ctx.artifacts.grep(id, pattern)
    except KeyError as e:
        raise ToolError(str(e))


def search_docs(ctx, query: str) -> str:
    rows = ctx.memory.search_knowledge(query, k=3)
    if not rows:
        return "No offline documentation matched %r. Try other keywords." % query
    return "\n\n".join("[%s | %s]\n%s" % (r["source"].split("::")[0], r["title"], r["text"][:700]) for r in rows)


def save_lesson(ctx, trigger: str, advice: str, tool: str = "") -> str:
    ctx.memory.add_lesson(tool, trigger, advice)
    return "Lesson stored."


def ask_user(ctx, question: str) -> ToolResult:
    ans = ctx.ui.ask(question) if ctx.ui is not None else None
    if ans is None:
        return ToolResult(False, "No user is available to answer. Make a sensible assumption, record it with "
                                 "remember_fact, and continue.")
    return ToolResult(True, "User answered: %s" % ans)


def parse_document(ctx, path: str, pages: str = "") -> ToolResult:
    p = ctx.sandbox.resolve(path)
    if not p.exists():
        raise ToolError("File not found: %s" % path)
    try:
        spec = parse_page_spec(pages)
    except ValueError:
        raise ToolError("pages must look like '1-3,5'")
    try:
        text = parse_document_file(p, spec)
    except ToolError:
        raise
    except Exception as e:  # noqa: BLE001
        raise ToolError("Could not parse %s: %s: %s" % (path, type(e).__name__, e))
    if not text.strip():
        return ToolResult(False, "No text found in %s (scanned/image-only? OCR needed)." % path)
    return ToolResult(True, text[:3_000_000])


def run_skill_script(ctx, skill: str, script: str, args: str = "") -> ToolResult:
    sk = ctx.skills.get(skill) if ctx.skills else None
    if sk is None:
        raise ToolError("Unknown skill %r" % skill)
    if "/" in script or "\\" in script or not script.endswith(".py"):
        raise ToolError("script must be a .py file name inside the skill's scripts folder")
    sp = sk.path / "scripts" / script
    if not sp.exists():
        have = ", ".join(x.name for x in (sk.path / "scripts").glob("*.py")) if (sk.path / "scripts").exists() else "none"
        raise ToolError("Skill %s has no script %s. Available: %s" % (skill, script, have))
    argv = [sys.executable, str(sp)] + (shlex.split(args, posix=(sys.platform != "win32")) if args.strip() else [])
    try:
        cp = _run(argv, ctx.sandbox.workspace, ctx.cfg.python_timeout, False)
    except subprocess.TimeoutExpired:
        return ToolResult(False, "script timed out")
    return _fmt(cp)


def _finish_placeholder(ctx, **kw):  # intercepted by the agent loop
    return "finish handled by the agent"


def register(reg: ToolRegistry) -> None:
    P = Param
    reg.register(Tool("finish_step", "Call when the current step is done (success=true) or impossible (success=false).",
                      [P("success", "boolean"), P("result", desc="what was achieved / found, 1-2 sentences",
                                                  max_length=400)], _finish_placeholder, "meta"))
    reg.register(Tool("parse_document", "Extract text+tables from pdf/docx/pptx/xlsx/csv/html/json/zip.", [
        P("path"), P("pages", desc="e.g. 1-3,5 (pdf pages / slides)", required=False, default="")],
        parse_document, "read", 'parse_document(path="spec.pdf", pages="1-5")'))
    reg.register(Tool("remember_fact", "Pin a short fact (name/value) so it stays visible in later steps.", [
        P("key"), P("value")], remember_fact, "meta"))
    reg.register(Tool("read_artifact", "Read lines of a saved big output, e.g. A3.", [
        P("id", desc="artifact id like A3"), P("start_line", "integer", "", False, 1),
        P("end_line", "integer", "", False, 0)], read_artifact, "read"))
    reg.register(Tool("grep_artifact", "Regex-search inside a saved big output, e.g. A3.", [
        P("id"), P("pattern")], grep_artifact, "read", 'grep_artifact(id="A3", pattern="voltage")'))
    reg.register(Tool("search_docs", "Search offline documentation/cheat-sheets/manuals.", [P("query")],
                      search_docs, "read", 'search_docs(query="windows ping options")'))
    reg.register(Tool("save_lesson", "Store a reusable lesson (when X happens, do Y).", [
        P("trigger"), P("advice"), P("tool", required=False, default="")], save_lesson, "meta"))
    reg.register(Tool("ask_user", "Ask the human a question (only if essential info is missing).", [P("question")],
                      ask_user, "meta"))
    reg.register(Tool("calc", "Evaluate a math expression exactly (use instead of mental math).", [P("expression")],
                      calc, "read", 'calc(expression="(12*7.5)/3")'))
    reg.register(Tool("run_skill_script", "Run a helper script shipped with a skill.", [
        P("skill"), P("script", desc="file name in scripts/"), P("args", required=False, default="")],
        run_skill_script, "exec"))

"""Tool framework: declarative params -> JSON schema, validation, safe execution."""
from __future__ import annotations

import traceback
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from ..schema import coerce, validate


class ToolError(Exception):
    """Raised by tools for expected, model-fixable problems (message is shown to the model)."""


@dataclass
class ToolResult:
    ok: bool
    output: str
    data: Optional[dict] = None


@dataclass
class Param:
    name: str
    type: str = "string"            # string | integer | number | boolean
    desc: str = ""
    required: bool = True
    default: Any = None
    enum: Optional[List[str]] = None
    max_length: Optional[int] = None


@dataclass
class Tool:
    name: str
    desc: str
    params: List[Param]
    func: Callable[..., Any]
    tier: str = "read"              # read | write | exec | net | meta
    example: str = ""
    spill: bool = True              # big outputs are saved as artifacts unless False

    def args_schema(self) -> dict:
        props: Dict[str, dict] = {}
        for p in self.params:
            d: Dict[str, Any] = {"type": p.type}
            if p.enum:
                d["enum"] = list(p.enum)
            if p.max_length and p.type == "string":
                d["maxLength"] = p.max_length
            props[p.name] = d
        return {"type": "object", "properties": props,
                "required": [p.name for p in self.params if p.required]}

    def card(self) -> str:
        parts = []
        for p in self.params:
            s = "%s:%s" % (p.name, p.type if not p.enum else "|".join(p.enum))
            if not p.required:
                s += "=%r" % (p.default,)
            parts.append(s)
        line = "- %s(%s) - %s" % (self.name, ", ".join(parts), self.desc)
        if self.example:
            line += "\n  e.g. " + self.example
        return line


class ToolRegistry:
    def __init__(self):
        self._tools: Dict[str, Tool] = {}

    def register(self, tool: Tool) -> Tool:
        self._tools[tool.name] = tool
        return tool

    def get(self, name: str) -> Optional[Tool]:
        return self._tools.get(name)

    def names(self) -> List[str]:
        return list(self._tools)

    def cards(self, names: List[str]) -> str:
        return "\n".join(self._tools[n].card() for n in names if n in self._tools)

    def action_schema(self, names: List[str]) -> dict:
        """anyOf one object per allowed tool: the model cannot name a tool that is not allowed."""
        branches = []
        for n in names:
            t = self._tools.get(n)
            if not t:
                continue
            branches.append({
                "type": "object",
                "properties": {"thought": {"type": "string", "maxLength": 240},
                               "tool": {"const": n},
                               "args": t.args_schema()},
                "required": ["thought", "tool", "args"]})
        return {"anyOf": branches}

    def execute(self, name: str, args: Dict[str, Any], ctx: Any) -> ToolResult:
        tool = self._tools.get(name)
        if tool is None:
            return ToolResult(False, "Unknown tool %r. Available: %s" % (name, ", ".join(self.names())))
        schema = tool.args_schema()
        args = coerce(dict(args or {}), schema)
        for p in tool.params:                       # fill defaults
            if p.name not in args and not p.required:
                args[p.name] = p.default
        errs = validate(args, schema, "args")
        if errs:
            return ToolResult(False, "Bad arguments for %s: %s\nUsage: %s" % (name, "; ".join(errs[:4]), tool.card()))
        try:
            out = tool.func(ctx, **args)
            if isinstance(out, ToolResult):
                return out
            return ToolResult(True, str(out))
        except ToolError as e:
            return ToolResult(False, str(e))
        except Exception as e:  # noqa: BLE001 - never crash the agent loop
            tb = traceback.format_exc(limit=2)
            return ToolResult(False, "Tool %s crashed: %s: %s\n%s" % (name, type(e).__name__, e, tb[-400:]))

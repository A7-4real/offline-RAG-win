from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

from .base import Param, Tool, ToolError, ToolRegistry, ToolResult
from . import files, meta, network, shell

CORE_TOOLS = ["finish_step", "read_file", "list_dir", "search_docs", "read_artifact", "grep_artifact",
              "remember_fact", "calc", "ask_user"]


@dataclass
class ToolContext:
    cfg: Any
    sandbox: Any
    state: Any = None
    memory: Any = None
    artifacts: Any = None
    skills: Any = None
    ui: Any = None


def build_registry() -> ToolRegistry:
    reg = ToolRegistry()
    files.register(reg)
    shell.register(reg)
    network.register(reg)
    meta.register(reg)
    for n in ("read_file", "read_artifact", "grep_artifact", "list_dir", "search_docs", "grep", "find_files",
              "py_introspect"):
        t = reg.get(n)
        if t:
            t.spill = False
    return reg

"""Shell / Python execution tools (Windows + Linux aware)."""
from __future__ import annotations

import importlib
import importlib.util
import inspect
import os
import platform
import re
import shlex
import shutil
import subprocess
import sys
from pathlib import Path

from .base import Param, Tool, ToolError, ToolRegistry, ToolResult

IS_WIN = os.name == "nt"
_RISKY_PY = re.compile(r"shutil\.rmtree|os\.remove|os\.unlink|os\.rmdir|subprocess|os\.system|socket|ctypes|"
                       r"winreg|\bexec\(|__import__|send2trash|requests|urllib|http\.client|ftplib|smtplib|"
                       r"os\.popen|os\.kill|os\.chmod|os\.rename|shutil\.move", re.I)


def _run(cmd, cwd: Path, timeout: int, shell: bool) -> subprocess.CompletedProcess:
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUTF8"] = "1"
    return subprocess.run(cmd, cwd=str(cwd), shell=shell, capture_output=True, timeout=timeout, env=env)


def _decode(b: bytes) -> str:
    if not b:
        return ""
    try:
        return b.decode("utf-8")
    except UnicodeDecodeError:
        return b.decode("cp1252" if IS_WIN else "latin-1", "replace")


def _fmt(cp: subprocess.CompletedProcess, limit: int = 20000) -> ToolResult:
    out, err = _decode(cp.stdout), _decode(cp.stderr)
    text = ""
    if out.strip():
        text += out.rstrip()
    if err.strip():
        text += ("\n[stderr]\n" if text else "[stderr]\n") + err.rstrip()
    text = (text or "(no output)")[:limit]
    return ToolResult(cp.returncode == 0, "%s\n[exit code %d]" % (text, cp.returncode))


def run_shell(ctx, command: str, timeout: int = 0, cwd: str = ".") -> ToolResult:
    ctx.sandbox.gate("run shell command: %s" % command[:160], ctx.sandbox.command_verdict(command))
    wd = ctx.sandbox.resolve(cwd)
    if not wd.is_dir():
        raise ToolError("cwd %s is not a directory" % cwd)
    t = timeout or ctx.cfg.shell_timeout
    try:
        cp = _run(command, wd, t, True)
    except subprocess.TimeoutExpired:
        return ToolResult(False, "Command timed out after %ds. Use a shorter command or a larger timeout." % t)
    return _fmt(cp)


def os_info(ctx) -> str:
    tools = ["python", "pip", "git", "gnatmake", "gprbuild", "gcc", "node", "npm", "pdftotext", "soffice",
             "tesseract", "powershell", "pwsh", "curl", "ping"]
    found = [t for t in tools if shutil.which(t)]
    return ("OS: %s %s (%s)\nShell: %s\nPython: %s (%s)\nWorkspace: %s\nTools on PATH: %s" % (
        platform.system(), platform.release(), platform.machine(),
        "cmd.exe (Windows)" if IS_WIN else os.environ.get("SHELL", "sh"),
        platform.python_version(), sys.executable, ctx.sandbox.workspace, ", ".join(found) or "none"))


def run_python(ctx, code: str = "", path: str = "", args: str = "", timeout: int = 0) -> ToolResult:
    if not code.strip() and not path.strip():
        raise ToolError("Give either code=<python source> or path=<script.py>.")
    t = timeout or ctx.cfg.python_timeout
    if code.strip():
        if _RISKY_PY.search(code):
            ctx.sandbox.gate("run Python code that touches processes/network/deletes: %s" %
                             code.strip().splitlines()[0][:100], "ask")
        scratch = ctx.sandbox.workspace / ".scratch"
        scratch.mkdir(exist_ok=True)
        n = len(list(scratch.glob("run_*.py"))) + 1
        script = scratch / ("run_%d.py" % n)
        script.write_text(code, encoding="utf-8")
    else:
        script = ctx.sandbox.resolve(path)
        if not script.exists():
            raise ToolError("script not found: %s" % path)
        src = script.read_text(encoding="utf-8", errors="replace")
        if _RISKY_PY.search(src):
            ctx.sandbox.gate("run script %s (touches processes/network/deletes)" % path, "ask")
    argv = [sys.executable, str(script)] + (shlex.split(args, posix=not IS_WIN) if args.strip() else [])
    try:
        cp = _run(argv, ctx.sandbox.workspace, t, False)
    except subprocess.TimeoutExpired:
        return ToolResult(False, "Python script timed out after %ds." % t)
    return _fmt(cp)


def python_check(ctx, path: str) -> ToolResult:
    p = ctx.sandbox.resolve(path)
    if not p.exists():
        raise ToolError("file not found: %s" % path)
    try:
        compile(p.read_text(encoding="utf-8", errors="replace"), str(p), "exec")
    except SyntaxError as e:
        return ToolResult(False, "SyntaxError line %s col %s: %s\n> %s" % (e.lineno, e.offset, e.msg,
                                                                              (e.text or "").strip()))
    msg = "Syntax OK."
    for mod in ("pyflakes", "ruff"):
        if importlib.util.find_spec(mod):
            argv = [sys.executable, "-m", mod] + (["check"] if mod == "ruff" else []) + [str(p)]
            cp = _run(argv, ctx.sandbox.workspace, 60, False)
            out = (_decode(cp.stdout) + _decode(cp.stderr)).strip()
            if out:
                return ToolResult(False, "Syntax OK but %s reports:\n%s" % (mod, out[:1500]))
            msg += " %s: clean." % mod
            break
    return ToolResult(True, msg)


def run_tests(ctx, path: str = ".") -> ToolResult:
    p = ctx.sandbox.resolve(path)
    if importlib.util.find_spec("pytest"):
        argv = [sys.executable, "-m", "pytest", "-x", "-q", "--no-header", str(p)]
    else:
        d = p if p.is_dir() else p.parent
        argv = [sys.executable, "-m", "unittest", "discover", "-s", str(d), "-v"] if p.is_dir() else \
               [sys.executable, "-m", "unittest", str(p)]
    try:
        cp = _run(argv, ctx.sandbox.workspace, ctx.cfg.python_timeout, False)
    except subprocess.TimeoutExpired:
        return ToolResult(False, "tests timed out")
    return _fmt(cp, 6000)


def py_introspect(ctx, module: str, name: str = "") -> str:
    """Show real API of an installed module - better than the model's stale memory."""
    if not re.match(r"^[A-Za-z_][\w\.]*$", module):
        raise ToolError("invalid module name")
    try:
        mod = importlib.import_module(module)
    except Exception as e:  # noqa: BLE001
        raise ToolError("Cannot import %s: %s: %s" % (module, type(e).__name__, e))
    if not name:
        ver = getattr(mod, "__version__", "?")
        items = []
        for n in sorted(dir(mod)):
            if n.startswith("_"):
                continue
            obj = getattr(mod, n, None)
            kind = "class" if inspect.isclass(obj) else "func" if callable(obj) else "mod" if inspect.ismodule(obj) else "var"
            doc = (inspect.getdoc(obj) or "").split("\n")[0][:70] if kind != "var" else ""
            items.append("%s %s  %s" % (kind, n, doc))
        return "%s version %s\n%s" % (module, ver, "\n".join(items[:70]))
    obj = mod
    for part in name.split("."):
        if not hasattr(obj, part):
            raise ToolError("%s has no attribute %r" % (module, name))
        obj = getattr(obj, part)
    try:
        sig = str(inspect.signature(obj))
    except (TypeError, ValueError):
        sig = "(...)"
    doc = (inspect.getdoc(obj) or "(no docstring)")[:1200]
    out = "%s.%s%s\n%s" % (module, name, sig, doc)
    if inspect.isclass(obj):
        methods = [m for m in dir(obj) if not m.startswith("_") and callable(getattr(obj, m, None))]
        out += "\nMethods: " + ", ".join(methods[:40])
    return out


def register(reg: ToolRegistry) -> None:
    P = Param
    reg.register(Tool("run_shell", "Run one shell command (cmd.exe on Windows, sh on Linux) in the workspace.", [
        P("command"), P("timeout", "integer", "seconds, 0=default", False, 0), P("cwd", required=False, default=".")],
        run_shell, "exec", 'run_shell(command="dir")'))
    reg.register(Tool("os_info", "Show OS, shell, Python and which tools exist on PATH.", [], os_info, "read"))
    reg.register(Tool("run_python", "Run Python code (code=...) or a script (path=...); returns output + exit code.", [
        P("code", required=False, default=""), P("path", required=False, default=""),
        P("args", required=False, default=""), P("timeout", "integer", "", False, 0)], run_python, "exec"))
    reg.register(Tool("python_check", "Check a .py file for syntax errors (and lint if available).", [P("path")],
                      python_check, "read"))
    reg.register(Tool("run_tests", "Run pytest/unittest on a file or folder.", [
        P("path", required=False, default=".")], run_tests, "exec"))
    reg.register(Tool("py_introspect", "Show the real API (names/signatures/docs) of an installed Python module.", [
        P("module", desc="e.g. langgraph.graph"), P("name", desc="optional attribute", required=False, default="")],
        py_introspect, "read", 'py_introspect(module="langgraph.graph", name="StateGraph")'))

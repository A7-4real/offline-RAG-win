"""Document parsing. docx/pptx/xlsx are parsed with the stdlib (zip+XML) so they work with zero
dependencies; pdf uses pypdf / pdfplumber / PyMuPDF / pdftotext, whichever is available."""
from __future__ import annotations

import csv
import io
import json
import re
import shutil
import subprocess
import zipfile
import xml.etree.ElementTree as ET
from html.parser import HTMLParser
from pathlib import Path
from typing import List, Optional, Set

from .base import ToolError
from .files import read_text_any

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
P_NS = "{http://schemas.openxmlformats.org/presentationml/2006/main}"
S = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"


def parse_page_spec(spec: str) -> Optional[Set[int]]:
    spec = (spec or "").strip()
    if not spec:
        return None
    out: Set[int] = set()
    for part in spec.split(","):
        part = part.strip()
        if "-" in part:
            a, b = part.split("-", 1)
            out.update(range(int(a), int(b) + 1))
        elif part:
            out.add(int(part))
    return out


def _md_table(rows: List[List[str]]) -> str:
    if not rows:
        return ""
    width = max(len(r) for r in rows)
    rows = [r + [""] * (width - len(r)) for r in rows]
    esc = lambda c: c.replace("|", "\\|").replace("\n", " ")
    lines = ["| " + " | ".join(esc(c) for c in rows[0]) + " |", "|" + "---|" * width]
    lines += ["| " + " | ".join(esc(c) for c in r) + " |" for r in rows[1:]]
    return "\n".join(lines)


# ---------------------------------------------------------------- docx
def _w_text(el) -> str:
    parts = []
    for n in el.iter():
        if n.tag == W + "t" and n.text:
            parts.append(n.text)
        elif n.tag == W + "tab":
            parts.append("\t")
        elif n.tag in (W + "br", W + "cr"):
            parts.append("\n")
    return "".join(parts)


def _docx_table(tbl) -> str:
    rows = []
    for tr in tbl.findall(W + "tr"):
        row = []
        for tc in tr.findall(W + "tc"):
            pr = tc.find(W + "tcPr")
            span = 1
            vmerge_cont = False
            if pr is not None:
                gs = pr.find(W + "gridSpan")
                if gs is not None:
                    span = int(gs.get(W + "val", "1"))
                vm = pr.find(W + "vMerge")
                if vm is not None and vm.get(W + "val") in (None, "continue"):
                    vmerge_cont = True
            txt = " / ".join(_w_text(p).strip() for p in tc.iter(W + "p") if _w_text(p).strip())
            row.append("" if vmerge_cont else txt)
            row.extend([""] * (span - 1))
        rows.append(row)
    return _md_table(rows)


def parse_docx(path: Path) -> str:
    with zipfile.ZipFile(path) as z:
        root = ET.fromstring(z.read("word/document.xml"))
    body = root.find(W + "body")
    out: List[str] = []
    if body is None:
        return ""
    for el in body:
        if el.tag == W + "p":
            txt = _w_text(el).strip()
            if not txt:
                continue
            ppr = el.find(W + "pPr")
            style = ""
            is_list = False
            if ppr is not None:
                st = ppr.find(W + "pStyle")
                style = st.get(W + "val", "") if st is not None else ""
                is_list = ppr.find(W + "numPr") is not None
            m = re.match(r"(?i)heading\s*(\d)", style)
            if m:
                out.append("#" * min(6, int(m.group(1))) + " " + txt)
            elif style.lower() == "title":
                out.append("# " + txt)
            elif is_list or style.lower().startswith("list"):
                out.append("- " + txt)
            else:
                out.append(txt)
        elif el.tag == W + "tbl":
            out.append(_docx_table(el))
    return "\n\n".join(out)


# ---------------------------------------------------------------- pptx
def parse_pptx(path: Path, pages: Optional[Set[int]] = None) -> str:
    out = []
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        slides = sorted([n for n in names if re.match(r"ppt/slides/slide\d+\.xml$", n)],
                        key=lambda n: int(re.findall(r"\d+", n)[-1]))
        for idx, n in enumerate(slides, 1):
            if pages and idx not in pages:
                continue
            root = ET.fromstring(z.read(n))
            parts = ["--- slide %d ---" % idx]
            for sp in root.iter():
                if sp.tag == P_NS + "sp":
                    paras = []
                    for p in sp.iter(A + "p"):
                        t = "".join(x.text or "" for x in p.iter(A + "t")).strip()
                        if t:
                            paras.append(t)
                    if paras:
                        parts.append("\n".join(paras))
                elif sp.tag == A + "tbl":
                    rows = [["".join(x.text or "" for x in tc.iter(A + "t")) for tc in tr.findall(A + "tc")]
                            for tr in sp.findall(A + "tr")]
                    parts.append(_md_table(rows))
            notes = "ppt/notesSlides/notesSlide%s.xml" % re.findall(r"\d+", n)[-1]
            if notes in names:
                nr = ET.fromstring(z.read(notes))
                nt = " ".join(x.text or "" for x in nr.iter(A + "t")).strip()
                if nt:
                    parts.append("[notes] " + nt)
            out.append("\n".join(parts))
    return "\n\n".join(out)


# ---------------------------------------------------------------- xlsx
def _col_idx(ref: str) -> int:
    letters = re.match(r"[A-Z]+", ref).group(0)
    n = 0
    for ch in letters:
        n = n * 26 + (ord(ch) - 64)
    return n - 1


def parse_xlsx(path: Path, max_rows: int = 300) -> str:
    out = []
    with zipfile.ZipFile(path) as z:
        shared: List[str] = []
        if "xl/sharedStrings.xml" in z.namelist():
            sroot = ET.fromstring(z.read("xl/sharedStrings.xml"))
            for si in sroot.findall(S + "si"):
                shared.append("".join(t.text or "" for t in si.iter(S + "t")))
        wb = ET.fromstring(z.read("xl/workbook.xml"))
        rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
        rid2target = {r.get("Id"): r.get("Target") for r in rels}
        sheets = []
        for sh in wb.iter(S + "sheet"):
            tgt = rid2target.get(sh.get(R + "id"), "")
            tgt = tgt.lstrip("/")
            sheets.append((sh.get("name"), tgt if tgt.startswith("xl/") else "xl/" + tgt))
        for name, target in sheets:
            if target not in z.namelist():
                continue
            root = ET.fromstring(z.read(target))
            rows = []
            for r in root.iter(S + "row"):
                row: List[str] = []
                for c in r.findall(S + "c"):
                    i = _col_idx(c.get("r", "A1"))
                    while len(row) <= i:
                        row.append("")
                    t = c.get("t")
                    v = c.find(S + "v")
                    if t == "s" and v is not None:
                        row[i] = shared[int(v.text)] if int(v.text) < len(shared) else ""
                    elif t == "inlineStr":
                        row[i] = "".join(x.text or "" for x in c.iter(S + "t"))
                    elif v is not None:
                        row[i] = v.text or ""
                rows.append(row)
                if len(rows) >= max_rows:
                    break
            out.append("--- sheet: %s (%d rows shown) ---\n%s" % (name, len(rows), _md_table(rows)))
    return "\n\n".join(out)


# ---------------------------------------------------------------- pdf
def parse_pdf(path: Path, pages: Optional[Set[int]] = None) -> str:
    errors = []
    try:
        import pdfplumber  # type: ignore
        out = []
        with pdfplumber.open(str(path)) as pdf:
            for i, pg in enumerate(pdf.pages, 1):
                if pages and i not in pages:
                    continue
                txt = pg.extract_text() or ""
                tables = []
                try:
                    for t in pg.extract_tables():
                        tables.append(_md_table([[(c or "") for c in row] for row in t]))
                except Exception:  # noqa: BLE001
                    pass
                out.append("--- page %d ---\n%s%s" % (i, txt, ("\n\n" + "\n\n".join(tables)) if tables else ""))
        return "\n\n".join(out)
    except ImportError:
        errors.append("pdfplumber missing")
    try:
        from pypdf import PdfReader  # type: ignore
        rd = PdfReader(str(path))
        out = []
        for i, pg in enumerate(rd.pages, 1):
            if pages and i not in pages:
                continue
            out.append("--- page %d ---\n%s" % (i, pg.extract_text() or ""))
        return "\n\n".join(out)
    except ImportError:
        errors.append("pypdf missing")
    try:
        import fitz  # type: ignore
        doc = fitz.open(str(path))
        return "\n\n".join("--- page %d ---\n%s" % (i + 1, pg.get_text()) for i, pg in enumerate(doc)
                           if not pages or (i + 1) in pages)
    except ImportError:
        errors.append("PyMuPDF missing")
    if shutil.which("pdftotext"):
        cp = subprocess.run(["pdftotext", "-layout", str(path), "-"], capture_output=True)
        return cp.stdout.decode("utf-8", "replace")
    raise ToolError("No PDF reader available (%s). Install pypdf or pdfplumber from the offline wheelhouse." %
                    ", ".join(errors))


# ---------------------------------------------------------------- html & others
class _Strip(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts: List[str] = []
        self._skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self._skip += 1
        if tag in ("p", "br", "div", "tr", "li", "h1", "h2", "h3", "h4"):
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag in ("script", "style") and self._skip:
            self._skip -= 1

    def handle_data(self, data):
        if not self._skip:
            self.parts.append(data)


def parse_document_file(path: Path, pages: Optional[Set[int]] = None) -> str:
    ext = path.suffix.lower()
    if ext == ".docx":
        return parse_docx(path)
    if ext == ".pptx":
        return parse_pptx(path, pages)
    if ext in (".xlsx", ".xlsm"):
        return parse_xlsx(path)
    if ext == ".pdf":
        return parse_pdf(path, pages)
    if ext in (".html", ".htm"):
        p = _Strip()
        p.feed(read_text_any(path))
        return re.sub(r"\n\s*\n+", "\n\n", "".join(p.parts)).strip()
    if ext in (".csv", ".tsv"):
        text = read_text_any(path)
        rows = list(csv.reader(io.StringIO(text), delimiter="\t" if ext == ".tsv" else ","))
        return "%d rows\n%s" % (len(rows), _md_table(rows[:200]))
    if ext == ".json":
        try:
            return json.dumps(json.loads(read_text_any(path)), indent=2)
        except ValueError:
            return read_text_any(path)
    if ext == ".zip":
        with zipfile.ZipFile(path) as z:
            return "zip members:\n" + "\n".join("%s (%d bytes)" % (i.filename, i.file_size) for i in z.infolist()[:200])
    if ext in (".doc", ".ppt", ".xls", ".rtf", ".odt"):
        raise ToolError("Legacy format %s: convert first, e.g. `soffice --headless --convert-to docx file%s` "
                        "(if LibreOffice is installed) or save as the modern format." % (ext, ext))
    raw = path.read_bytes()[:4096]
    if b"\x00" in raw:
        raise ToolError("Unsupported binary file type %s" % ext)
    return read_text_any(path)

"""Network diagnostics (read-only, local-network oriented)."""
from __future__ import annotations

import ipaddress
import re
import socket
import urllib.error
import urllib.parse
import urllib.request

from .base import Param, Tool, ToolError, ToolRegistry, ToolResult
from .shell import IS_WIN, _fmt, _run
import subprocess

_HOST = re.compile(r"^[A-Za-z0-9._:\-]{1,253}$")

_CMDS = {
    "ping": (["ping", "-n", "4", "{t}"], ["ping", "-c", "4", "{t}"], True),
    "traceroute": (["tracert", "-d", "-h", "15", "{t}"], ["traceroute", "-n", "-m", "15", "{t}"], True),
    "dns": (["nslookup", "{t}"], ["nslookup", "{t}"], True),
    "interfaces": (["ipconfig", "/all"], ["ip", "addr"], False),
    "connections": (["netstat", "-ano"], ["ss", "-tunap"], False),
    "listening": (["netstat", "-an"], ["ss", "-tuln"], False),
    "arp": (["arp", "-a"], ["ip", "neigh"], False),
    "routes": (["route", "print"], ["ip", "route"], False),
}


def net_diag(ctx, kind: str, target: str = "") -> ToolResult:
    if kind not in _CMDS:
        raise ToolError("kind must be one of: %s" % ", ".join(_CMDS))
    win, lin, needs_target = _CMDS[kind]
    if needs_target:
        if not target or not _HOST.match(target):
            raise ToolError("'%s' needs a valid host/IP in 'target'." % kind)
    argv = [a.replace("{t}", target) for a in (win if IS_WIN else lin)]
    try:
        cp = _run(argv, ctx.sandbox.workspace, 60, False)
    except FileNotFoundError:
        return ToolResult(False, "Command %r not found on this system." % argv[0])
    except subprocess.TimeoutExpired:
        return ToolResult(False, "%s timed out (host unreachable or filtered)." % kind)
    return _fmt(cp, 8000)


def port_check(ctx, host: str, port: int, timeout: int = 3) -> ToolResult:
    if not _HOST.match(host):
        raise ToolError("invalid host")
    try:
        with socket.create_connection((host, int(port)), timeout=timeout):
            return ToolResult(True, "%s:%d is OPEN (TCP connect succeeded)" % (host, port))
    except socket.timeout:
        return ToolResult(False, "%s:%d timed out (filtered or host down)" % (host, port))
    except OSError as e:
        return ToolResult(False, "%s:%d closed/unreachable: %s" % (host, port, e))


def _is_local(host: str) -> bool:
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror:
        return False
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if not (ip.is_private or ip.is_loopback or ip.is_link_local):
            return False
    return True


def local_http_get(ctx, url: str, max_chars: int = 4000) -> ToolResult:
    u = urllib.parse.urlparse(url)
    if u.scheme not in ("http", "https") or not u.hostname:
        raise ToolError("url must start with http:// or https://")
    if not _is_local(u.hostname):
        raise ToolError("Only localhost / private-network addresses are allowed (this agent is offline).")
    try:
        with urllib.request.urlopen(url, timeout=10) as r:
            body = r.read(200000).decode("utf-8", "replace")
            return ToolResult(True, "HTTP %d, content-type %s\n%s" % (r.status, r.headers.get("content-type", "?"),
                                                                        body[:max_chars]))
    except urllib.error.HTTPError as e:
        return ToolResult(False, "HTTP error %d for %s" % (e.code, url))
    except Exception as e:  # noqa: BLE001
        return ToolResult(False, "Request failed: %s" % e)


def register(reg: ToolRegistry) -> None:
    P = Param
    reg.register(Tool("net_diag", "Network info/diagnostics (OS-aware commands, read-only).", [
        P("kind", desc="what to run", enum=list(_CMDS)), P("target", desc="host/IP for ping|traceroute|dns",
                                                           required=False, default="")],
        net_diag, "net", 'net_diag(kind="ping", target="192.168.1.1")'))
    reg.register(Tool("port_check", "Test whether a TCP port is open.", [
        P("host"), P("port", "integer"), P("timeout", "integer", "", False, 3)], port_check, "net"))
    reg.register(Tool("local_http_get", "HTTP GET to localhost/LAN addresses only.", [
        P("url"), P("max_chars", "integer", "", False, 4000)], local_http_get, "net"))

"""File tools. All paths go through the sandbox."""
from __future__ import annotations

import difflib
import fnmatch
import re
import shutil
from pathlib import Path
from typing import List

from .base import Param, Tool, ToolError, ToolRegistry, ToolResult

TEXT_EXT_SKIP = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".zip", ".gz", ".7z", ".rar", ".exe", ".dll",
                 ".so", ".pyc", ".pdf", ".docx", ".pptx", ".xlsx", ".db", ".sqlite", ".bin", ".gguf", ".dvd"}


def read_text_any(path: Path) -> str:
    raw = path.read_bytes()
    if raw[:3] == b"\xef\xbb\xbf":
        return raw[3:].decode("utf-8", "replace")
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return raw.decode("utf-16", "replace")
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return raw.decode("cp1252", "replace")


def _is_binary(path: Path) -> bool:
    if path.suffix.lower() in TEXT_EXT_SKIP:
        return True
    try:
        with open(path, "rb") as fh:
            return b"\x00" in fh.read(2048)
    except OSError:
        return False


def _track(ctx, p: Path) -> None:
    st = getattr(ctx, "state", None)
    if st is not None:
        rel = ctx.sandbox.rel(p)
        if rel not in st.touched_files:
            st.touched_files.append(rel)


# ---------------------------------------------------------------------------
def list_dir(ctx, path: str = ".", depth: int = 1, max_entries: int = 80) -> str:
    root = ctx.sandbox.resolve(path)
    if not root.is_dir():
        raise ToolError("%s is not a directory" % path)
    out: List[str] = []

    def walk(d: Path, level: int):
        try:
            items = sorted(d.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower()))
        except PermissionError:
            return
        for it in items:
            if it.name.startswith(".") and it.name != ".":
                continue
            if len(out) >= max_entries:
                return
            ind = "  " * level
            if it.is_dir():
                out.append("%s%s/" % (ind, it.name))
                if level + 1 < depth:
                    walk(it, level + 1)
            else:
                out.append("%s%s (%d bytes)" % (ind, it.name, it.stat().st_size))

    walk(root, 0)
    if not out:
        return "(empty directory)"
    more = "\n...[list truncated at %d entries]" % max_entries if len(out) >= max_entries else ""
    return "\n".join(out) + more


def read_file(ctx, path: str, start_line: int = 1, end_line: int = 120) -> str:
    p = ctx.sandbox.resolve(path)
    if not p.exists():
        raise ToolError("File not found: %s. Use list_dir/find_files to locate it." % path)
    if p.is_dir():
        raise ToolError("%s is a directory; use list_dir." % path)
    if _is_binary(p):
        raise ToolError("%s looks binary/office/pdf. Use parse_document for pdf/docx/pptx/xlsx." % path)
    lines = read_text_any(p).splitlines()
    n = len(lines)
    s, e = max(1, start_line), min(n, max(start_line, end_line))
    body = "\n".join("%d| %s" % (i + 1, lines[i][:400]) for i in range(s - 1, e))
    if len(body) > 6000:
        body = body[:6000] + "\n...[output cut at 6000 chars; use a smaller line range]"
    foot = "" if e >= n else "\n...[%d more lines; call again with start_line=%d]" % (n - e, e + 1)
    return "[%s lines %d-%d of %d]\n%s%s" % (ctx.sandbox.rel(p), s, e, n, body, foot)


def write_file(ctx, path: str, content: str, mode: str = "create") -> str:
    p = ctx.sandbox.resolve(path, write=True)
    if p.exists() and mode == "create":
        raise ToolError("%s already exists. Use mode='overwrite' to replace it, mode='append' to add, "
                        "or edit_file to change part of it." % path)
    if p.is_dir():
        raise ToolError("%s is a directory" % path)
    p.parent.mkdir(parents=True, exist_ok=True)
    if mode == "append" and p.exists():
        with open(p, "a", encoding="utf-8", newline="") as fh:
            fh.write(content)
    else:
        with open(p, "w", encoding="utf-8", newline="") as fh:
            fh.write(content)
    _track(ctx, p)
    note = ""
    if p.suffix == ".py":
        try:
            compile(read_text_any(p), str(p), "exec")
        except SyntaxError as e:
            note = "\nWARNING: Python syntax error line %s: %s" % (e.lineno, e.msg)
    return "Wrote %s (%d chars, mode=%s).%s" % (ctx.sandbox.rel(p), len(content), mode, note)


def _norm(s: str) -> str:
    return "\n".join(l.rstrip() for l in s.replace("\r\n", "\n").split("\n")).strip("\n")


def edit_file(ctx, path: str, search: str, replace: str, replace_all: bool = False) -> str:
    p = ctx.sandbox.resolve(path, write=True)
    if not p.exists():
        raise ToolError("File not found: %s" % path)
    text = read_text_any(p)
    crlf = "\r\n" in text
    text = text.replace("\r\n", "\n")
    s = search.replace("\r\n", "\n")
    if not s.strip():
        raise ToolError("'search' is empty")
    count = text.count(s)
    if count == 0:  # whitespace-tolerant retry (trailing spaces)
        lines = text.split("\n")
        sl = _norm(s).split("\n")
        hit = -1
        for i in range(len(lines) - len(sl) + 1):
            if all(lines[i + j].rstrip() == sl[j].rstrip() for j in range(len(sl))):
                hit = i
                break
        if hit >= 0:
            lines[hit:hit + len(sl)] = _norm(replace).split("\n")
            new = "\n".join(lines)
            count = 1
        else:
            cand = difflib.get_close_matches(sl[0], lines, n=1, cutoff=0.5)
            hint = ""
            if cand:
                idx = lines.index(cand[0])
                hint = "\nClosest line %d: %s" % (idx + 1, cand[0][:200])
            raise ToolError("'search' text not found in %s (must match exactly).%s\nUse read_file to copy the exact text."
                            % (path, hint))
    else:
        if count > 1 and not replace_all:
            raise ToolError("'search' matches %d places; include more surrounding lines or set replace_all=true." % count)
        new = text.replace(s, replace) if replace_all else text.replace(s, replace, 1)
    if crlf:
        new = new.replace("\n", "\r\n")
    with open(p, "w", encoding="utf-8", newline="") as fh:
        fh.write(new)
    _track(ctx, p)
    note = ""
    if p.suffix == ".py":
        try:
            compile(new.replace("\r\n", "\n"), str(p), "exec")
        except SyntaxError as e:
            note = "\nWARNING: Python syntax error line %s: %s" % (e.lineno, e.msg)
    return "Edited %s (%d replacement%s).%s" % (ctx.sandbox.rel(p), count if replace_all else 1,
                                                  "s" if (replace_all and count > 1) else "", note)


def find_files(ctx, pattern: str = "*", path: str = ".", max_results: int = 60) -> str:
    root = ctx.sandbox.resolve(path)
    res = []
    for f in root.rglob("*"):
        if any(part.startswith(".") for part in f.relative_to(root).parts):
            continue
        if fnmatch.fnmatch(f.name.lower(), pattern.lower()):
            res.append(ctx.sandbox.rel(f) + ("/" if f.is_dir() else ""))
            if len(res) >= max_results:
                res.append("...[more results; narrow the pattern]")
                break
    return "\n".join(res) if res else "No files match %r under %s" % (pattern, path)


def grep(ctx, pattern: str, path: str = ".", glob: str = "*", max_hits: int = 40) -> str:
    root = ctx.sandbox.resolve(path)
    try:
        rx = re.compile(pattern, re.I)
    except re.error:
        rx = re.compile(re.escape(pattern), re.I)
    files = [root] if root.is_file() else [f for f in root.rglob("*") if f.is_file()
                                            and not any(x.startswith(".") for x in f.relative_to(root).parts)
                                            and fnmatch.fnmatch(f.name.lower(), glob.lower())]
    out = []
    for f in files:
        if _is_binary(f):
            continue
        try:
            for i, ln in enumerate(read_text_any(f).splitlines(), 1):
                if rx.search(ln):
                    out.append("%s:%d: %s" % (ctx.sandbox.rel(f), i, ln.strip()[:200]))
                    if len(out) >= max_hits:
                        return "\n".join(out) + "\n...[more matches; refine]"
        except OSError:
            continue
    return "\n".join(out) if out else "No matches for %r" % pattern


def file_info(ctx, path: str) -> str:
    p = ctx.sandbox.resolve(path)
    if not p.exists():
        raise ToolError("not found: %s" % path)
    st = p.stat()
    kind = "directory" if p.is_dir() else "file"
    extra = ""
    if p.is_file() and not _is_binary(p):
        extra = ", %d lines" % (read_text_any(p).count("\n") + 1)
    return "%s %s: %d bytes%s" % (kind, ctx.sandbox.rel(p), st.st_size, extra)


def make_dir(ctx, path: str) -> str:
    p = ctx.sandbox.resolve(path, write=True)
    p.mkdir(parents=True, exist_ok=True)
    return "Created directory %s" % ctx.sandbox.rel(p)


def copy_path(ctx, src: str, dst: str) -> str:
    s, d = ctx.sandbox.resolve(src), ctx.sandbox.resolve(dst, write=True)
    if not s.exists():
        raise ToolError("not found: %s" % src)
    d.parent.mkdir(parents=True, exist_ok=True)
    if s.is_dir():
        shutil.copytree(s, d, dirs_exist_ok=True)
    else:
        shutil.copy2(s, d)
    _track(ctx, d)
    return "Copied %s -> %s" % (ctx.sandbox.rel(s), ctx.sandbox.rel(d))


def move_path(ctx, src: str, dst: str) -> str:
    s, d = ctx.sandbox.resolve(src, write=True), ctx.sandbox.resolve(dst, write=True)
    if not s.exists():
        raise ToolError("not found: %s" % src)
    ctx.sandbox.gate("move %s to %s" % (src, dst), "ask" if d.exists() else "allow")
    d.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(s), str(d))
    _track(ctx, d)
    return "Moved %s -> %s" % (ctx.sandbox.rel(s), ctx.sandbox.rel(d))


def delete_path(ctx, path: str) -> str:
    p = ctx.sandbox.resolve(path, write=True)
    if not p.exists():
        raise ToolError("not found: %s" % path)
    if p == ctx.sandbox.workspace:
        raise ToolError("refusing to delete the workspace root")
    scratch = ctx.sandbox.workspace / ".scratch"
    ctx.sandbox.gate("delete %s" % ctx.sandbox.rel(p), "allow" if Sandbox_inside(p, scratch) else "ask")
    if p.is_dir():
        shutil.rmtree(p)
    else:
        p.unlink()
    return "Deleted %s" % ctx.sandbox.rel(p)


def Sandbox_inside(p: Path, root: Path) -> bool:
    try:
        p.relative_to(root)
        return True
    except ValueError:
        return False


def register(reg: ToolRegistry) -> None:
    P = Param
    reg.register(Tool("list_dir", "List files in a directory.", [
        P("path", desc="directory", required=False, default="."),
        P("depth", "integer", "levels to show", False, 1)], list_dir, "read", 'list_dir(path="src")'))
    reg.register(Tool("read_file", "Read a text file with line numbers (use ranges for big files).", [
        P("path"), P("start_line", "integer", "", False, 1), P("end_line", "integer", "", False, 120)],
        read_file, "read", 'read_file(path="app.py", start_line=1, end_line=80)'))
    reg.register(Tool("write_file", "Create a file (fails if it exists unless mode=overwrite/append).", [
        P("path"), P("content", desc="full file text"),
        P("mode", desc="create|overwrite|append", required=False, default="create",
          enum=["create", "overwrite", "append"])], write_file, "write"))
    reg.register(Tool("edit_file", "Replace exact text in a file (search must match exactly once).", [
        P("path"), P("search", desc="exact existing text"), P("replace", desc="new text"),
        P("replace_all", "boolean", "", False, False)], edit_file, "write"))
    reg.register(Tool("find_files", "Find files by name pattern, e.g. *.py", [
        P("pattern", required=False, default="*"), P("path", required=False, default=".")],
        find_files, "read"))
    reg.register(Tool("grep", "Search text (regex) inside files.", [
        P("pattern"), P("path", required=False, default="."), P("glob", desc="file name filter",
                                                                    required=False, default="*")],
        grep, "read"))
    reg.register(Tool("file_info", "Size/type of a file or folder.", [P("path")], file_info, "read"))
    reg.register(Tool("make_dir", "Create a directory (parents included).", [P("path")], make_dir, "write"))
    reg.register(Tool("copy_path", "Copy a file or folder.", [P("src"), P("dst")], copy_path, "write"))
    reg.register(Tool("move_path", "Move/rename a file or folder.", [P("src"), P("dst")], move_path, "write"))
    reg.register(Tool("delete_path", "Delete a file or folder (asks for approval).", [P("path")],
                      delete_path, "write"))

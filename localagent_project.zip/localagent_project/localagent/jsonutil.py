"""Tolerant JSON extraction from LLM text."""
from __future__ import annotations

import ast
import json
import re
from typing import Any


class JSONExtractError(ValueError):
    pass


_FENCE = re.compile(r"```(?:json|JSON)?\s*(.*?)```", re.S)
_TRAILING_COMMA = re.compile(r",\s*([}\]])")


def _try_load(s: str) -> Any:
    try:
        return json.loads(s)
    except Exception:
        pass
    s2 = _TRAILING_COMMA.sub(r"\1", s)
    s2 = s2.replace("\u201c", '"').replace("\u201d", '"').replace("\u2018", "'").replace("\u2019", "'")
    try:
        return json.loads(s2)
    except Exception:
        pass
    try:  # python-literal style (single quotes, True/None)
        val = ast.literal_eval(s2)
        if isinstance(val, (dict, list)):
            return val
    except Exception:
        pass
    raise JSONExtractError("not json")


def extract_json(text: str) -> Any:
    """Return the first dict/list found in *text*. Raises JSONExtractError."""
    if text is None:
        raise JSONExtractError("empty reply")
    t = text.strip()
    if not t:
        raise JSONExtractError("empty reply")
    m = _FENCE.search(t)
    if m:
        t = m.group(1).strip()
    try:
        v = _try_load(t)
        if isinstance(v, (dict, list)):
            return v
    except JSONExtractError:
        pass
    dec = json.JSONDecoder()
    for i, ch in enumerate(t):
        if ch in "{[":
            try:
                v, _ = dec.raw_decode(t[i:])
                if isinstance(v, (dict, list)):
                    return v
            except Exception:
                pass
            # try balanced slice with lenient loader
            end = _balanced_end(t, i)
            if end:
                try:
                    v = _try_load(t[i:end])
                    if isinstance(v, (dict, list)):
                        return v
                except JSONExtractError:
                    pass
    raise JSONExtractError("no JSON object found in reply")


def _balanced_end(s: str, start: int) -> int:
    open_ch = s[start]
    close_ch = "}" if open_ch == "{" else "]"
    depth = 0
    in_str = False
    esc = False
    quote = ""
    for i in range(start, len(s)):
        c = s[i]
        if in_str:
            if esc:
                esc = False
            elif c == "\\":
                esc = True
            elif c == quote:
                in_str = False
            continue
        if c in "\"'":
            in_str = True
            quote = c
        elif c == open_ch:
            depth += 1
        elif c == close_ch:
            depth -= 1
            if depth == 0:
                return i + 1
    return 0

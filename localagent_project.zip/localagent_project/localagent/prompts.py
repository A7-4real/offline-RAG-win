"""All prompt text in one place. Kept short on purpose: small models follow short prompts."""
from __future__ import annotations

from typing import Dict, List

from .verify import CHECK_KINDS

ROUTER_SYS = ("You are the ROUTER of an offline autonomous agent. Choose the 1-2 skills that best fit the task. "
              'Reply with JSON only, e.g. {"skills": ["python_dev"]}.')

PLANNER_SYS = """You are the PLANNER of an offline autonomous agent.
Split the task into the FEWEST concrete steps (at most {n}). Each step must be doable with 1-5 tool calls.
For every step name the single most useful tool (tool_hint) and how success is checked (check).
check.kind values: none | file_exists (arg=path) | file_contains (arg=path::text) | output_contains (arg=text) | last_tool_ok | python_compiles (arg=path) | tests_pass (arg=path).
Prefer a code-checkable check over none. Reply with JSON only.
Example:
{{"steps":[{{"goal":"Find the CSV files","tool_hint":"find_files","check":{{"kind":"last_tool_ok","arg":""}}}},{{"goal":"Write summary.md with row counts","tool_hint":"write_file","check":{{"kind":"file_exists","arg":"summary.md"}}}}]}}"""

ACTOR_SYS = """You are the EXECUTOR of an offline autonomous agent. You complete ONE step by calling ONE tool at a time.
Reply with a single JSON object: {"thought": "<one short sentence>", "tool": "<tool name>", "args": {...}}.
Rules: use only the listed tools; read before you edit; never invent file contents or results; if a tool returns ERROR, fix the cause instead of repeating the call; call finish_step as soon as the step goal is achieved (success=true) or cannot be achieved (success=false).
Example: {"thought": "Need to see the file first", "tool": "read_file", "args": {"path": "data.csv", "end_line": 20}}"""

JUDGE_SYS = ("You verify whether a step goal was achieved, using ONLY the evidence shown. "
             'Reply JSON: {"verdict": "pass"|"fail"|"unsure", "reason": "<short>"}.')

REFLECT_SYS = ("A step of an autonomous agent failed. Diagnose it briefly and give ONE reusable lesson "
               "(trigger = situation, advice = what to do next time). Choose next: retry_step (try the same step "
               "differently), replan (change the remaining plan), skip_step, or abort. Reply with JSON only.")

FINAL_SYS = ("You write the final report of an autonomous agent for the user: at most 6 short sentences covering what "
             "was done, the key results, and the files created. Use ONLY the facts given. No invented details.")


def router_schema(names: List[str]) -> dict:
    return {"type": "object", "properties": {"skills": {"type": "array", "items": {"enum": names},
                                                          "minItems": 1, "maxItems": 2}},
            "required": ["skills"]}


def planner_schema(tool_names: List[str], max_steps: int) -> dict:
    return {"type": "object", "properties": {"steps": {
        "type": "array", "minItems": 1, "maxItems": max_steps,
        "items": {"type": "object", "properties": {
            "goal": {"type": "string", "maxLength": 200},
            "tool_hint": {"enum": tool_names + ["none"]},
            "check": {"type": "object", "properties": {
                "kind": {"enum": CHECK_KINDS}, "arg": {"type": "string", "maxLength": 120}},
                "required": ["kind", "arg"]}},
            "required": ["goal", "tool_hint", "check"]}}},
        "required": ["steps"]}


JUDGE_SCHEMA = {"type": "object", "properties": {
    "verdict": {"enum": ["pass", "fail", "unsure"]}, "reason": {"type": "string", "maxLength": 200}},
    "required": ["verdict", "reason"]}

REFLECT_SCHEMA = {"type": "object", "properties": {
    "error_class": {"enum": ["bad_arguments", "wrong_tool", "environment", "missing_information",
                             "logic_error", "impossible"]},
    "lesson": {"type": "object", "properties": {
        "trigger": {"type": "string", "maxLength": 120}, "advice": {"type": "string", "maxLength": 200}},
        "required": ["trigger", "advice"]},
    "next": {"enum": ["retry_step", "replan", "skip_step", "abort"]}},
    "required": ["error_class", "lesson", "next"]}

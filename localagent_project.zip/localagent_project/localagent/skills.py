"""Skill library. A skill is a folder:

    skills/<name>/SKILL.md        frontmatter + ## Rules / ## Workflow / ## Notes
    skills/<name>/scripts/*.py    helper scripts (run through the run_skill_script tool)
    skills/<name>/reference/*.md  cheat-sheets, indexed into offline search (search_docs)
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from .context import truncate
from .state import Step

_FM = re.compile(r"^---\s*\n(.*?)\n---\s*\n?(.*)$", re.S)
_WORD = re.compile(r"[a-z0-9_]{3,}")


def _list(v: str) -> List[str]:
    v = v.strip().strip("[]")
    return [x.strip().strip("'\"") for x in v.split(",") if x.strip()]


@dataclass
class Skill:
    name: str
    description: str
    path: Path
    tools: List[str] = field(default_factory=list)
    keywords: List[str] = field(default_factory=list)
    max_steps: int = 6
    plan_mode: str = "guided"          # guided (LLM plans, using the workflow) | fixed (workflow IS the plan)
    rules: str = ""
    workflow: str = ""
    notes: str = ""

    def scripts(self) -> List[str]:
        d = self.path / "scripts"
        return sorted(p.name for p in d.glob("*.py")) if d.exists() else []

    def references(self) -> List[Path]:
        d = self.path / "reference"
        return sorted(p for p in d.glob("*") if p.suffix.lower() in (".md", ".txt", ".rst")) if d.exists() else []

    def card(self, max_chars: int = 1500, with_workflow: bool = False) -> str:
        parts = ["Skill '%s': %s" % (self.name, self.description)]
        if self.rules:
            parts.append("Rules:\n" + self.rules.strip())
        if with_workflow and self.workflow:
            parts.append("Typical workflow:\n" + self.workflow.strip())
        sc = self.scripts()
        if sc:
            parts.append("Scripts (use run_skill_script skill=%s script=<name> args=...): %s" % (self.name, ", ".join(sc)))
        if self.references():
            parts.append("Reference docs are searchable with search_docs.")
        return truncate("\n".join(parts), max_chars)

    def fixed_steps(self) -> List[Step]:
        steps = []
        for line in self.workflow.splitlines():
            m = re.match(r"^\s*\d+[\.\)]\s+(.*)$", line)
            if not m:
                continue
            txt = m.group(1).strip()
            hint = re.search(r"\(tool:\s*([a-z_]+)\)", txt)
            chk = re.search(r"\(check:\s*([a-z_]+)(?::\s*([^)]*))?\)", txt)
            goal = re.sub(r"\((?:tool|check):[^)]*\)", "", txt).strip()
            steps.append(Step(id=len(steps) + 1, goal=goal, tool_hint=hint.group(1) if hint else "",
                              check_kind=chk.group(1) if chk else "none",
                              check_arg=(chk.group(2) or "").strip() if chk else ""))
        return steps


def parse_skill(text: str, path: Path) -> Skill:
    m = _FM.match(text.replace("\r\n", "\n"))
    if not m:
        raise ValueError("SKILL.md in %s needs a --- frontmatter block" % path)
    meta: Dict[str, str] = {}
    for line in m.group(1).splitlines():
        if ":" in line and not line.startswith(" "):
            k, v = line.split(":", 1)
            meta[k.strip().lower()] = v.strip()
    body = m.group(2)
    sections: Dict[str, str] = {}
    cur = "body"
    buf: List[str] = []
    for line in body.splitlines():
        if line.startswith("## "):
            sections[cur] = "\n".join(buf)
            cur, buf = line[3:].strip().lower(), []
        else:
            buf.append(line)
    sections[cur] = "\n".join(buf)
    name = meta.get("name") or path.name
    return Skill(name=name, description=meta.get("description", ""), path=path,
                 tools=_list(meta.get("tools", "")), keywords=_list(meta.get("keywords", "")),
                 max_steps=int(meta.get("max_steps", "6") or 6), plan_mode=meta.get("plan_mode", "guided"),
                 rules=sections.get("rules", "").strip(), workflow=sections.get("workflow", "").strip(),
                 notes=sections.get("notes", "").strip())


class SkillLibrary:
    def __init__(self, root: Path):
        self.root = Path(root)
        self.skills: Dict[str, Skill] = {}
        self.errors: List[str] = []
        if self.root.exists():
            for d in sorted(self.root.iterdir()):
                f = d / "SKILL.md"
                if d.is_dir() and f.exists():
                    try:
                        sk = parse_skill(f.read_text(encoding="utf-8"), d)
                        self.skills[sk.name] = sk
                    except Exception as e:  # noqa: BLE001
                        self.errors.append("%s: %s" % (d.name, e))

    def get(self, name: str) -> Optional[Skill]:
        return self.skills.get(name)

    def names(self) -> List[str]:
        return list(self.skills)

    def candidates(self, task: str, k: int = 5) -> List[Skill]:
        """Keyword/overlap pre-filter so the router LLM only sees a short list."""
        words = set(_WORD.findall(task.lower()))
        low = task.lower()
        scored = []
        for sk in self.skills.values():
            s = 0.0
            for kw in sk.keywords:
                if kw.lower() in low:
                    s += 3
            blob = set(_WORD.findall((sk.name + " " + sk.description).lower().replace("_", " ")))
            s += len(words & blob)
            scored.append((s, sk))
        scored.sort(key=lambda x: -x[0])
        if scored and scored[0][0] == 0:
            return [sk for _, sk in scored[:k]]
        return [sk for s, sk in scored if s > 0][:k]

    def index_references(self, memory, reader=None) -> int:
        n = 0
        for sk in self.skills.values():
            for ref in sk.references():
                n += memory.ingest_file(ref, "skill:" + sk.name, reader)
        return n

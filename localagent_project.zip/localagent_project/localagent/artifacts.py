"""Artifact store: big tool outputs live on disk; the model only sees a handle + preview."""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Dict, List, Optional


class ArtifactStore:
    def __init__(self, root: Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self._index_path = self.root / "index.json"
        self._index: Dict[str, dict] = {}
        if self._index_path.exists():
            try:
                self._index = json.loads(self._index_path.read_text(encoding="utf-8"))
            except Exception:
                self._index = {}

    def _flush(self) -> None:
        self._index_path.write_text(json.dumps(self._index, indent=1), encoding="utf-8")

    def save(self, text: str, label: str = "") -> str:
        aid = "A%d" % (len(self._index) + 1)
        (self.root / (aid + ".txt")).write_text(text, encoding="utf-8")
        self._index[aid] = {"label": label, "chars": len(text), "lines": text.count("\n") + 1}
        self._flush()
        return aid

    def exists(self, aid: str) -> bool:
        return aid in self._index

    def meta(self, aid: str) -> Optional[dict]:
        return self._index.get(aid)

    def _lines(self, aid: str) -> List[str]:
        if aid not in self._index:
            raise KeyError("unknown artifact %r (known: %s)" % (aid, ", ".join(self._index) or "none"))
        return (self.root / (aid + ".txt")).read_text(encoding="utf-8").splitlines()

    def read(self, aid: str, start: int = 1, end: Optional[int] = None, max_chars: int = 3000) -> str:
        lines = self._lines(aid)
        n = len(lines)
        start = max(1, start)
        end = min(n, end if end else start + 59)
        chunk = "\n".join("%d| %s" % (i + 1, lines[i][:300]) for i in range(start - 1, end))
        head = "[%s lines %d-%d of %d]\n" % (aid, start, end, n)
        if len(chunk) > max_chars:
            chunk = chunk[:max_chars] + "\n...[cut; request a smaller line range]"
        return head + chunk

    def grep(self, aid: str, pattern: str, context: int = 1, max_hits: int = 15) -> str:
        lines = self._lines(aid)
        try:
            rx = re.compile(pattern, re.I)
        except re.error:
            rx = re.compile(re.escape(pattern), re.I)
        out, hits = [], 0
        for i, ln in enumerate(lines):
            if rx.search(ln):
                hits += 1
                lo, hi = max(0, i - context), min(len(lines), i + context + 1)
                out.append("\n".join("%d| %s" % (j + 1, lines[j][:240]) for j in range(lo, hi)))
                if hits >= max_hits:
                    out.append("...[more matches; refine the pattern]")
                    break
        if not out:
            return "No matches for %r in %s (%d lines)." % (pattern, aid, len(lines))
        return "\n--\n".join(out)

"""Task state: plan, facts, counters. Serialised after every action (resume-able)."""
from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List

from .context import truncate


@dataclass
class Step:
    id: int
    goal: str
    tool_hint: str = ""
    check_kind: str = "none"
    check_arg: str = ""
    status: str = "pending"      # pending | running | done | failed | skipped
    result: str = ""
    attempts: int = 0


@dataclass
class TaskState:
    task: str
    run_id: str = field(default_factory=lambda: time.strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:4])
    skills: List[str] = field(default_factory=list)
    plan: List[Step] = field(default_factory=list)
    facts: Dict[str, str] = field(default_factory=dict)
    touched_files: List[str] = field(default_factory=list)
    actions_used: int = 0
    replans: int = 0
    status: str = "new"          # new | running | done | failed | aborted
    final: str = ""
    notes: List[str] = field(default_factory=list)      # failure notes for replanning

    # --- views used inside prompts -------------------------------------
    def plan_view(self, max_chars: int = 900) -> str:
        icon = {"pending": "[ ]", "running": "[>]", "done": "[x]", "failed": "[!]", "skipped": "[-]"}
        lines = []
        for s in self.plan:
            tail = ""
            if s.status in ("done", "failed") and s.result:
                tail = " => " + truncate(s.result.replace("\n", " "), 90)
            lines.append("%s %d. %s%s" % (icon.get(s.status, "[ ]"), s.id, s.goal, tail))
        return truncate("\n".join(lines), max_chars, "middle")

    def facts_view(self, max_chars: int = 900) -> str:
        if not self.facts:
            return ""
        return truncate("\n".join("%s = %s" % (k, v) for k, v in self.facts.items()), max_chars, "head")

    def current_step(self):
        for s in self.plan:
            if s.status in ("pending", "running"):
                return s
        return None

    # --- persistence -----------------------------------------------------
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.to_dict(), indent=1), encoding="utf-8")
        tmp.replace(path)

    @classmethod
    def load(cls, path: Path) -> "TaskState":
        d = json.loads(path.read_text(encoding="utf-8"))
        plan = [Step(**s) for s in d.pop("plan", [])]
        st = cls(**d)
        st.plan = plan
        return st

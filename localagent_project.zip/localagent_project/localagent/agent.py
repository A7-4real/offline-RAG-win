"""The agent loop: route -> plan -> (act -> observe -> verify)* -> reflect/replan -> report."""
from __future__ import annotations

import json
import os
import platform
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from . import prompts
from .artifacts import ArtifactStore
from .config import Config
from .context import ContextAssembler, Slot, truncate
from .llm import LLMClient, LLMError, LLMFormatError
from .memory import Memory
from .skills import Skill, SkillLibrary
from .state import Step, TaskState
from .tools import CORE_TOOLS, ToolContext
from .tools.base import ToolRegistry, ToolResult
from .tools.sandbox import Sandbox
from .verify import CHECK_KINDS, run_check


@dataclass
class StepOutcome:
    ok: bool
    reason: str
    recent: List[Dict[str, Any]] = field(default_factory=list)


class Agent:
    def __init__(self, cfg: Config, client: LLMClient, memory: Memory, library: SkillLibrary,
                 registry: ToolRegistry, ui: Any, sandbox: Sandbox):
        self.cfg, self.client, self.memory = cfg, client, memory
        self.library, self.registry, self.ui, self.sandbox = library, registry, ui, sandbox
        prof = cfg.profile_params()
        self.asm = ContextAssembler(prof["budget_tokens"], prof.get("chars_per_token", 3.3))
        self._run_dir: Optional[Path] = None

    # ================================================================== public
    def run(self, task: str, resume: Optional[TaskState] = None) -> TaskState:
        state = resume or TaskState(task=task)
        self._run_dir = self.cfg.data_path / "runs" / state.run_id
        self._run_dir.mkdir(parents=True, exist_ok=True)
        artifacts = ArtifactStore(self._run_dir / "artifacts")
        ctx = ToolContext(self.cfg, self.sandbox, state, self.memory, artifacts, self.library, self.ui)
        if self.cfg.trace:
            self.client.set_trace(self._trace_fn(self._run_dir / "trace.jsonl"))
        state.status = "running"
        for s in state.plan:                       # resume: interrupted steps start over
            if s.status == "running":
                s.status = "pending"
        self.ui.say("Run %s | model profile %s | skills dir: %d skills" % (
            state.run_id, self.cfg.profile, len(self.library.skills)))
        try:
            if not state.skills:
                self._route(state)
            if not state.plan:
                self._plan(state)
            self._execute(state, ctx)
            if state.status == "running":
                state.status = "done"
            state.final = self._final_report(state)
        except LLMError as e:
            state.status = "aborted"
            state.final = "Stopped: language-model error: %s" % e
        except KeyboardInterrupt:
            state.status = "aborted"
            state.final = "Interrupted by user (state saved; resume with --resume %s)." % state.run_id
        finally:
            self._save(state)
            try:
                self.memory.add_episode(state.task, state.status, state.final[:600])
            except Exception:  # noqa: BLE001
                pass
        return state

    # ================================================================== phases
    def _route(self, state: TaskState) -> None:
        cands = self.library.candidates(state.task, k=5)
        if not cands:
            state.skills = []
        elif len(cands) == 1:
            state.skills = [cands[0].name]
        else:
            listing = "\n".join("- %s: %s" % (c.name, c.description) for c in cands)
            user, _ = self.asm.assemble([Slot("TASK", state.task, 10, 450, 30),
                                         Slot("SKILLS", listing, 9, 900, 80),
                                         Slot("INSTRUCTION", "Pick the best 1-2 skill names.", 10, 40, 10)])
            try:
                r = self.client.json("router", prompts.ROUTER_SYS, user,
                                     prompts.router_schema([c.name for c in cands]), max_tokens=120,
                                     schema_name="route")
                state.skills = list(dict.fromkeys(r["skills"]))
            except LLMFormatError:
                state.skills = [cands[0].name]
        self.ui.say("Skills: %s" % (", ".join(state.skills) or "(none - core tools only)"))

    def _skills(self, state: TaskState) -> List[Skill]:
        return [s for s in (self.library.get(n) for n in state.skills) if s]

    def _union_tools(self, state: TaskState) -> List[str]:
        names = [t for t in CORE_TOOLS if t != "finish_step"]
        for sk in self._skills(state):
            names += sk.tools
        seen, out = set(), []
        for n in names:
            t = self.registry.get(n)
            if t and n not in seen and n != "finish_step":
                if self.cfg.autonomy == "readonly" and t.tier in ("write", "exec"):
                    continue
                seen.add(n)
                out.append(n)
        return out

    def _plan(self, state: TaskState, replan: bool = False) -> None:
        skills = self._skills(state)
        if not replan and len(skills) == 1 and skills[0].plan_mode == "fixed":
            steps = skills[0].fixed_steps()
            if steps:
                state.plan = steps
                self.ui.say("Plan (fixed by skill %s): %d steps" % (skills[0].name, len(steps)))
                return
        tools = self._union_tools(state)
        wf = "\n\n".join(s.card(1400, with_workflow=True) for s in skills)
        lessons = self._lessons_text(state.task + " " + " ".join(state.notes[-2:]), 2)
        slots = [Slot("ENVIRONMENT", self._env(), 3, 120),
                 Slot("TASK", state.task, 10, 500, 40),
                 Slot("SKILL GUIDANCE", wf, 5, 1200),
                 Slot("FACTS", state.facts_view(), 6, 300),
                 Slot("LESSONS", lessons, 3, 300)]
        if replan:
            slots += [Slot("PROGRESS SO FAR", state.plan_view(1200), 8, 600, 60),
                      Slot("WHY IT FAILED", "\n".join(state.notes[-3:]), 9, 400, 40)]
            instr = "Plan ONLY the remaining work, differently from what failed."
        else:
            instr = "Write the plan."
        slots.append(Slot("INSTRUCTION", instr + " Allowed tool_hint values: " + ", ".join(tools), 10, 260, 60))
        user, _ = self.asm.assemble(slots)
        n = self.cfg.max_plan_steps
        r = self.client.json("planner", prompts.PLANNER_SYS.format(n=n), user,
                             prompts.planner_schema(tools, n), max_tokens=900, schema_name="plan")
        base = max([s.id for s in state.plan] + [0])
        new = []
        for i, item in enumerate(r["steps"][:n], 1):
            goal = item["goal"].strip()
            if not goal:
                continue
            ck = item["check"]
            new.append(Step(id=base + i, goal=goal, tool_hint="" if item["tool_hint"] == "none" else item["tool_hint"],
                            check_kind=ck["kind"] if ck["kind"] in CHECK_KINDS else "none", check_arg=ck["arg"]))
        if not new:
            raise LLMFormatError("planner returned no usable steps")
        if replan:
            state.plan = [s for s in state.plan if s.status in ("done", "failed", "skipped")] + new
        else:
            state.plan = new
        self.ui.say("Plan: " + " | ".join("%d. %s" % (s.id, truncate(s.goal, 60)) for s in new))

    def _execute(self, state: TaskState, ctx: ToolContext) -> None:
        while True:
            step = state.current_step()
            if step is None:
                return
            if state.actions_used >= self.cfg.max_total_actions:
                state.status = "failed"
                state.notes.append("global action budget (%d) exhausted" % self.cfg.max_total_actions)
                return
            out = self._run_step(state, step, ctx)
            self._save(state)
            if out.ok:
                continue
            step.status = "failed"
            step.result = out.reason
            self.ui.say("  step %d failed: %s" % (step.id, out.reason))
            if state.actions_used >= self.cfg.max_total_actions:
                state.status = "failed"
                return
            decision = self._reflect(state, step, out)
            if decision == "retry_step" and step.attempts <= self.cfg.max_step_retries:
                step.status = "pending"
                continue
            if decision == "skip_step":
                step.status = "skipped"
                continue
            if decision in ("replan", "retry_step") and state.replans < self.cfg.max_replans:
                state.replans += 1
                self.ui.say("  replanning (%d/%d)" % (state.replans, self.cfg.max_replans))
                self._plan(state, replan=True)
                continue
            state.status = "failed"
            return

    # ================================================================== step loop
    def _allowed_tools(self, state: TaskState, step: Step) -> List[str]:
        order = ["finish_step"]
        if step.tool_hint:
            order.append(step.tool_hint)
        for sk in self._skills(state):
            order += sk.tools
        order += [t for t in CORE_TOOLS]
        out, seen = [], set()
        for n in order:
            t = self.registry.get(n)
            if not t or n in seen:
                continue
            if self.cfg.autonomy == "readonly" and t.tier in ("write", "exec"):
                continue
            seen.add(n)
            out.append(n)
        return out[: self.cfg.max_tools_per_step]

    def _run_step(self, state: TaskState, step: Step, ctx: ToolContext) -> StepOutcome:
        step.status = "running"
        step.attempts += 1
        self.ui.say("Step %d/%d: %s" % (step.id, len(state.plan), step.goal))
        allowed = self._allowed_tools(state, step)
        schema = self.registry.action_schema(allowed)
        recent: List[Dict[str, Any]] = []
        results: List[ToolResult] = []
        strikes = verify_fails = repeat = 0
        last_key = None
        for _ in range(self.cfg.max_actions_per_step):
            if state.actions_used >= self.cfg.max_total_actions:
                return StepOutcome(False, "global action budget exhausted", recent)
            system, user = self._actor_prompt(state, step, recent, allowed)
            try:
                act = self.client.json("actor", system, user, schema, schema_name="action")
            except LLMFormatError:
                strikes += 1
                recent.append({"tool": "(invalid reply)", "args": {}, "ok": False,
                               "text": "ERROR: not a valid action. Reply with JSON {thought, tool, args}."})
                if strikes >= 2:
                    return StepOutcome(False, "model could not produce a valid action", recent)
                continue
            strikes = 0
            tool, args = act["tool"], (act.get("args") or {})
            if tool == "finish_step":
                if not args.get("success"):
                    return StepOutcome(False, str(args.get("result", "")) or "model reported the step impossible", recent)
                good, why = self._verify(state, step, ctx, results, str(args.get("result", "")))
                if good:
                    step.status, step.result = "done", str(args.get("result", ""))[:400]
                    self.ui.say("  step %d done: %s" % (step.id, truncate(step.result, 100)))
                    return StepOutcome(True, step.result, recent)
                verify_fails += 1
                recent.append({"tool": "finish_step", "args": args, "ok": False,
                               "text": "VERIFICATION FAILED: %s. Fix this, then call finish_step again." % why})
                if verify_fails >= 2:
                    return StepOutcome(False, "verification failed: " + why, recent)
                continue
            key = tool + json.dumps(args, sort_keys=True, default=str)
            repeat = repeat + 1 if key == last_key else 0
            last_key = key
            if repeat >= 2:
                return StepOutcome(False, "stuck repeating the same %s call" % tool, recent)
            res = self.registry.execute(tool, args, ctx)
            state.actions_used += 1
            results.append(res)
            text = self._observe(res, ctx, tool)
            if repeat == 1:
                text += "\n(NOTE: identical call repeated - change approach or call finish_step)"
            recent.append({"tool": tool, "args": args, "ok": res.ok, "text": text})
            self.ui.action(tool, args, res)
            self._save(state)
        return StepOutcome(False, "action budget for this step used up without finish_step", recent)

    # ================================================================== prompts
    def _env(self) -> str:
        return "OS: %s | workspace: %s | python %s" % (platform.system(), self.sandbox.workspace,
                                                       platform.python_version())

    def _lessons_text(self, query: str, k: int) -> str:
        rows = self.memory.search_lessons(query, k)
        return "\n".join("- When %s: %s" % (r["trigger"], r["advice"]) for r in rows)

    @staticmethod
    def _args_short(args: dict, n: int = 110) -> str:
        return truncate(json.dumps(args, ensure_ascii=False, default=str), n, "tail")

    def _recent_text(self, recent: List[dict]) -> str:
        if not recent:
            return "(none yet)"
        keep = self.cfg.recent_full_observations
        lines = []
        for i, r in enumerate(recent):
            n = i + 1
            head = "[%d] %s(%s)" % (n, r["tool"], self._args_short(r["args"]))
            if i >= len(recent) - keep:
                lines.append(head + "\n" + r["text"])
            else:
                first = (r["text"].strip().splitlines() or [""])[0]
                lines.append(head + " -> " + truncate(first, 90))
        return "\n".join(lines)

    def _actor_prompt(self, state: TaskState, step: Step, recent: List[dict], allowed: List[str]):
        skills = self._skills(state)
        rules = "\n\n".join(s.card(900) for s in skills)
        q = step.goal + " " + (recent[-1]["text"][:150] if recent and not recent[-1]["ok"] else "")
        step_txt = "Step %d of %d: %s" % (step.id, len(state.plan), step.goal)
        if step.check_kind != "none":
            step_txt += "\nSuccess check: %s %s" % (step.check_kind, step.check_arg)
        if state.notes:
            step_txt += "\nEarlier problems: " + truncate(" ".join(state.notes[-2:]), 300)
        slots = [
            Slot("ENVIRONMENT", self._env(), 3, 120),
            Slot("TASK", state.task, 9, 450, 40),
            Slot("PLAN", state.plan_view(800), 6, 350),
            Slot("CURRENT STEP", step_txt, 10, 300, 50),
            Slot("FACTS", state.facts_view(700), 7, 300),
            Slot("SKILL RULES", rules, 4, 600),
            Slot("LESSONS", self._lessons_text(q + " " + state.task, 2), 3, 250),
            Slot("TOOLS", self.registry.cards(allowed), 8, 1100, 120),
            Slot("RECENT ACTIONS", self._recent_text(recent), 8, 2200, 100, trim="head"),
            Slot("INSTRUCTION", 'Reply with one JSON object {"thought","tool","args"}. '
                                "Call finish_step when the step goal is met.", 10, 100, 20),
        ]
        user, _ = self.asm.assemble(slots)
        return prompts.ACTOR_SYS, user

    # ================================================================== observation / verification
    def _observe(self, res: ToolResult, ctx: ToolContext, label: str) -> str:
        text = res.output
        tool = self.registry.get(label)
        limit = self.cfg.tool_output_chars
        if len(text) <= limit:
            body = text
        elif tool is not None and not tool.spill:
            body = truncate(text, limit * 3, "middle")
        else:
            aid = ctx.artifacts.save(text, label)
            head, tail = text[: int(limit * 0.6)], text[-int(limit * 0.25):]
            body = "%s\n...[%d chars omitted]...\n%s\n[full output saved as %s, %d lines - use read_artifact or grep_artifact]" % (
                head, len(text) - len(head) - len(tail), tail, aid, text.count("\n") + 1)
        return ("OK: " if res.ok else "ERROR: ") + body

    def _verify(self, state: TaskState, step: Step, ctx: ToolContext, results: List[ToolResult], claim: str):
        if step.check_kind != "none":
            v, why = run_check(step.check_kind, step.check_arg, ctx, results)
            if v is not None:
                return v, why
        suspicious = (not results) or (not results[-1].ok)
        if suspicious:
            evidence = "\n".join(r.output[:300] for r in results[-2:]) or "(no tool was run)"
            user, _ = self.asm.assemble([
                Slot("STEP GOAL", step.goal, 10, 200, 40), Slot("AGENT CLAIM", claim, 9, 200, 20),
                Slot("EVIDENCE (last tool outputs)", evidence, 8, 700, 40),
                Slot("INSTRUCTION", "Was the goal achieved? Mostly judge by the evidence.", 10, 60, 10)])
            try:
                j = self.client.json("judge", prompts.JUDGE_SYS, user, prompts.JUDGE_SCHEMA, max_tokens=150,
                                     schema_name="verdict")
                if j["verdict"] == "fail":
                    return False, j["reason"]
            except LLMFormatError:
                pass
        return True, "accepted"

    # ================================================================== reflection / report
    def _reflect(self, state: TaskState, step: Step, out: StepOutcome) -> str:
        default = "replan" if state.replans < self.cfg.max_replans else "abort"
        user, _ = self.asm.assemble([
            Slot("TASK", state.task, 8, 300, 30), Slot("FAILED STEP", step.goal, 10, 200, 30),
            Slot("FAILURE", out.reason, 10, 250, 30),
            Slot("LAST ACTIONS", self._recent_text(out.recent), 7, 1200, 60, trim="head"),
            Slot("INSTRUCTION", "Diagnose, give one lesson, pick next.", 10, 40, 10)])
        try:
            r = self.client.json("reflector", prompts.REFLECT_SYS, user, prompts.REFLECT_SCHEMA, max_tokens=300,
                                 schema_name="reflection")
        except LLMFormatError:
            state.notes.append("Step %d failed: %s" % (step.id, out.reason))
            return default
        last_tool = next((x["tool"] for x in reversed(out.recent) if x["tool"] != "(invalid reply)"), "")
        self.memory.add_lesson(last_tool, r["lesson"]["trigger"], r["lesson"]["advice"])
        state.notes.append("Step %d failed (%s): %s. Advice: %s" % (step.id, r["error_class"], out.reason,
                                                                      r["lesson"]["advice"]))
        return r["next"]

    def _final_report(self, state: TaskState) -> str:
        results = "\n".join("%d. [%s] %s => %s" % (s.id, s.status, s.goal, truncate(s.result, 160)) for s in state.plan)
        files = ", ".join(state.touched_files) or "none"
        fallback = "Status: %s.\n%s\nFiles: %s" % (state.status, results, files)
        if state.status == "aborted":
            return state.final or fallback
        try:
            user, _ = self.asm.assemble([
                Slot("TASK", state.task, 9, 400, 30), Slot("STATUS", state.status, 9, 20, 5),
                Slot("STEP RESULTS", results, 8, 1500, 100), Slot("FILES TOUCHED", files, 7, 300, 20),
                Slot("INSTRUCTION", "Write the final report.", 10, 30, 10)])
            txt = self.client.text("reporter", prompts.FINAL_SYS, user, max_tokens=350)
            return txt if txt else fallback
        except LLMError:
            return fallback

    # ================================================================== persistence
    def _save(self, state: TaskState) -> None:
        if self._run_dir:
            state.save(self._run_dir / "state.json")

    @staticmethod
    def _trace_fn(path: Path):
        def fn(rec: Dict[str, Any]) -> None:
            with open(path, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
        return fn

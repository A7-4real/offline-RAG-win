import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from testgen import schema
from testgen.config import load_config
from testgen.eval import compare
from testgen.grounding import SymbolTable, load_symbols, normalize
from testgen.issues import FatalError, counts, dedupe, exit_code, make_issue
from testgen.llm_client import extract_json, fold_system, strip_fences
from testgen.render import lane_groups
from testgen.roles import keyword_role
from testgen.sections import plan_batches, rule_label


def tmp(text, name="f.txt", mode="w", enc="utf-8"):
    d = tempfile.mkdtemp()
    p = os.path.join(d, name)
    with open(p, mode, **({"encoding": enc} if "b" not in mode else {})) as h:
        h.write(text)
    return p


class LaneGroups(unittest.TestCase):
    def test_all_same(self):
        self.assertEqual(lane_groups(["1", "1", "1", "1"]), [("1111", "1")])

    def test_two_values(self):
        self.assertEqual(lane_groups(["1", "0", "1", "0"]), [("1010", "1"), ("0101", "0")])

    def test_dont_care_excluded(self):
        self.assertEqual(lane_groups([None, None, "1", "1"]), [("0011", "1")])

    def test_three_values_order(self):
        self.assertEqual(lane_groups(["a", "b", "c", "a"]), [("1001", "a"), ("0100", "b"), ("0010", "c")])

    def test_all_none(self):
        self.assertEqual(lane_groups([None, None]), [])

    def test_leading_zero_kept(self):
        self.assertEqual(lane_groups(["0110", "0110"]), [("11", "0110")])


class Schema(unittest.TestCase):
    def test_valid(self):
        s = schema.section_labels_schema(["S1"], ["a", "b"])
        self.assertEqual(schema.validate({"labels": [{"id": "S1", "label": "a"}]}, s), [])

    def test_problems(self):
        s = schema.section_labels_schema(["S1", "S2"], ["a"])
        self.assertTrue(schema.validate({"labels": []}, s))
        self.assertTrue(schema.validate({}, s))
        self.assertTrue(schema.validate([], s))
        self.assertTrue(schema.validate({"labels": [{"id": "S1", "label": "zzz"}, {"id": "S2", "label": "a"}]}, s))
        self.assertTrue(schema.validate({"labels": [{"id": "S1", "label": "a", "x": 1}, {"id": "S2", "label": "a"}]}, s))

    def test_bool_is_not_int(self):
        self.assertTrue(schema.validate(True, {"type": "integer"}))

    def test_unhashable_enum_value(self):
        self.assertTrue(schema.validate([1], {"enum": ["a"]}))


class JsonHelpers(unittest.TestCase):
    def test_fences(self):
        self.assertEqual(strip_fences("```json\n{\"a\": 1}\n```"), '{"a": 1}')

    def test_extract_with_chatter(self):
        self.assertEqual(extract_json('Sure! {"a": [1, 2]} hope it helps'), {"a": [1, 2]})

    def test_extract_nested_and_braces_in_strings(self):
        self.assertEqual(extract_json('x {"a": "}{", "b": {"c": 1}} y'), {"a": "}{", "b": {"c": 1}})

    def test_extract_fails(self):
        with self.assertRaises(ValueError):
            extract_json("no json here")

    def test_fold_system(self):
        out = fold_system([("system", "S"), ("human", "H")])
        self.assertEqual(out, [("human", "S\n\nH")])


class Config(unittest.TestCase):
    def test_defaults(self):
        cfg, issues = load_config()
        self.assertEqual(issues, [])
        self.assertEqual(cfg["num_computers"], 4)

    def test_merge_keeps_other_defaults(self):
        cfg, _ = load_config(tmp(json.dumps({"llm": {"model": "x"}})))
        self.assertEqual(cfg["llm"]["model"], "x")
        self.assertEqual(cfg["llm"]["backend"], "ollama")

    def test_unknown_key_flagged(self):
        _, issues = load_config(tmp(json.dumps({"num_computerz": 4})))
        self.assertTrue(any("num_computerz" in i["message"] for i in issues))

    def test_bad_json_fatal(self):
        with self.assertRaises(FatalError):
            load_config(tmp("{not json"))

    def test_missing_file_fatal(self):
        with self.assertRaises(FatalError):
            load_config("/nonexistent/config.json")

    def test_bad_type_fatal(self):
        with self.assertRaises(FatalError):
            load_config(tmp(json.dumps({"num_computers": "four"})))
        with self.assertRaises(FatalError):
            load_config(tmp(json.dumps({"strict": 1})))

    def test_bad_template_placeholder_fatal(self):
        with self.assertRaises(FatalError):
            load_config(tmp(json.dumps({"formats": {"check": "{sym} {nope}"}})))

    def test_bad_template_syntax_fatal(self):
        with self.assertRaises(FatalError):
            load_config(tmp(json.dumps({"formats": {"check": "{sym"}})))

    def test_bad_mask_fatal(self):
        with self.assertRaises(FatalError):
            load_config(tmp(json.dumps({"default_masks": {"check": "12"}})))

    def test_json_with_bom(self):
        p = tmp("\ufeff" + json.dumps({"strict": True}), enc="utf-8")
        cfg, _ = load_config(p)
        self.assertTrue(cfg["strict"])


class Symbols(unittest.TestCase):
    def test_ok_and_aliases(self):
        sy, issues = load_symbols(tmp("variable,symbol,aliases\na_b,sym1,alpha|beta\n"))
        self.assertEqual(issues, [])
        self.assertEqual(sy.resolve("Alpha", {"accept": .9, "margin": .05, "floor": .5, "top_n": 3})["variable"], "a_b")

    def test_missing_columns(self):
        with self.assertRaises(FatalError):
            load_symbols(tmp("name,thing\na,b\n"))

    def test_empty(self):
        with self.assertRaises(FatalError):
            load_symbols(tmp("   \n"))

    def test_no_rows(self):
        with self.assertRaises(FatalError):
            load_symbols(tmp("variable,symbol\n"))

    def test_missing_file(self):
        with self.assertRaises(FatalError):
            load_symbols("/nonexistent.csv")

    def test_duplicates_and_incomplete(self):
        sy, issues = load_symbols(tmp("variable,symbol\na,s1\na,s2\nb,\nc,s1\n"))
        msgs = " ".join(i["message"] for i in issues)
        self.assertIn("duplicate variable", msgs)
        self.assertIn("incomplete", msgs)
        self.assertIn("symbol 's1' is used by both", msgs)
        self.assertEqual(len(sy), 2)

    def test_semicolon_and_latin1(self):
        p = tmp("variable;symbol\nh\u00f6he;s1\n".encode("latin-1").decode("latin-1"), enc="latin-1")
        sy, _ = load_symbols(p)
        self.assertEqual(len(sy), 1)

    def test_bom(self):
        sy, _ = load_symbols(tmp("\ufeffvariable,symbol\na,b\n"))
        self.assertEqual(len(sy), 1)


class Grounding(unittest.TestCase):
    G = {"accept": .92, "margin": .05, "floor": .55, "top_n": 5}

    def setUp(self):
        self.st = SymbolTable([
            {"variable": "driver_panel_auto_gas", "symbol": "s1", "description": "", "aliases": ""},
            {"variable": "driver_panel_brake", "symbol": "s2", "description": "", "aliases": ""},
            {"variable": "vehicle_mode", "symbol": "pc_cs", "description": "", "aliases": "mode"},
        ])

    def test_exact_normalization(self):
        self.assertEqual(normalize("Driver_Panel-AutoGas"), "driver panel auto gas")
        self.assertEqual(self.st.resolve("Vehicle Mode", self.G)["status"], "exact")

    def test_symbol_is_resolvable(self):
        self.assertEqual(self.st.resolve("pc_cs", self.G)["variable"], "vehicle_mode")

    def test_typo_fuzzy(self):
        r = self.st.resolve("driver pannel auto gas", self.G)
        self.assertEqual((r["status"], r["variable"]), ("fuzzy", "driver_panel_auto_gas"))

    def test_ambiguous(self):
        r = self.st.resolve("driver panel", self.G)
        self.assertEqual(r["status"], "ambiguous")
        self.assertTrue(r["candidates"])

    def test_none(self):
        self.assertEqual(self.st.resolve("zzzz qqqq", self.G)["status"], "none")

    def test_empty_text(self):
        self.assertEqual(self.st.resolve("", self.G)["status"], "none")

    def test_large_table_is_fast(self):
        import time
        rows = [{"variable": "var_%d_x%d" % (i, i * 7), "symbol": "s%d" % i, "description": "", "aliases": ""} for i in range(5000)]
        big = SymbolTable(rows)
        t = time.time()
        for q in ["var 17 x119", "something else", "var 4999 x34993", "unknown thing here"] * 5:
            big.resolve(q, self.G)
        self.assertLess(time.time() - t, 15)


class Rules(unittest.TestCase):
    R = load_config()[0]["keyword_rules"]

    def test_rule_labels(self):
        self.assertEqual(rule_label("Index", self.R), "index")
        self.assertEqual(rule_label("Expected output of test cases", self.R), "expected_outputs")
        self.assertEqual(rule_label("Test Inputs", self.R), "test_inputs")
        self.assertEqual(rule_label("System Initialization", self.R), "initialization")
        self.assertEqual(rule_label("Weird Chapter", self.R), None)

    def test_keyword_role(self):
        self.assertEqual(keyword_role("Test inputs"), "input")
        self.assertEqual(keyword_role("Expected result"), "expected")
        self.assertIsNone(keyword_role("something"))

    def test_batches(self):
        self.assertEqual(plan_batches(0, 5, 1), [])
        self.assertEqual(plan_batches(3, 5, 1), [[0, 1, 2]])
        b = plan_batches(10, 4, 1)
        self.assertEqual(b[0], [0, 1, 2, 3])
        self.assertEqual(b[1][0], 3)
        self.assertEqual(b[-1][-1], 9)
        self.assertEqual(plan_batches(5, 1, 5)[0], [0])        # overlap clamped, no infinite loop


class Issues(unittest.TestCase):
    def test_helpers(self):
        a = make_issue("review", "x", "m")
        self.assertEqual(len(dedupe([a, dict(a)])), 1)
        self.assertEqual(make_issue("weird", "x", "m")["severity"], "review")
        self.assertEqual(exit_code([], False), 0)
        self.assertEqual(exit_code([a], False), 1)
        self.assertEqual(exit_code([make_issue("info", "x", "m")], False), 0)
        self.assertEqual(exit_code([], True), 2)
        self.assertEqual(counts([a])["review"], 1)


class Eval(unittest.TestCase):
    def test_compare(self):
        r = compare("# c\na <-> 1\nb <-> 2\n", "a <-> 1\nc <-> 3\n")
        self.assertEqual((r["matched"], r["missing"], r["extra"]), (1, ["c <-> 3"], ["b <-> 2"]))
        self.assertEqual(compare("", "")["f1"], 0.0)


if __name__ == "__main__":
    unittest.main()

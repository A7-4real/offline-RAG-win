import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))
import fake_langgraph
from docx import Document
from synth_docs import build_doc, make_table, write_symbols
from testgen import stages
from testgen.config import load_config
from testgen.grounding import load_symbols
from testgen.llm_client import LLMClient
from testgen.runner import run_pipeline
from testgen.testing import FakeModel

ROOT = os.path.join(os.path.dirname(__file__), "..")
TMP = tempfile.mkdtemp()
SYMS = write_symbols(os.path.join(TMP, "symbols.csv"))
DOCS = {}


def doc(variant):
    if variant not in DOCS:
        DOCS[variant] = build_doc(os.path.join(TMP, variant + ".docx"), variant)
    return DOCS[variant]


def run(variant_or_path, cfg_over=None, model=None, client=None, tag=None, **kw):
    path = variant_or_path if os.path.sep in variant_or_path else doc(variant_or_path)
    cfg, ci = load_config(None, cfg_over)
    sy, si = load_symbols(SYMS)
    out = tempfile.mkdtemp(dir=TMP)
    client = client or LLMClient(model if model is not None else FakeModel(), model_id="fake", sleep=lambda s: None, timeout=kw.pop("timeout", 5))
    kw.setdefault("recipe_dir", os.path.join(out, "recipes"))
    state, code, eng = run_pipeline(path, out, cfg, sy, client, config_issues=ci + si, **kw)
    stem = os.path.splitext(os.path.basename(path))[0]
    tpf = os.path.join(out, stem + ".tpf")
    text = open(tpf).read() if os.path.exists(tpf) else None
    return state, code, text, out, eng


def lines(text):
    return [l for l in text.splitlines() if l and not l.startswith("#")]


class Basic(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.state, cls.code, cls.tpf, cls.out, _ = run("full")
        cls.lines = lines(cls.tpf)

    def test_finishes_with_review_items(self):
        self.assertEqual(self.code, 1)
        self.assertIsNone(self.state["fatal"])
        self.assertEqual([s["status"] for s in self.state["stage_log"]], ["ok"] * 9)

    def test_expected_lines(self):
        for want in ["dps_sym[1111] <-> 0/", "sbc_sym[1010] <-> 1/", "sbc_sym[0101] <-> 0/", "pp_sym[1111] <-> 0110/",
                     "out_sym[0011] <-> 1/", "t_delay[111] <-> 10", "t_hold[111] <-> 5", "mm_sym[1111] <-> 3/"]:
            self.assertIn(want, self.lines)

    def test_no_unresolved_and_four_cases(self):
        self.assertNotIn("??UNRESOLVED", self.tpf)
        self.assertEqual(self.tpf.count("# test case"), 4)

    def test_channel_lanes_are_todo(self):
        self.assertEqual(sum(1 for l in self.tpf.splitlines() if l.startswith("# TODO")), 12)

    def test_ignored_tables_not_used(self):
        self.assertNotIn("R-1", self.tpf)
        self.assertEqual({r["role"] for r in self.state["roles"].values()}, {"ignore", "input", "expected"})

    def test_spec_json_is_interleaved(self):
        spec = json.load(open(os.path.join(self.out, "full.spec.json")))
        step = spec["test_cases"][0]["steps"][0]
        self.assertTrue(step["set_input"] and step["check_expected_output"])
        self.assertEqual(spec["test_cases"][0]["id"], "1")

    def test_files_written(self):
        for f in ["full.tpf", "full.review.md", "full.tables.md", "full.run_report.json", "full.spec.json",
                  "work/00_load.json", "work/08_render.json"]:
            self.assertTrue(os.path.exists(os.path.join(self.out, f)), f)

    def test_notes_extracted(self):
        g = self.state["spec"]["global_init"]
        self.assertEqual(g["funcs"], ["BOOT", "LOAD"])
        self.assertEqual(g["test_variables"][0]["symbol"], "if_sym")
        self.assertIn("water mode", " ".join(self.state["spec"]["constraints"]))


class VariantsAndNoLLM(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ref = lines(run("full")[2])

    def test_no_llm_same_result(self):
        _, code, text, _, _ = run("full", client=LLMClient(None))
        self.assertEqual(lines(text), self.ref)
        self.assertEqual(code, 1)

    def test_no_headings(self):
        st, _, text, _, _ = run("no_headings")
        self.assertEqual(lines(text), self.ref)
        self.assertTrue(any("treated as headings" in i["message"] for i in st["issues"]))

    def test_reordered(self):
        self.assertEqual(sorted(lines(run("reordered")[2])), sorted(self.ref))

    def test_extra_table_ignored(self):
        self.assertEqual(lines(run("extra_table")[2]), self.ref)

    def test_row_mismatch(self):
        st, code, text, _, _ = run("row_mismatch")
        self.assertEqual(text.count("# test case"), 4)
        self.assertTrue(any("row counts differ" in i["message"] for i in st["issues"]))

    def test_prose_only_and_no_tables(self):
        for v in ("prose_only", "no_tables"):
            st, code, text, _, _ = run(v)
            self.assertEqual(code, 1)
            self.assertIn("no test cases", text)
            self.assertTrue(any(i["severity"] == "error" for i in st["issues"]))

    def test_input_lane_mask_option(self):
        _, _, text, _, _ = run("full", {"input_lane_render": "mask"})
        self.assertIn("l_seat_prog[1010] <-> 1", text.replace("l_seat_prog[0101]", "x")) if False else None
        self.assertIn("l_seat_at_prog[111] <-> 3", text)
        self.assertNotIn("# TODO", text)

    def test_default_environment_and_global_init(self):
        _, _, text, _, _ = run("full", {"case_environment_default": {"func": ["in_water"], "target_computer": [1, 1, 1, 1]},
                                        "emit_global_init": True})
        self.assertIn("func <-> in_water", text)
        self.assertIn("pcomp <-> 1111", text)
        self.assertIn("# init system and verify", text)
        self.assertIn("if_sym <-> 0 /", text)
        self.assertIn("pc_pg = /", text)

    def test_custom_format(self):
        _, _, text, _, _ = run("full", {"formats": {"check": "CHECK {sym} {mask} {value}"}})
        self.assertIn("CHECK dps_sym 1111 0", text)

    def test_missing_symbol_becomes_unresolved(self):
        cfg_map = {"table_column_map": {"Timing / Delay": {"variable": "nope", "kind": "set_input"}}}
        st, _, text, _, _ = run("full", cfg_map)
        self.assertIn("??UNRESOLVED", text)
        self.assertTrue(any("not in symbols.csv" in i["message"] for i in st["issues"]))


class EnvironmentColumns(unittest.TestCase):
    def test_env_columns_via_config(self):
        d = Document()
        d.add_heading("Test Inputs", 1)
        make_table(d, [[("Step", 1, 1), ("Func", 1, 1), ("Computers", 1, 1), ("Delay", 1, 1)]],
                   [["1", "in_water", "1011", "10"], ["2", "boot, load", "1111", "20"]], 4)
        d.add_heading("Expected Outputs", 1)
        make_table(d, [[("Step", 1, 1), ("Mode", 1, 1)]], [["1", "2"], ["2", "3"]], 2)
        p = os.path.join(TMP, "env.docx")
        d.save(p)
        cmap = {"Func": {"kind": "env_func"}, "Computers": {"kind": "env_computers"}}
        st, _, text, _, _ = run(p, {"table_column_map": cmap, "funcs": ["in_water", "boot", "load"]})
        self.assertIn("func <-> in_water", text)
        self.assertIn("pcomp <-> 1011", text)
        self.assertIn("func <-> boot", text)
        self.assertIn("pc_cs[1111] <-> 2/", text)
        self.assertFalse(any("no column describes" in i["message"] for i in st["issues"]))


class BadInput(unittest.TestCase):
    def _fatal(self, path):
        st, code, text, out, _ = run(path)
        self.assertEqual(code, 2)
        self.assertTrue(st["fatal"])
        self.assertTrue(os.path.exists(os.path.join(out, os.path.splitext(os.path.basename(path))[0] + ".review.md")))
        return st

    def test_corrupt(self):
        p = os.path.join(TMP, "bad.docx")
        open(p, "wb").write(b"this is not a zip file")
        self._fatal(p)

    def test_missing(self):
        self._fatal(os.path.join(TMP, "none.docx"))

    def test_old_doc(self):
        p = os.path.join(TMP, "old.doc")
        open(p, "wb").write(b"x")
        self.assertIn(".docx", self._fatal(p)["fatal"])

    def test_empty_file(self):
        p = os.path.join(TMP, "empty.docx")
        open(p, "wb").write(b"")
        self._fatal(p)

    def test_document_without_content(self):
        p = os.path.join(TMP, "blank.docx")
        Document().save(p)
        self._fatal(p)


class LLMFailures(unittest.TestCase):
    """Whatever the model does, the run finishes and the tpf is still right."""

    @classmethod
    def setUpClass(cls):
        cls.ref = lines(run("full")[2])

    def _check(self, task, mode, times=None, **kw):
        model = FakeModel(fail={task: (mode, times)}, sleep_for=0.5)
        st, code, text, _, _ = run("full", model=model, timeout=kw.get("timeout", 5))
        self.assertIsNone(st["fatal"])
        return st, text

    def test_every_task_every_failure(self):
        for task in ("section_labels", "table_role", "field_map", "choose_variable", "notes_normalize", "notes_extract"):
            for mode in ("exception", "malformed", "empty", "truncated", "bad_enum"):
                st, text = self._check(task, mode)
                self.assertEqual(lines(text), self.ref, (task, mode))

    def test_timeout(self):
        st, text = self._check("section_labels", "timeout", timeout=0.05)
        self.assertEqual(lines(text), self.ref)
        self.assertTrue(any("LLM labelling failed" in i["message"] for i in st["issues"]))

    def test_fenced_answer_is_accepted(self):
        st, text = self._check("section_labels", "fenced")
        self.assertFalse(any("LLM labelling failed" in i["message"] for i in st["issues"]))

    def test_retry_recovers(self):
        st, text = self._check("section_labels", "malformed", times=1)
        self.assertFalse(any("LLM labelling failed" in i["message"] for i in st["issues"]))

    def test_ambiguous_column_uses_llm_choice(self):
        from testgen.grounding import SymbolTable
        from testgen.recipes import _map_field
        st = SymbolTable([{"variable": "driver_panel_auto_gas", "symbol": "s1", "description": "", "aliases": ""},
                          {"variable": "driver_panel_brake", "symbol": "s2", "description": "", "aliases": ""}])
        cfg, _ = load_config()
        table = {"rows": [{"values": {"Driver Panel": ["1"]}}]}
        fld = {"key": "Driver Panel", "path": ["Driver Panel"], "kind": "scalar", "lane_labels": [], "cols": [1]}
        model = FakeModel()
        issues = []
        e = _map_field(fld, "input", table, "T1", st, LLMClient(model, model_id="f"), cfg, issues)
        self.assertEqual((e["source"], e["kind"]), ("llm", "set_input"))
        self.assertIn(e["variable"], ("driver_panel_auto_gas", "driver_panel_brake"))
        # model failure: column stays, is flagged, nothing crashes
        bad = LLMClient(FakeModel(fail={"field_map": ("malformed", None)}), model_id="f", retries=0)
        issues = []
        e = _map_field(fld, "input", table, "T1", st, bad, cfg, issues)
        self.assertEqual((e["source"], e["variable"]), ("default", None))
        self.assertTrue(any("could not be linked" in i["message"] for i in issues))


class StageCrashes(unittest.TestCase):
    def test_stage_crash_uses_fallback(self):
        with mock.patch.object(stages, "assemble_cases", side_effect=RuntimeError("boom")):
            st, code, text, out, _ = run("full")
        self.assertEqual(code, 1)
        self.assertIsNone(st["fatal"])
        self.assertIn("failed", [s["status"] for s in st["stage_log"]])
        self.assertIn("no test cases", text)
        self.assertTrue(os.path.exists(os.path.join(out, "work", "errors.log")))

    def test_crash_in_last_stage_still_writes_file(self):
        with mock.patch.object(stages, "render_spec", side_effect=RuntimeError("boom")):
            st, code, text, _, _ = run("full")
        self.assertIn("RENDER FAILED", text)

    def test_strict_makes_crash_fatal(self):
        with mock.patch.object(stages, "assemble_cases", side_effect=RuntimeError("boom")):
            st, code, _, _, _ = run("full", strict=True)
        self.assertEqual(code, 2)

    def test_load_crash_is_fatal(self):
        with mock.patch.object(stages, "load_blocks", side_effect=RuntimeError("boom")):
            st, code, _, _, _ = run("full")
        self.assertEqual(code, 2)


class ResumeAndRecipes(unittest.TestCase):
    def test_stop_and_resume(self):
        cfg, ci = load_config()
        sy, si = load_symbols(SYMS)
        out = tempfile.mkdtemp(dir=TMP)
        rd = os.path.join(out, "r")
        cl = lambda: LLMClient(FakeModel(), model_id="fake")
        st, code, _ = run_pipeline(doc("full"), out, cfg, sy, cl(), recipe_dir=rd, stop_after=3)
        self.assertFalse(os.path.exists(os.path.join(out, "full.tpf")))
        st2, code2, _ = run_pipeline(doc("full"), out, cfg, sy, cl(), recipe_dir=rd, resume_from=4)
        self.assertIsNone(st2["fatal"])
        self.assertEqual(lines(open(os.path.join(out, "full.tpf")).read()), lines(run("full")[2]))
        self.assertIn("resumed", [s["status"] for s in st2["stage_log"]])

    def test_resume_without_checkpoints_is_fatal(self):
        cfg, _ = load_config()
        sy, _ = load_symbols(SYMS)
        out = tempfile.mkdtemp(dir=TMP)
        st, code, _ = run_pipeline(doc("full"), out, cfg, sy, LLMClient(None), resume_from=4)
        self.assertEqual(code, 2)
        self.assertIn("checkpoint", st["fatal"])

    def test_recipe_cache_and_approval(self):
        cfg, _ = load_config()
        sy, _ = load_symbols(SYMS)
        out = tempfile.mkdtemp(dir=TMP)
        rd = os.path.join(out, "r")
        run_pipeline(doc("full"), out, cfg, sy, LLMClient(FakeModel(), model_id="f"), recipe_dir=rd)
        for f in os.listdir(rd):                                   # approve all recipes
            p = os.path.join(rd, f)
            data = json.load(open(p))
            data["approved"] = True
            json.dump(data, open(p, "w"))
        st, _, _ = run_pipeline(doc("full"), out, cfg, sy, LLMClient(None), recipe_dir=rd)
        self.assertTrue(all(r["from_cache"] for r in st["recipes"].values()))
        self.assertFalse(any("not approved" in i["message"] for i in st["issues"]))

    def test_corrupt_cache_is_rebuilt(self):
        cfg, _ = load_config()
        sy, _ = load_symbols(SYMS)
        out = tempfile.mkdtemp(dir=TMP)
        rd = os.path.join(out, "r")
        run_pipeline(doc("full"), out, cfg, sy, LLMClient(None), recipe_dir=rd)
        for f in os.listdir(rd):
            open(os.path.join(rd, f), "w").write("{broken")
        st, code, _ = run_pipeline(doc("full"), out, cfg, sy, LLMClient(None), recipe_dir=rd)
        self.assertIsNone(st["fatal"])
        self.assertFalse(any(r["from_cache"] for r in st["recipes"].values()))


class Engines(unittest.TestCase):
    def setUp(self):
        self.ref = lines(run("full")[2])

    def tearDown(self):
        fake_langgraph.uninstall(getattr(self, "g", None))

    def test_langgraph_engine_via_stub(self):
        self.g = fake_langgraph.install()
        st, code, text, _, eng = run("full", engine="langgraph")
        self.assertEqual(eng, "langgraph")
        self.assertEqual(lines(text), self.ref)
        self.assertEqual(len(st["stage_log"]), 9)                 # reducers appended every node's log

    def test_stop_after_with_langgraph(self):
        self.g = fake_langgraph.install()
        st, _, text, _, eng = run("full", engine="langgraph", stop_after=2)
        self.assertEqual(len(st["stage_log"]), 3)
        self.assertIsNone(text)

    def test_langgraph_missing(self):
        _, code, _, _, _ = run("full", engine="langgraph")
        self.assertEqual(code, 2)
        _, code, text, _, eng = run("full", engine="auto")
        self.assertEqual(eng, "sequential")

    def test_engine_failure_falls_back(self):
        self.g = fake_langgraph.install(broken=True)
        st, code, text, _, eng = run("full", engine="auto")
        self.assertEqual(eng, "sequential")
        self.assertEqual(lines(text), self.ref)
        self.assertTrue(any("re-ran with the sequential engine" in i["message"] for i in st["issues"]))


class CLI(unittest.TestCase):
    def sh(self, *args):
        return subprocess.run([sys.executable, "-m", "testgen"] + list(args), cwd=ROOT, capture_output=True, text=True)

    def test_run_no_llm(self):
        out = os.path.join(TMP, "cli_out")
        r = self.sh("run", doc("full"), "--symbols", SYMS, "--backend", "none", "--out", out)
        self.assertEqual(r.returncode, 1, r.stderr)
        self.assertTrue(os.path.exists(os.path.join(out, "full.tpf")))
        r2 = self.sh("render", os.path.join(out, "full.spec.json"), "--out", os.path.join(out, "again.tpf"))
        self.assertIn("wrote", r2.stdout)
        self.assertEqual(open(os.path.join(out, "again.tpf")).read(), open(os.path.join(out, "full.tpf")).read())
        r3 = self.sh("eval", os.path.join(out, "full.tpf"), os.path.join(out, "again.tpf"))
        self.assertIn("f1 1.000", r3.stdout)

    def test_tables_command(self):
        r = self.sh("tables", doc("full"))
        self.assertEqual(r.returncode, 0)
        self.assertIn("4 header rows", r.stdout)

    def test_check_and_errors(self):
        self.assertEqual(self.sh("check", "--symbols", SYMS, "--backend", "none").returncode, 0)
        self.assertEqual(self.sh("run", "/nope.docx", "--symbols", SYMS, "--backend", "none").returncode, 2)
        self.assertEqual(self.sh("run", doc("full"), "--symbols", "/nope.csv", "--backend", "none").returncode, 2)
        bad = os.path.join(TMP, "bad.json")
        open(bad, "w").write("{oops")
        self.assertEqual(self.sh("run", doc("full"), "--symbols", SYMS, "--config", bad).returncode, 2)
        self.assertEqual(self.sh("run", doc("full"), "--symbols", SYMS, "--backend", "none", "--resume-from", "99").returncode, 2)

    def test_unreachable_backend_still_finishes(self):
        cfg = os.path.join(TMP, "c.json")
        json.dump({"llm": {"retries": 0, "timeout": 5}}, open(cfg, "w"))
        r = self.sh("run", doc("full"), "--symbols", SYMS, "--config", cfg, "--backend", "ollama",
                    "--base-url", "http://127.0.0.1:9", "--out", os.path.join(TMP, "cli_dead"))
        self.assertIn(r.returncode, (0, 1), r.stderr)                 # no model reachable: rules take over


if __name__ == "__main__":
    unittest.main()

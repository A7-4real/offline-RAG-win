"""Builds synthetic .docx test descriptions with merged-header tables.

The layouts imitate the real ones described in the project chat: an index list,
an author table, a requirements table, initialization text, a complex INPUT
table (merged headers, sub-columns), a separate complex EXPECTED-OUTPUT table
(three merged header rows + a lane counter row 1..4), constraint paragraphs.
"""
from __future__ import annotations

import os
from typing import List, Optional, Sequence, Tuple

from docx import Document
from docx.shared import Pt

HeaderCell = Tuple[str, int, int]       # (text, colspan, rowspan)


def make_table(doc: Document, header: Sequence[Sequence[HeaderCell]], data: Sequence[Sequence[str]],
               ncols: int):
    """Create a table with merged header cells. Header rows list cells left to
    right; positions covered by an earlier vertical span are skipped."""
    n_h = len(header)
    table = doc.add_table(rows=n_h + len(data), cols=ncols)
    table.style = "Table Grid"
    occupied = set()
    for r, row in enumerate(header):
        c = 0
        for text, cs, rs in row:
            while (r, c) in occupied:
                c += 1
            cell = table.cell(r, c)
            if cs > 1 or rs > 1:
                cell = cell.merge(table.cell(r + rs - 1, c + cs - 1))
            cell.text = text
            for rr in range(r, r + rs):
                for cc in range(c, c + cs):
                    occupied.add((rr, cc))
            c += cs
    for i, values in enumerate(data):
        for c, value in enumerate(values):
            table.cell(n_h + i, c).text = value
    return table


# -- the complex EXPECTED-OUTPUT table (20 grid columns, 4 header rows) ------------
def expected_header() -> List[List[HeaderCell]]:
    return [
        [("Row", 1, 4), ("Section A", 9, 1), ("Section B", 5, 1), ("Section C", 5, 1)],
        [("Power Status", 1, 3), ("Step Buffer", 8, 1), ("Mode", 1, 1), ("Selected", 4, 2),
         ("Pattern", 1, 1), ("Output", 4, 2)],
        [("Result", 4, 1), ("Count", 4, 1), ("M", 1, 2), ("P", 1, 2)],
        [(str(i), 1, 1) for i in (1, 2, 3, 4)] * 2 + [(str(i), 1, 1) for i in (1, 2, 3, 4)] * 2,
    ]


def expected_rows(n: int = 4) -> List[List[str]]:
    base = [
        ["1", "0", "1", "1", "1", "1", "1", "0", "1", "0", "2", "0", "0", "0", "0", "0110", "1", "1", "1", "1"],
        ["2", "1", "1", "0", "1", "0", "0", "0", "0", "0", "1", "1", "1", "1", "1", "1010", "0", "0", "0", "0"],
        ["3", "0", "0", "0", "0", "0", "1", "1", "1", "1", "2", "0", "1", "0", "1", "0011", "1", "0", "1", "0"],
        ["4", "1", "1", "1", "1", "1", "0", "0", "0", "0", "3", "1", "1", "1", "1", "1111", "-", "-", "1", "1"],
    ]
    return base[:n]


# -- the complex INPUT table (14 grid columns, 3 header rows) --------------------
def input_header() -> List[List[HeaderCell]]:
    return [
        [("Step", 1, 3), ("Panel Inputs", 6, 1), ("Seat Inputs", 4, 1), ("Timing", 3, 1)],
        [("Auto Gas", 3, 1), ("Brake", 3, 1), ("Seat Prog", 4, 1), ("Delay", 1, 2), ("Hold", 1, 2),
         ("Remarks", 1, 2)],
        [(str(i), 1, 1) for i in (1, 2, 3)] * 2 + [(str(i), 1, 1) for i in (1, 2, 3, 4)],
    ]


def input_rows(n: int = 4) -> List[List[str]]:
    base = [
        ["1", "3", "3", "3", "0", "0", "0", "1", "1", "1", "1", "10", "5", "first"],
        ["2", "2", "2", "2", "1", "1", "1", "0", "0", "0", "0", "20", "5", "second"],
        ["3", "1", "1", "1", "0", "0", "0", "1", "0", "1", "0", "30", "5", ""],
        ["4", "0", "0", "0", "1", "1", "1", "1", "1", "1", "1", "40", "5", "last"],
    ]
    return base[:n]


SYMBOLS_CSV = """variable,symbol,description,aliases
inspect_fail,if_sym,inspect failure flag,
pc_page,pc_pg,page,
vehicle_mode,pc_cs,vehicle mode,mode|veh mode
power_status,dps_sym,discrete power status,Power Status
step_buffer_result,sbr_sym,,Step Buffer Result
step_buffer_count,sbc_sym,,Step Buffer Count
mode_m,mm_sym,,Mode M
selected_value,sel_sym,,Selected
pattern_p,pp_sym,,Pattern P
output_value,out_sym,,Output
driver_panel_auto_gas,l_seat_at_prog,,Panel Inputs Auto Gas
driver_panel_brake,l_brake,,Panel Inputs Brake
seat_prog,l_seat_prog,,Seat Inputs Seat Prog
delay_ms,t_delay,,Timing Delay|Delay
hold_ms,t_hold,,Timing Hold|Hold
"""


def _heading(doc, text, level=1, style_headings=True):
    if style_headings:
        doc.add_heading(text, level=level)
    else:                                   # bold paragraph, no heading style
        p = doc.add_paragraph()
        run = p.add_run(text)
        run.bold = True
        run.font.size = Pt(14)


def build_doc(path: str, variant: str = "full") -> str:
    """variants: full | no_headings | reordered | extra_table | row_mismatch |
    prose_only | no_tables | tracked_noise"""
    doc = Document()
    sh = variant != "no_headings"
    n_in = 3 if variant == "row_mismatch" else 4
    sections = {}

    def index():
        _heading(doc, "Index", 1, sh)
        for item in ("1 Introduction", "2 Initialization", "3 Test Inputs", "4 Expected Outputs"):
            doc.add_paragraph(item, style="List Bullet")

    def info():
        _heading(doc, "Document Information", 1, sh)
        make_table(doc, [[("Author", 1, 1), ("Date", 1, 1), ("Version", 1, 1)]],
                   [["A. Writer", "2026-01-01", "1.0"]], 3)

    def reqs():
        _heading(doc, "Requirements", 1, sh)
        make_table(doc, [[("Req ID", 1, 1), ("Text", 1, 1)]], [["R-1", "The system shall boot."]], 2)

    def init():
        _heading(doc, "Initialization", 1, sh)
        doc.add_paragraph("Boot the system and load the software. Verify that inspect_fail is 0. "
                          "Check the pc_page value manually.")

    def inputs():
        _heading(doc, "Test Inputs", 1, sh)
        doc.add_paragraph("Set the following inputs for every test step.")
        if variant != "prose_only" and variant != "no_tables":
            make_table(doc, input_header(), input_rows(n_in), 14)
        else:
            doc.add_paragraph("Set Auto Gas to 3 and Brake to 0 in step one.")

    def expected():
        _heading(doc, "Expected Outputs", 1, sh)
        if variant != "prose_only" and variant != "no_tables":
            make_table(doc, expected_header(), expected_rows(4), 20)
        else:
            doc.add_paragraph("Power status must be 0 in step one.")

    def constraints():
        _heading(doc, "Constraints", 1, sh)
        doc.add_paragraph("All tests must run with the vehicle in water mode. "
                          "Inputs must be applied within 2 seconds.")

    def extra():
        _heading(doc, "Appendix Tables", 1, sh)
        make_table(doc, [[("Name", 1, 1), ("Value", 1, 1)]], [["a", "1"], ["b", "2"]], 2)

    order = [index, info, reqs, init, inputs, expected, constraints]
    if variant == "reordered":
        order = [index, info, init, expected, inputs, constraints, reqs]
    if variant == "extra_table":
        order = order + [extra]
    for fn in order:
        fn()
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    doc.save(path)
    return path


def write_symbols(path: str) -> str:
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(SYMBOLS_CSV)
    return path

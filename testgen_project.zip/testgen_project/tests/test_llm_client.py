import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from testgen.llm_client import (LLMClient, LLMDisabled, LLMOutputError, LLMTimeout, LLMTransportError, Reply)

S = {"type": "object", "properties": {"a": {"type": "integer"}}, "required": ["a"], "additionalProperties": False}


class Scripted:
    def __init__(self, *answers):
        self.answers, self.prompts = list(answers), []

    def __call__(self, messages, schema=None):
        self.prompts.append(messages[-1][1])
        a = self.answers.pop(0) if len(self.answers) > 1 else self.answers[0]
        if isinstance(a, Exception):
            raise a
        return a if isinstance(a, Reply) else Reply(a)


def client(t, **kw):
    sleeps = []
    c = LLMClient(t, model_id="m", sleep=sleeps.append, **kw)
    c.sleeps = sleeps
    return c


class Client(unittest.TestCase):
    def test_ok_and_fence(self):
        self.assertEqual(client(Scripted('```json\n{"a": 1}\n```')).ask_json("t", "s", "u", S), {"a": 1})

    def test_retry_gets_feedback(self):
        t = Scripted("nonsense", '{"a": 2}')
        c = client(t)
        self.assertEqual(c.ask_json("t", "s", "TASK: t", S), {"a": 2})
        self.assertIn("previous answer was rejected", t.prompts[1])
        self.assertEqual(c.stats["retries"], 1)

    def test_schema_violation_retries_then_raises(self):
        c = client(Scripted('{"a": "x"}'), retries=2)
        with self.assertRaises(LLMOutputError):
            c.ask_json("t", "s", "u", S)
        self.assertEqual((c.stats["attempts"], c.stats["failures"]), (3, 1))

    def test_truncated_is_rejected(self):
        c = client(Scripted(Reply('{"a": 1}', truncated=True)), retries=1)
        with self.assertRaises(LLMOutputError):
            c.ask_json("t", "s", "u", S)
        self.assertEqual(c.stats["truncated"], 2)

    def test_transport_errors_back_off(self):
        c = client(Scripted(LLMTransportError("down"), LLMTransportError("down"), '{"a": 3}'), backoff=1.0)
        self.assertEqual(c.ask_json("t", "s", "u", S), {"a": 3})
        self.assertEqual(c.sleeps, [1.0, 2.0])

    def test_unexpected_exception_is_wrapped(self):
        c = client(Scripted(ValueError("weird")), retries=0)
        with self.assertRaises(LLMTransportError):
            c.ask_json("t", "s", "u", S)

    def test_bad_return_type(self):
        c = client(lambda m, s=None: 42, retries=0)
        with self.assertRaises(LLMTransportError):
            c.ask_json("t", "s", "u", S)

    def test_timeout(self):
        import time
        c = client(lambda m, s=None: (time.sleep(0.3), Reply("{}"))[1], timeout=0.05, retries=0)
        with self.assertRaises(LLMTimeout):
            c.ask_json("t", "s", "u", S)
        self.assertEqual(c.stats["timeouts"], 1)

    def test_semantic_check(self):
        c = client(Scripted('{"a": 1}', '{"a": 5}'))
        self.assertEqual(c.ask_json("t", "s", "u", S, check=lambda p: [] if p["a"] > 3 else ["a must be > 3"]), {"a": 5})

    def test_cache(self):
        d = tempfile.mkdtemp()
        t = Scripted('{"a": 1}')
        c = client(t, cache_dir=d)
        c.ask_json("t", "s", "u", S)
        c.ask_json("t", "s", "u", S)
        self.assertEqual((len(t.prompts), c.stats["cache_hits"]), (1, 1))
        for f in os.listdir(d):                                     # corrupt cache file: recompute, no crash
            open(os.path.join(d, f), "w").write("{bad")
        c.ask_json("t", "s", "u", S)
        self.assertEqual(len(t.prompts), 2)

    def test_cache_key_depends_on_model_and_prompt(self):
        d = tempfile.mkdtemp()
        t = Scripted('{"a": 1}')
        LLMClient(t, model_id="m1", cache_dir=d).ask_json("t", "s", "u", S)
        LLMClient(t, model_id="m2", cache_dir=d).ask_json("t", "s", "u", S)
        self.assertEqual(len(t.prompts), 2)

    def test_disabled(self):
        c = LLMClient(None)
        self.assertFalse(c.enabled)
        with self.assertRaises(LLMDisabled):
            c.ask_json("t", "s", "u", S)
        with self.assertRaises(LLMDisabled):
            c.ask_text("t", "s", "u")

    def test_ask_text(self):
        self.assertEqual(client(Scripted("  hello ")).ask_text("t", "s", "u"), "hello")
        with self.assertRaises(LLMOutputError):
            client(Scripted(""), retries=1).ask_text("t", "s", "u")

    def test_log_written_and_unwritable_log_ignored(self):
        d = tempfile.mkdtemp()
        c = client(Scripted('{"a": 1}'), log_path=os.path.join(d, "log.jsonl"))
        c.ask_json("t", "s", "u", S)
        self.assertTrue(os.path.getsize(os.path.join(d, "log.jsonl")) > 0)
        client(Scripted('{"a": 1}'), log_path="/proc/nope/log.jsonl").ask_json("t", "s", "u", S)


if __name__ == "__main__":
    unittest.main()

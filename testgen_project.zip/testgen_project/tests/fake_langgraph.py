"""A stand-in for `langgraph` used ONLY in tests.

It imitates the API surface testgen/graph.py uses (StateGraph, START, END,
add_node, add_edge, add_conditional_edges, compile, invoke) and enforces the
same rules the real library enforces: nodes must exist before edges point at
them, every node needs an outgoing edge, node updates must be a non-empty dict,
list reducers come from the Annotated[...] hints of the state class.
It cannot prove compatibility with the real library; it proves the wiring code
is self-consistent.
"""
import sys
import types
import typing

START = "__start__"
END = "__end__"


class StateGraph:
    def __init__(self, schema):
        self.schema = schema
        self.nodes = {}
        self.edges = {}
        self.cond = {}
        hints = typing.get_type_hints(schema, include_extras=True)
        self.reducers = {}
        for key, hint in hints.items():
            meta = getattr(hint, "__metadata__", None)
            if meta:
                self.reducers[key] = meta[0]

    def add_node(self, name, fn):
        if name in self.nodes or name in (START, END):
            raise ValueError("bad node name %s" % name)
        self.nodes[name] = fn

    def add_edge(self, a, b):
        if a != START and a not in self.nodes:
            raise ValueError("unknown node %s" % a)
        if b != END and b not in self.nodes:
            raise ValueError("unknown node %s" % b)
        self.edges[a] = b

    def add_conditional_edges(self, src, path, path_map=None):
        if src not in self.nodes:
            raise ValueError("unknown node %s" % src)
        for target in (path_map or {}).values():
            if target != END and target not in self.nodes:
                raise ValueError("unknown target %s" % target)
        self.cond[src] = (path, path_map)

    def compile(self):
        for name in self.nodes:
            if name not in self.edges and name not in self.cond:
                raise ValueError("node %s has no outgoing edge" % name)
        if START not in self.edges:
            raise ValueError("no entry point")
        return _Compiled(self)


class _Compiled:
    def __init__(self, graph):
        self.g = graph

    def invoke(self, state, config=None):
        g = self.g
        state = dict(state)
        current = g.edges[START]
        steps = 0
        limit = (config or {}).get("recursion_limit", 25)
        while current != END:
            steps += 1
            if steps > limit:
                raise RuntimeError("recursion limit")
            update = g.nodes[current](state)
            if not isinstance(update, dict) or not update:
                raise ValueError("InvalidUpdateError: node %s returned no update" % current)
            for k, v in update.items():
                if k in g.reducers:
                    state[k] = g.reducers[k](state.get(k, []), v)
                else:
                    state[k] = v
            if current in g.cond:
                path, pmap = g.cond[current]
                target = path(state)
                if pmap is not None and target not in pmap:
                    raise ValueError("router returned %r not in map" % (target,))
                current = pmap[target] if pmap else target
            else:
                current = g.edges[current]
        return state


def install(broken=False):
    """Put the fake into sys.modules. broken=True makes invoke() raise."""
    mod = types.ModuleType("langgraph")
    graph = types.ModuleType("langgraph.graph")
    graph.StateGraph, graph.START, graph.END = StateGraph, START, END
    if broken:
        def bad(self, state, config=None):
            raise RuntimeError("engine exploded")
        _Compiled_invoke = _Compiled.invoke
        _Compiled.invoke = bad
        graph._restore = lambda: setattr(_Compiled, "invoke", _Compiled_invoke)
    mod.graph = graph
    sys.modules["langgraph"] = mod
    sys.modules["langgraph.graph"] = graph
    return graph


def uninstall(graph=None):
    if graph is not None and hasattr(graph, "_restore"):
        graph._restore()
    sys.modules.pop("langgraph", None)
    sys.modules.pop("langgraph.graph", None)

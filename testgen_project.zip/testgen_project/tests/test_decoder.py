import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

from synth_docs import (expected_header, expected_rows, input_header, input_rows, make_table)
from testgen.table_decoder import decode_table, flatten_text, to_markdown


def decode(header, rows, ncols, **kw):
    doc = Document()
    t = make_table(doc, header, rows, ncols)
    return decode_table(t._tbl, kw.get("options"), kw.get("dont_care", ("", "-", "x")))


class Expected(unittest.TestCase):
    def setUp(self):
        self.d = decode(expected_header(), expected_rows(), 20)
        self.f = {f["key"]: f for f in self.d["fields"]}

    def test_shape(self):
        self.assertEqual((self.d["n_header_rows"], self.d["n_cols"], self.d["n_rows"], self.d["id_column"]), (4, 20, 4, True))

    def test_fields(self):
        self.assertEqual(list(self.f), [
            "Section A / Power Status", "Section A / Step Buffer / Result", "Section A / Step Buffer / Count",
            "Section B / Mode / M", "Section B / Selected", "Section C / Pattern / P", "Section C / Output"])
        self.assertEqual(self.f["Section A / Step Buffer / Result"]["kind"], "lanes")
        self.assertEqual(self.f["Section A / Step Buffer / Result"]["lane_labels"], ["1", "2", "3", "4"])
        self.assertEqual(self.f["Section A / Power Status"]["kind"], "scalar")

    def test_values(self):
        r1 = self.d["rows"][0]["values"]
        self.assertEqual(r1["Section A / Step Buffer / Count"], ["1", "0", "1", "0"])
        self.assertEqual(r1["Section C / Pattern / P"], ["0110"])           # leading zero kept
        self.assertEqual(self.d["rows"][3]["values"]["Section C / Output"], [None, None, "1", "1"])  # "-" = dont care

    def test_row_ids(self):
        self.assertEqual([r["row_id"] for r in self.d["rows"]], ["1", "2", "3", "4"])

    def test_layout_hash_stable(self):
        again = decode(expected_header(), expected_rows(2), 20)
        self.assertEqual(again["layout_hash"], self.d["layout_hash"])

    def test_markdown_and_text(self):
        self.assertIn("Lane 4", to_markdown(self.d))
        self.assertIn("Row 1:", flatten_text(self.d))
        self.assertIn("#1", to_markdown(self.d, "flat"))


class Inputs(unittest.TestCase):
    def test_input_table(self):
        d = decode(input_header(), input_rows(), 14)
        keys = [f["key"] for f in d["fields"]]
        self.assertIn("Panel Inputs / Auto Gas", keys)
        self.assertIn("Timing / Remarks", keys)
        self.assertEqual({f["key"]: f for f in d["fields"]}["Seat Inputs / Seat Prog"]["lane_labels"], ["1", "2", "3", "4"])
        self.assertEqual(d["n_header_rows"], 3)


class Simple(unittest.TestCase):
    def test_single_header_no_id(self):
        d = decode([[("Name", 1, 1), ("Value", 1, 1)]], [["a", "1"], ["b", "2"]], 2)
        self.assertEqual((d["n_header_rows"], d["id_column"], d["n_rows"]), (1, False, 2))
        self.assertEqual(d["rows"][1]["row_id"], "2")                      # ordinal when no id column

    def test_header_override(self):
        hdr = [[("G", 2, 1)], [("a", 1, 1), ("b", 1, 1)]]
        d = decode(hdr, [["1", "2"]], 2, options={"header_rows": 2})
        self.assertEqual([f["key"] for f in d["fields"]], ["G / a", "G / b"])

    def test_header_override_too_large(self):
        d = decode([[("A", 1, 1)]], [["1"]], 1, options={"header_rows": 9})
        self.assertEqual(d["n_rows"], 0)
        self.assertTrue(any("larger" in w for w in d["warnings"]))

    def test_subheader_without_merge_rule(self):
        hdr = [[("Group", 2, 1), ("Other", 1, 1)], [("x", 1, 1), ("y", 1, 1), ("z", 1, 1)]]
        d = decode(hdr, [["1", "2", "3"]], 3)
        self.assertEqual(d["n_header_rows"], 2)

    def test_header_only_table(self):
        d = decode([[("A", 1, 1), ("B", 1, 1)]], [], 2)
        self.assertEqual(d["n_rows"], 0)
        self.assertTrue(any("no data rows" in w for w in d["warnings"]))

    def test_blank_rows_skipped(self):
        d = decode([[("A", 1, 1), ("B", 1, 1)]], [["1", "2"], ["", ""], ["3", "4"]], 2)
        self.assertEqual(d["n_rows"], 2)

    def test_duplicate_headers_get_unique_keys(self):
        d = decode([[("A", 1, 1), ("A", 1, 1)]], [["1", "2"]], 2)
        self.assertEqual([f["key"] for f in d["fields"]], ["A", "A [2]"])

    def test_unnamed_column(self):
        d = decode([[("A", 1, 1), ("", 1, 1)]], [["1", "2"]], 2)
        self.assertEqual(d["fields"][1]["key"], "col2")

    def test_numeric_header_without_parent_is_scalar(self):
        d = decode([[("1", 1, 1), ("2", 1, 1)]], [["a", "b"]], 2)
        self.assertTrue(all(f["kind"] == "scalar" for f in d["fields"]))

    def test_transpose(self):
        doc = Document()
        t = make_table(doc, [[("Name", 1, 1), ("Case 1", 1, 1), ("Case 2", 1, 1)]], [["x", "1", "2"], ["y", "3", "4"]], 3)
        d = decode_table(t._tbl, {"transpose": True, "header_rows": 1})
        self.assertEqual([f["key"] for f in d["fields"]], ["Name"] if False else [f["key"] for f in d["fields"]])
        self.assertEqual(d["n_rows"], 2)

    def test_id_column_forced_off(self):
        d = decode(expected_header(), expected_rows(), 20, options={"id_column": False})
        self.assertFalse(d["id_column"])

    def test_sequential_numbers_without_header_match_are_id(self):
        d = decode([[("Case", 1, 1), ("V", 1, 1)]], [["1", "a"], ["2", "b"], ["3", "c"]], 2)
        self.assertTrue(d["id_column"])

    def test_non_sequential_numbers_are_data(self):
        d = decode([[("Case", 1, 1), ("V", 1, 1)]], [["5", "a"], ["9", "b"]], 2)
        self.assertFalse(d["id_column"])

    def test_merged_data_cell_warning(self):
        doc = Document()
        t = make_table(doc, [[("A", 1, 1), ("B", 1, 1)]], [["1", "2"]], 2)
        t.cell(1, 0).merge(t.cell(1, 1)).text = "same"
        d = decode_table(t._tbl, {})
        self.assertEqual(d["rows"][0]["values"], {"A": ["same"], "B": ["same"]})
        self.assertTrue(any("merged" in w for w in d["warnings"]))


class Malformed(unittest.TestCase):
    def test_orphan_vmerge_continue(self):
        doc = Document()
        t = make_table(doc, [[("A", 1, 1), ("B", 1, 1)]], [["1", "2"]], 2)
        tc = t.rows[1].cells[0]._tc
        pr = tc.get_or_add_tcPr()
        pr.append(OxmlElement("w:vMerge"))                                  # continue without a restart above
        d = decode_table(t._tbl, {})
        self.assertTrue(any("without a start" in w for w in d["warnings"]))

    def test_grid_before(self):
        doc = Document()
        t = make_table(doc, [[("A", 1, 1), ("B", 1, 1), ("C", 1, 1)]], [["1", "2", "3"]], 3)
        tr = t.rows[1]._tr
        pr = tr.get_or_add_trPr()
        gb = OxmlElement("w:gridBefore")
        gb.set(qn("w:val"), "1")
        pr.append(gb)
        tr.remove(tr.findall(qn("w:tc"))[0])
        d = decode_table(t._tbl, {})
        self.assertEqual(d["n_cols"], 3)                                    # padded, no crash

    def test_huge_span_is_clamped(self):
        doc = Document()
        t = make_table(doc, [[("A", 1, 1)]], [["1"]], 1)
        tc = t.rows[0].cells[0]._tc
        pr = tc.get_or_add_tcPr()
        gs = OxmlElement("w:gridSpan")
        gs.set(qn("w:val"), "99999")
        pr.append(gs)
        d = decode_table(t._tbl, {})
        self.assertLessEqual(d["n_cols"], 400)                              # clamped, no crash

    def test_empty_table_element(self):
        doc = Document()
        t = doc.add_table(rows=1, cols=1)
        t._tbl.remove(t._tbl.findall(qn("w:tr"))[0])
        with self.assertRaises(ValueError):
            decode_table(t._tbl, {})


if __name__ == "__main__":
    unittest.main()

# testgen: Word test description -> tpf test file

    pip install -r requirements.txt
    python -m testgen check --symbols symbols.csv --backend ollama --model gemma2:9b   # config + LLM connection
    python -m testgen tables spec.docx                                                 # see how tables decode (no LLM)
    python -m testgen run spec.docx --symbols symbols.csv --config config.json --out out/
    python -m testgen run spec.docx --symbols symbols.csv --backend none               # rules only, no LLM

Read `out/<name>.review.md` after every run. Exit code: 0 clean, 1 items to review, 2 fatal.
Hand-fix `out/<name>.spec.json` and re-render with `python -m testgen render out/<name>.spec.json`.
Resume after fixing a checkpoint: `--resume-from recipes` (stage name or number 0-8).
LM Studio: `--backend lmstudio --model <name> --base-url http://localhost:1234/v1`.
Tests: `python -m unittest discover -s tests -t .`

"""Stage 0: read the .docx in document order and produce blocks.

A *block* is one heading, paragraph, list item or table:
    {"id": "B001", "order": 1, "kind": "heading"|"paragraph"|"list"|"table",
     "text": str, "level": int, "style": str, "heading_source": "style"|"heuristic"|"",
     "table_index": int|None, "table": decoded-table dict | None}

Robustness rules
    - not a .docx / corrupt zip / unreadable  -> FatalError with a clear message
    - no content at all                       -> FatalError
    - a table that cannot be decoded          -> block kept with a flattened text,
                                                 review issue, run continues
    - headings come from styles or outline levels; only if the whole document has
      none, bold/numbered short paragraphs are promoted (and an issue says so)
"""
from __future__ import annotations

import os
import re
from typing import Any, Dict, Iterator, List, Tuple

from docx import Document
from docx.oxml.ns import qn
from docx.text.paragraph import Paragraph

from .issues import FatalError, make_issue
from .table_decoder import decode_table, flatten_text

_NUMBERED_RE = re.compile(r"^\d+(\.\d+){0,4}[.)]?\s+\S")


def _iter_body(parent: Any) -> Iterator[Tuple[str, Any]]:
    """Yield ('p'|'tbl', element) in document order, looking inside content controls."""
    for child in parent:
        if child.tag == qn("w:p"):
            yield "p", child
        elif child.tag == qn("w:tbl"):
            yield "tbl", child
        elif child.tag == qn("w:sdt"):
            content = child.find(qn("w:sdtContent"))
            if content is not None:
                for item in _iter_body(content):
                    yield item


def _p_text(p_el: Any) -> str:
    text = "".join(t.text or "" for t in p_el.iter(qn("w:t")))
    return re.sub(r"\s+", " ", text).strip()


def _style_name(para: Paragraph) -> str:
    try:
        return (para.style.name or "").strip()
    except Exception:                                   # noqa: BLE001 - broken style table
        return ""


def _outline_level(p_el: Any) -> int:
    p_pr = p_el.find(qn("w:pPr"))
    if p_pr is None:
        return -1
    lvl = p_pr.find(qn("w:outlineLvl"))
    if lvl is None:
        return -1
    try:
        return int(lvl.get(qn("w:val")))
    except (TypeError, ValueError):
        return -1


def _is_list(p_el: Any, style: str) -> bool:
    p_pr = p_el.find(qn("w:pPr"))
    has_num = p_pr is not None and p_pr.find(qn("w:numPr")) is not None
    return has_num or style.lower().startswith(("list", "toc"))


def _all_bold(para: Paragraph) -> bool:
    runs = [r for r in para.runs if r.text.strip()]
    return bool(runs) and all(bool(r.bold) for r in runs)


def load_blocks(path: str, cfg: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], List[Dict[str, str]]]:
    """Return (blocks, issues). Raises FatalError for unusable input."""
    issues: List[Dict[str, str]] = []
    if not path or not os.path.isfile(path):
        raise FatalError("input file not found: %s" % path)
    ext = os.path.splitext(path)[1].lower()
    if ext == ".doc":
        raise FatalError("old .doc format is not supported; save the file as .docx first")
    if ext not in (".docx", ".docm", ".dotx"):
        raise FatalError("expected a .docx file, got %r" % ext)
    if os.path.getsize(path) == 0:
        raise FatalError("input file is empty: %s" % path)
    try:
        doc = Document(path)
    except Exception as exc:                            # noqa: BLE001 - python-docx raises many types
        raise FatalError("cannot open %s as a Word document (%s: %s)"
                         % (os.path.basename(path), type(exc).__name__, exc))

    raw: List[Dict[str, Any]] = []
    opts = cfg["table_options"]
    dont_care = cfg["dont_care_values"]
    table_no = 0
    for kind, el in _iter_body(doc.element.body):
        if kind == "p":
            para = Paragraph(el, doc)
            text = _p_text(el)
            if not text:
                continue
            style = _style_name(para)
            low = style.lower()
            level = 0
            heading_source = ""
            block_kind = "paragraph"
            if low.startswith("heading") or low in ("title", "toc heading"):
                match = re.search(r"(\d+)\s*$", style)
                level = int(match.group(1)) if match else 1
                block_kind, heading_source = "heading", "style"
            elif _outline_level(el) >= 0:
                level = _outline_level(el) + 1
                block_kind, heading_source = "heading", "style"
            elif _is_list(el, style):
                block_kind = "list"
            raw.append({"kind": block_kind, "text": text, "level": level, "style": style,
                        "heading_source": heading_source, "table_index": None, "table": None,
                        "_para": para})
        else:
            table_no += 1
            per = opts.get("per_table", {}).get(str(table_no - 1), {})
            merged = dict(opts)
            merged.update({k: v for k, v in per.items()})
            decoded = None
            text = ""
            try:
                decoded = decode_table(el, merged, dont_care)
                text = flatten_text(decoded)
            except Exception as exc:                    # noqa: BLE001 - any failure is non-fatal here
                from docx.table import Table
                try:
                    rows = [[c.text.strip() for c in r.cells] for r in Table(el, doc).rows]
                    text = "\n".join(" | ".join(r) for r in rows)
                except Exception:                       # noqa: BLE001
                    text = ""
                issues.append(make_issue(
                    "review", "load", "table %d could not be decoded: %s" % (table_no, exc),
                    "table %d" % table_no, "fix the table or set table_options.per_table in config.json"))
            for warn in (decoded or {}).get("warnings", []):
                issues.append(make_issue("info", "load", "table %d: %s" % (table_no, warn), "table %d" % table_no))
            if decoded is not None and not decoded["fields"]:
                decoded = None
            raw.append({"kind": "table", "text": text, "level": 0, "style": "", "heading_source": "",
                        "table_index": table_no - 1, "table": decoded, "_para": None})

    if not raw:
        raise FatalError("the document has no text or tables: %s" % os.path.basename(path))

    # Heuristic headings only when the document has no real headings at all.
    if not any(b["kind"] == "heading" for b in raw):
        promoted = 0
        for b in raw:
            if b["kind"] != "paragraph" or len(b["text"]) > 80 or b["text"].endswith((".", ",", ";")):
                continue
            if _all_bold(b["_para"]) or _NUMBERED_RE.match(b["text"]):
                dots = b["text"].split(" ")[0].count(".")
                b["kind"], b["level"], b["heading_source"] = "heading", min(dots + 1, 4), "heuristic"
                promoted += 1
        if promoted:
            issues.append(make_issue("info", "load",
                                     "no heading styles found; %d short bold/numbered paragraphs were treated as headings" % promoted,
                                     fix="use Word heading styles for more reliable sections"))
        else:
            issues.append(make_issue("review", "load", "document has no headings; sections cannot be found by title",
                                     fix="the LLM will label the whole document as one section"))

    width = max(3, len(str(len(raw))))
    blocks: List[Dict[str, Any]] = []
    for i, b in enumerate(raw, start=1):
        b.pop("_para", None)
        b["id"] = "B%0*d" % (width, i)
        b["order"] = i
        blocks.append(b)
    return blocks, issues

"""Stage 5: facts from the paragraphs (initialization hints, constraints).

Test cases come from tables. Paragraphs only contribute
    - hints about the global initialization (functions, checks, manual verifies)
    - constraints / notes
The initialization itself is handled by another file, so by default these are
written to review.md, and only rendered when config emit_global_init is true.

Two LLM passes per text window: (A) rewrite as short lines under fixed headings,
(B) grammar-constrained JSON. Every extracted item must carry `evidence`, a
quote that really occurs in the source; items whose evidence is not found are
dropped and reported (possible hallucination).
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Tuple

from .grounding import normalize
from .issues import make_issue
from .llm_client import LLMClient, LLMError
from .prompts import NOTES_SYSTEM, notes_extract_prompt, notes_normalize_prompt
from .schema import notes_schema

WINDOW_CHARS = 3000


def _windows(texts: List[str], limit: int = WINDOW_CHARS) -> List[str]:
    """Group lines into windows below `limit` characters (never split a line)."""
    out, cur = [], ""
    for t in texts:
        if cur and len(cur) + len(t) + 1 > limit:
            out.append(cur)
            cur = ""
        cur = (cur + "\n" + t) if cur else t
    if cur:
        out.append(cur)
    return out


def _in_source(evidence: str, source: str) -> bool:
    e, s = normalize(evidence), normalize(source)
    return bool(e) and e in s


def extract_notes(blocks: List[Dict[str, Any]], sections: List[Dict[str, Any]], client: LLMClient,
                  cfg: Dict[str, Any]) -> Tuple[Dict[str, Any], List[Dict[str, str]]]:
    issues: List[Dict[str, str]] = []
    notes: Dict[str, Any] = {"init": {"funcs": [], "test_variables": [], "verify_variables": [], "source_sections": []},
                             "constraints": [], "raw": {"initialization": [], "constraints": []}}
    by_id = {b["id"]: b for b in blocks}
    for label in ("initialization", "constraints"):
        lines: List[str] = []
        for sec in sections:
            if sec["label"] != label:
                continue
            if label == "initialization":
                notes["init"]["source_sections"].append(sec["id"])
            for bid in sec["block_ids"]:
                b = by_id[bid]
                if b["text"]:
                    lines.append(b["text"])
        notes["raw"][label] = lines
        if not lines:
            continue
        if not client.enabled:
            issues.append(make_issue("review", "notes", "%s text was not analysed (no LLM); read it in review.md" % label))
            if label == "constraints":
                notes["constraints"] = [{"text": t, "evidence": t} for t in lines]
            continue
        for window in _windows(lines):
            try:
                normalized = client.ask_text("notes_normalize", NOTES_SYSTEM,
                                             notes_normalize_prompt(window, cfg["funcs"]))
                ans = client.ask_json("notes_extract", NOTES_SYSTEM, notes_extract_prompt(window, normalized),
                                      notes_schema(cfg["funcs"]))
            except LLMError as exc:
                issues.append(make_issue("review", "notes", "could not analyse the %s text (%s); read it in review.md" % (label, exc)))
                if label == "constraints":
                    notes["constraints"].extend({"text": t, "evidence": t} for t in window.split("\n"))
                continue
            dropped = 0
            for f in ans["funcs"]:
                if f not in notes["init"]["funcs"]:
                    notes["init"]["funcs"].append(f)
            for item in ans["test_variables"]:
                if _in_source(item["evidence"], window):
                    notes["init"]["test_variables"].append(item)
                else:
                    dropped += 1
            for item in ans["verify_variables"]:
                if _in_source(item["evidence"], window):
                    notes["init"]["verify_variables"].append(item)
                else:
                    dropped += 1
            for item in ans["constraints"]:
                if _in_source(item["evidence"], window):
                    notes["constraints"].append(item)
                else:
                    dropped += 1
            if dropped:
                issues.append(make_issue("review", "notes",
                                         "%d extracted item(s) dropped: their evidence quote is not in the source text" % dropped,
                                         label, "read the %s text in review.md" % label))
    return notes, issues

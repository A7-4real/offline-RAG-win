"""testgen - Word test description -> tpf test file (hybrid LLM + code pipeline)."""
__version__ = "1.0.0"

"""The nine pipeline stages and the wrapper that makes each one safe.

A stage function has the signature   fn(ctx, state) -> (update_dict, issues)
and never talks to LangGraph. `make_node` wraps it so that
    * an exception becomes an issue plus a rule-based fallback result
      (strict mode and the load stage turn it into a fatal error instead)
    * a FatalError stops the run cleanly
    * the result is written to work/NN_<stage>.json (checkpoint)
    * with --resume-from N, stages before N are read from their checkpoints
    * the node always returns a stage_log entry (LangGraph requires a state update)
"""
from __future__ import annotations

import copy
import json
import os
import time
import traceback
from typing import Any, Callable, Dict, List, Optional, Tuple

from .assemble import assemble_cases
from .docx_loader import load_blocks
from .grounding import SymbolTable, choose_with_llm
from .issues import FatalError, dedupe, make_issue
from .llm_client import LLMClient, LLMError
from .notes import extract_notes
from .recipes import build_recipes
from .render import render_spec
from .roles import decide_roles
from .sections import build_sections, label_sections
from .validate import validate_spec


class RunContext:
    """Everything the stages need besides the state: config, symbols, LLM, paths."""

    def __init__(self, cfg: Dict[str, Any], symbols: SymbolTable, client: LLMClient, input_path: str,
                 out_dir: str, recipe_dir: Optional[str] = None, strict: bool = False,
                 resume_from: Optional[int] = None, stop_after: Optional[int] = None) -> None:
        self.cfg = cfg
        self.symbols = symbols
        self.client = client
        self.input_path = input_path
        self.out_dir = out_dir
        self.work_dir = os.path.join(out_dir, "work")
        self.recipe_dir = recipe_dir
        self.strict = strict or bool(cfg.get("strict"))
        self.resume_from = resume_from
        self.stop_after = stop_after
        self.stem = os.path.splitext(os.path.basename(input_path))[0] or "spec"

    def path(self, suffix: str) -> str:
        return os.path.join(self.out_dir, self.stem + suffix)


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def write_json(path: str, data: Any) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2, ensure_ascii=False, default=str)
    os.replace(tmp, path)


def _ground_name(ctx: RunContext, text: str, context: str, issues: List[Dict[str, str]], loc: str
                 ) -> Optional[str]:
    """Free text -> canonical variable (rules first, LLM choice among candidates second)."""
    res = ctx.symbols.resolve(text, ctx.cfg["grounding"])
    if res["status"] in ("exact", "fuzzy"):
        return res["variable"]
    if res["status"] == "ambiguous" and ctx.client.enabled:
        try:
            return choose_with_llm(ctx.client, ctx.symbols, text, res["candidates"], context)
        except LLMError as exc:
            issues.append(make_issue("review", "ground", "LLM could not choose a variable for %r (%s)" % (text, exc), loc))
    issues.append(make_issue("review", "ground", "no variable found for %r" % text, loc,
                             "add it to symbols.csv (variable or aliases)"))
    return None


# ---------------------------------------------------------------------------
# stage functions
# ---------------------------------------------------------------------------
def stage_load(ctx: RunContext, state: Dict[str, Any]) -> Tuple[Dict[str, Any], List[Dict[str, str]]]:
    blocks, issues = load_blocks(ctx.input_path, ctx.cfg)
    return {"blocks": blocks}, issues


def stage_sections(ctx: RunContext, state: Dict[str, Any]) -> Tuple[Dict[str, Any], List[Dict[str, str]]]:
    sections = build_sections(state.get("blocks", []), int(ctx.cfg["sections"]["preview_chars"]))
    issues = label_sections(sections, ctx.client, ctx.cfg)
    return {"sections": sections}, issues


def stage_roles(ctx: RunContext, state: Dict[str, Any]) -> Tuple[Dict[str, Any], List[Dict[str, str]]]:
    roles, issues = decide_roles(state.get("blocks", []), state.get("sections", []), ctx.client, ctx.cfg)
    return {"roles": roles}, issues


def stage_recipes(ctx: RunContext, state: Dict[str, Any]) -> Tuple[Dict[str, Any], List[Dict[str, str]]]:
    recipes, issues = build_recipes(state.get("blocks", []), state.get("roles", {}), ctx.symbols,
                                    ctx.client, ctx.cfg, ctx.recipe_dir)
    return {"recipes": recipes}, issues


def stage_assemble(ctx: RunContext, state: Dict[str, Any]) -> Tuple[Dict[str, Any], List[Dict[str, str]]]:
    cases, issues = assemble_cases(state.get("blocks", []), state.get("roles", {}),
                                   state.get("recipes", {}), ctx.cfg)
    return {"cases": cases}, issues


def stage_notes(ctx: RunContext, state: Dict[str, Any]) -> Tuple[Dict[str, Any], List[Dict[str, str]]]:
    notes, issues = extract_notes(state.get("blocks", []), state.get("sections", []), ctx.client, ctx.cfg)
    return {"notes": notes}, issues


def _attach_symbols(ctx: RunContext, cases: List[Dict[str, Any]], issues: List[Dict[str, str]]) -> None:
    """Give every item its symbol; a variable that is not in symbols.csv becomes unresolved."""
    for case in cases:
        for step in case.get("steps", []):
            for bucket in ("set_input", "check_expected_output", "verify_only"):
                for item in step.get(bucket, []):
                    var = item.get("variable")
                    if var and not ctx.symbols.has_variable(var):
                        issues.append(make_issue("error", "ground", "variable %r is not in symbols.csv" % var,
                                                 item.get("source", "")))
                        item["variable"] = None
                    item["symbol"] = ctx.symbols.symbol_for(item.get("variable"))


def stage_ground(ctx: RunContext, state: Dict[str, Any]) -> Tuple[Dict[str, Any], List[Dict[str, str]]]:
    issues: List[Dict[str, str]] = []
    cases = copy.deepcopy(state.get("cases", []))
    _attach_symbols(ctx, cases, issues)
    for case in cases:
        grounded = []
        for name in case.get("verify_test_case_environment", []):
            text = name if isinstance(name, str) else name.get("variable_text", "")
            var = _ground_name(ctx, text, "environment variable to verify in test case %s" % case["id"],
                               issues, "case %s" % case["id"])
            grounded.append({"variable_text": text, "variable": var, "symbol": ctx.symbols.symbol_for(var)})
        case["verify_test_case_environment"] = grounded
    notes = state.get("notes", {})
    init = notes.get("init", {})
    g_init: Dict[str, Any] = {"funcs": [], "test_variables": [], "verify_variables": []}
    known = ctx.cfg.get("funcs") or []
    for f in init.get("funcs", []):
        if known and f not in known:
            issues.append(make_issue("review", "ground", "init function %r is not in the configured function list" % f, "global init"))
            continue
        g_init["funcs"].append(f)
    for t in init.get("test_variables", []):
        var = _ground_name(ctx, t["variable"], "variable checked during global initialization", issues, "global init")
        g_init["test_variables"].append({"variable_text": t["variable"], "expected_value": t["expected_value"],
                                         "variable": var, "symbol": ctx.symbols.symbol_for(var)})
    for v in init.get("verify_variables", []):
        var = _ground_name(ctx, v["variable"], "variable verified manually during global initialization", issues, "global init")
        g_init["verify_variables"].append({"variable_text": v["variable"], "variable": var,
                                           "symbol": ctx.symbols.symbol_for(var)})
    spec = {"version": 1,
            "meta": {"source": os.path.basename(ctx.input_path), "model": ctx.client.model_id,
                     "generated": time.strftime("%Y-%m-%d %H:%M:%S"), "n_cases": len(cases)},
            "global_init": g_init,
            "constraints": [c.get("text", "") for c in notes.get("constraints", [])],
            "test_cases": cases}
    write_json(os.path.join(ctx.out_dir, ctx.stem + ".spec.json"), spec)
    return {"spec": spec}, issues


def stage_validate(ctx: RunContext, state: Dict[str, Any]) -> Tuple[Dict[str, Any], List[Dict[str, str]]]:
    issues = validate_spec(state.get("spec", {}), state.get("sections", []), state.get("roles", {}),
                           state.get("recipes", {}), ctx.cfg)
    return {"validation": issues}, issues


def stage_render(ctx: RunContext, state: Dict[str, Any]) -> Tuple[Dict[str, Any], List[Dict[str, str]]]:
    lines, issues, stats = render_spec(state.get("spec", {}), ctx.cfg)
    path = ctx.path(".tpf")
    os.makedirs(ctx.out_dir, exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="\n") as handle:
        handle.write("\n".join(lines) + "\n")
    os.replace(tmp, path)
    return {"outputs": {"tpf": path, "render_stats": stats}}, issues


STAGES: List[Tuple[str, Callable[..., Any]]] = [
    ("load", stage_load), ("sections", stage_sections), ("roles", stage_roles),
    ("recipes", stage_recipes), ("assemble", stage_assemble), ("notes", stage_notes),
    ("ground", stage_ground), ("validate", stage_validate), ("render", stage_render),
]
STAGE_NAMES = [n for n, _ in STAGES]


# ---------------------------------------------------------------------------
# fallbacks: what a stage returns when it crashed (must never raise itself)
# ---------------------------------------------------------------------------
def _disabled_client() -> LLMClient:
    return LLMClient(None, model_id="none")


def fallback_for(ctx: RunContext, name: str, state: Dict[str, Any]) -> Tuple[Dict[str, Any], List[Dict[str, str]]]:
    try:
        if name == "sections":
            sections = build_sections(state.get("blocks", []), int(ctx.cfg["sections"]["preview_chars"]))
            return {"sections": sections}, label_sections(sections, _disabled_client(), ctx.cfg)
        if name == "roles":
            roles, iss = decide_roles(state.get("blocks", []), state.get("sections", []), _disabled_client(), ctx.cfg)
            return {"roles": roles}, iss
        if name == "recipes":
            return {"recipes": {}}, []
        if name == "assemble":
            return {"cases": []}, []
        if name == "notes":
            return {"notes": {"init": {"funcs": [], "test_variables": [], "verify_variables": [], "source_sections": []},
                              "constraints": [], "raw": {"initialization": [], "constraints": []}}}, []
        if name == "ground":
            cases = copy.deepcopy(state.get("cases", []))
            iss: List[Dict[str, str]] = []
            _attach_symbols(ctx, cases, iss)
            for case in cases:
                case["verify_test_case_environment"] = [
                    {"variable_text": str(v), "variable": None, "symbol": None}
                    for v in case.get("verify_test_case_environment", [])]
            return {"spec": {"version": 1, "meta": {"source": os.path.basename(ctx.input_path)},
                             "global_init": {}, "constraints": [], "test_cases": cases}}, iss
        if name == "validate":
            return {"validation": []}, []
        if name == "render":
            path = ctx.path(".tpf")
            os.makedirs(ctx.out_dir, exist_ok=True)
            with open(path, "w", encoding="utf-8") as handle:
                handle.write("# RENDER FAILED - see review.md and work/errors.log\n")
            return {"outputs": {"tpf": path, "render_stats": {}}}, []
    except Exception:                                   # noqa: BLE001
        pass
    return {}, []


# ---------------------------------------------------------------------------
# node wrapper
# ---------------------------------------------------------------------------
def _ckpt_path(ctx: RunContext, idx: int, name: str) -> str:
    return os.path.join(ctx.work_dir, "%02d_%s.json" % (idx, name))


def make_node(ctx: RunContext, idx: int, name: str, fn: Callable[..., Any]) -> Callable[[Dict[str, Any]], Dict[str, Any]]:
    def node(state: Dict[str, Any]) -> Dict[str, Any]:
        if state.get("fatal"):
            return {"stage_log": [{"stage": name, "status": "skipped", "seconds": 0.0}]}
        started = time.time()
        status = "ok"
        try:
            if ctx.resume_from is not None and idx < ctx.resume_from:
                path = _ckpt_path(ctx, idx, name)
                if not os.path.isfile(path):
                    raise FatalError("cannot resume from stage %d: checkpoint %s is missing; run the earlier stages first"
                                     % (ctx.resume_from, path))
                try:
                    with open(path, "r", encoding="utf-8") as handle:
                        saved = json.load(handle)
                    update, issues = saved["update"], saved.get("issues", [])
                except (OSError, ValueError, KeyError) as exc:
                    raise FatalError("checkpoint %s is unreadable (%s)" % (path, exc))
                status = "resumed"
            else:
                update, issues = fn(ctx, state)
                try:
                    write_json(_ckpt_path(ctx, idx, name), {"stage": name, "update": update, "issues": issues})
                except OSError:
                    issues = list(issues) + [make_issue("info", name, "checkpoint could not be written")]
        except FatalError as exc:
            return {"fatal": str(exc), "issues": [make_issue("error", name, str(exc))],
                    "stage_log": [{"stage": name, "status": "fatal", "seconds": round(time.time() - started, 3)}]}
        except Exception as exc:                        # noqa: BLE001 - a stage must never kill the run
            trace = traceback.format_exc()
            try:
                os.makedirs(ctx.work_dir, exist_ok=True)
                with open(os.path.join(ctx.work_dir, "errors.log"), "a", encoding="utf-8") as handle:
                    handle.write("=== stage %s ===\n%s\n" % (name, trace))
            except OSError:
                pass
            msg = "stage %r failed: %s: %s" % (name, type(exc).__name__, exc)
            if ctx.strict or name == "load":
                return {"fatal": msg, "issues": [make_issue("error", name, msg)],
                        "stage_log": [{"stage": name, "status": "fatal", "seconds": round(time.time() - started, 3)}]}
            update, extra = fallback_for(ctx, name, state)
            issues = [make_issue("error", name, msg, fix="see work/errors.log; a rule-based fallback was used")] + list(extra)
            status = "failed"
            try:
                write_json(_ckpt_path(ctx, idx, name), {"stage": name, "update": update, "issues": issues})
            except OSError:
                pass
        out: Dict[str, Any] = dict(update)
        out["issues"] = list(issues)
        out["stage_log"] = [{"stage": name, "status": status, "seconds": round(time.time() - started, 3)}]
        if ctx.strict and status != "resumed" and any(i["severity"] == "error" for i in issues):
            out["fatal"] = "strict mode: stage %r reported errors" % name
        return out
    node.__name__ = "node_" + name
    return node

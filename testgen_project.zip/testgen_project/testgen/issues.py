"""Issue records and the fatal-error type shared by every stage.

An *issue* is a plain dict so it can be stored in JSON checkpoints and merged
by LangGraph reducers:

    {"severity": "error" | "review" | "info",
     "stage": "load" | "sections" | ...,
     "location": "T2 row 3 / Mode",          # where it happened (free text)
     "message": "what is wrong",
     "fix": "what a human can do about it"}

Severity meaning
    error   something failed or is certainly wrong in the output
    review  output was produced but a human must check it
    info    harmless note (kept for traceability)

Exit codes of the CLI: 0 = clean, 1 = finished with error/review items,
2 = fatal (run could not finish).
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List

SEVERITIES = ("error", "review", "info")


class FatalError(Exception):
    """The run cannot continue (bad input file, bad config, missing checkpoint)."""


def make_issue(severity: str, stage: str, message: str,
               location: str = "", fix: str = "") -> Dict[str, str]:
    """Build one issue dict. Unknown severities are downgraded to 'review'."""
    if severity not in SEVERITIES:
        severity = "review"
    return {
        "severity": severity,
        "stage": str(stage),
        "location": str(location),
        "message": str(message),
        "fix": str(fix),
    }


def dedupe(issues: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Drop exact duplicates (same severity, stage, location, message), keep order."""
    seen = set()
    out: List[Dict[str, Any]] = []
    for item in issues:
        key = (item.get("severity"), item.get("stage"),
               item.get("location"), item.get("message"))
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    return out


def counts(issues: Iterable[Dict[str, Any]]) -> Dict[str, int]:
    """Number of issues per severity."""
    result = {s: 0 for s in SEVERITIES}
    for item in issues:
        sev = item.get("severity", "review")
        result[sev] = result.get(sev, 0) + 1
    return result


def exit_code(issues: Iterable[Dict[str, Any]], fatal: bool) -> int:
    """0 clean, 1 finished with items to review, 2 fatal."""
    if fatal:
        return 2
    c = counts(issues)
    return 1 if (c["error"] or c["review"]) else 0

"""Stage 7: whole-spec validation. Findings become issues; nothing is raised.

Checks
    unknown variables / missing symbols, unresolved items
    mask lengths (lane count versus num_computers for computer lanes)
    conflicting values for the same symbol+mask inside one step
    empty cases, empty spec
    coverage: useful sections or tables that nothing used
"""
from __future__ import annotations

from typing import Any, Dict, List, Set, Tuple

from .issues import make_issue
from .render import lane_groups


def validate_spec(spec: Dict[str, Any], sections: List[Dict[str, Any]], roles: Dict[str, Dict[str, Any]],
                  recipes: Dict[str, Dict[str, Any]], cfg: Dict[str, Any]) -> List[Dict[str, str]]:
    issues: List[Dict[str, str]] = []
    cases = spec.get("test_cases", [])
    if not cases:
        issues.append(make_issue("error", "validate", "the spec contains no test cases"))
    n_unres = 0
    for case in cases:
        loc = "case %s" % case["id"]
        for s_idx, step in enumerate(case.get("steps", []), start=1):
            for bucket, mask_key in (("set_input", "input"), ("check_expected_output", "check")):
                seen: Dict[Tuple[str, str], str] = {}
                for item in step.get(bucket, []):
                    if not item.get("symbol"):
                        n_unres += 1
                        continue
                    lanes = item.get("lanes")
                    if lanes is None:
                        pairs = [(cfg["default_masks"][mask_key], str(item.get("value")))]
                    elif item.get("lane_meaning") == "computer":
                        if len(lanes) != cfg["num_computers"]:
                            issues.append(make_issue("review", "validate",
                                                     "%s: %d lanes, expected %d computers" % (item["symbol"], len(lanes), cfg["num_computers"]),
                                                     item.get("source", loc)))
                        pairs = lane_groups(lanes)
                    else:
                        continue
                    for mask, value in pairs:
                        # a symbol written twice for overlapping computers with different values
                        for (sym, other_mask), other_val in list(seen.items()):
                            if sym == item["symbol"] and other_val != value and any(
                                    a == "1" and b == "1" for a, b in zip(mask, other_mask)):
                                issues.append(make_issue(
                                    "review", "validate",
                                    "%s is given two different values (%s, %s) for overlapping computers in %s step %d"
                                    % (item["symbol"], other_val, value, bucket, s_idx), item.get("source", loc)))
                        seen[(item["symbol"], mask)] = value
    if n_unres:
        issues.append(make_issue("review", "validate", "%d item(s) have no symbol (rendered as ??UNRESOLVED??)" % n_unres))
    used_tables = {tid for tid, r in recipes.items()}
    for sec in sections:
        if sec["label"] in ("test_inputs", "expected_outputs"):
            if not sec["table_block_ids"] and sec["block_ids"]:
                issues.append(make_issue("review", "validate",
                                         "section %r (%s) has no table; its text was not turned into test steps" % (sec["heading"], sec["label"]),
                                         sec["id"], "describe the steps in a table, or add support for prose steps"))
            for tid in sec["table_block_ids"]:
                if tid not in used_tables and roles.get(tid, {}).get("role") != "ignore":
                    issues.append(make_issue("review", "validate", "table %s in %r was not used" % (tid, sec["heading"]), tid))
    return issues

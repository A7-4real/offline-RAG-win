"""All prompt text in one place.

Design rules for a small (9B, 4-bit) model
    - one narrow task per call, answer is a short JSON object
    - the first line is 'TASK: <name>' (also lets tests route fake answers)
    - labels/variables are chosen from lists given in the prompt, never invented
    - 'reason' is written before the answer so the model thinks first
    - no long rule lists; knowledge that can be written as code lives in code
Bump llm_client.PROMPT_VERSION after editing any text here.
"""
from __future__ import annotations

from typing import Dict, List, Sequence

SYSTEM_JSON = "You analyse software test description documents. Answer only with JSON."

SECTION_LABEL_HELP = {
    "index": "table of contents or list of chapters",
    "document_info": "authors, revision history, scope, introduction, glossary",
    "requirements": "requirement descriptions",
    "initialization": "system or test initialization, preconditions, boot, global setup",
    "test_inputs": "test cases or steps with input values to set",
    "expected_outputs": "expected results or outputs to verify",
    "constraints": "constraints, notes, assumptions, limitations",
    "other": "anything else",
}


def section_labels_prompt(items: Sequence[Dict[str, str]], labels: Sequence[str]) -> str:
    """items: [{"id","heading","summary","preview","hint"}]"""
    label_lines = "\n".join("- %s: %s" % (l, SECTION_LABEL_HELP.get(l, "")) for l in labels)
    sec_lines = []
    for it in items:
        sec_lines.append('[%s] heading: "%s" | %s | hint: %s\n    preview: %s'
                         % (it["id"], it["heading"], it["summary"], it["hint"] or "none", it["preview"]))
    ids = ", ".join(it["id"] for it in items)
    return (
        "TASK: section_labels\n"
        "Give every section of a test description document exactly one label.\n"
        "Labels:\n%s\n\n"
        "Decide from the heading first, then the content. The hint comes from a keyword rule and may be wrong.\n\n"
        "Sections:\n%s\n\n"
        "Answer as JSON with one entry per section (%s):\n"
        '{"labels": [{"id": "S001", "label": "index"}]}' % (label_lines, "\n".join(sec_lines), ids))


def table_role_prompt(heading: str, caption: str, section_label: str, headers: Sequence[str],
                      first_row: str, hint: str, n_rows: int) -> str:
    return (
        "TASK: table_role\n"
        "Decide what this table is for in a test description.\n"
        "- input: rows give values to SET (stimuli) for each test step\n"
        "- expected: rows give values that must be CHECKED after each test step\n"
        "- mixed: the same rows contain both inputs and expected values\n"
        "- ignore: anything else (authors, requirements, history, notes)\n\n"
        "Section heading: %s\nSection label: %s\nText just before the table: %s\n"
        "Rule-based hint: %s\nData rows: %d\nColumn headers: %s\nFirst row: %s\n\n"
        'Answer as JSON: {"reason": "<one short sentence>", "role": "<input|expected|mixed|ignore>"}'
        % (heading or "(none)", section_label, caption or "(none)", hint or "none", n_rows,
           "; ".join(headers) if headers else "(none)", first_row or "(empty)"))


def field_map_prompt(role: str, field_key: str, kind: str, lane_labels: Sequence[str],
                     samples: Sequence[str], candidates: Sequence[str], kinds: Dict[str, str]) -> str:
    cand = "\n".join("- %s" % c for c in candidates) or "- (no candidates)"
    kind_lines = "\n".join("- %s: %s" % (k, v) for k, v in kinds.items())
    lanes = (" with sub-columns %s" % ", ".join(lane_labels)) if lane_labels else ""
    return (
        "TASK: field_map\n"
        "A table column of a test description must be linked to a variable.\n"
        "Table role: %s\nColumn header path: %s%s\nExample values: %s\n\n"
        "Candidate variables:\n%s\n\nKinds:\n%s\n\n"
        "Choose one candidate variable (or NONE if the column is not a variable, e.g. a remark) and a kind.\n"
        'Answer as JSON: {"reason": "<one short sentence>", "variable": "<candidate or NONE>", "kind": "<kind>"}'
        % (role, field_key, lanes, "; ".join(samples) or "(empty)", cand, kind_lines))


NOTES_SYSTEM = "You read short parts of a test description and extract facts. Do not invent anything."


def notes_normalize_prompt(text: str, known_funcs: Sequence[str]) -> str:
    funcs = ", ".join(known_funcs) if known_funcs else "(not restricted)"
    return (
        "TASK: notes_normalize\n"
        "Rewrite the text below as short lines under these headings. Write NONE under a heading if nothing applies.\n"
        "FUNCTIONS: functions to run (known functions: %s)\n"
        "CHECKS: variable must equal a value\n"
        "VERIFY: variable to be looked at manually\n"
        "CONSTRAINTS: rules or limits for the tests\n"
        "Copy variable names and values exactly as written. Do not add anything.\n\n"
        "TEXT:\n%s" % (funcs, text))


def notes_extract_prompt(text: str, normalized: str) -> str:
    return (
        "TASK: notes_extract\n"
        "Fill the JSON from the notes. 'evidence' must be a short quote copied exactly from the ORIGINAL TEXT.\n"
        "Copy variable names exactly as written there.\n\n"
        "ORIGINAL TEXT:\n%s\n\nNOTES:\n%s\n\n"
        'Answer as JSON: {"funcs": [], "test_variables": [{"evidence": "", "variable": "", "expected_value": ""}], '
        '"verify_variables": [{"evidence": "", "variable": ""}], "constraints": [{"evidence": "", "text": ""}]}'
        % (text, normalized))

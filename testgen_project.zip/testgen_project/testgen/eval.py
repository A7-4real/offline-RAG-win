"""Compare a generated tpf with a gold tpf (line level, order-insensitive).

Comments (#...) and blank lines are ignored, whitespace is normalised. Gives
precision / recall / F1 plus the missing and extra lines, so you can see what to
fix in recipes or config.
"""
from __future__ import annotations

import re
from collections import Counter
from typing import Any, Dict, List


def _norm_lines(text: str) -> List[str]:
    out = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        out.append(re.sub(r"\s+", " ", line))
    return out


def compare(generated: str, gold: str) -> Dict[str, Any]:
    g, t = Counter(_norm_lines(generated)), Counter(_norm_lines(gold))
    matched = sum((g & t).values())
    n_gen, n_gold = sum(g.values()), sum(t.values())
    precision = matched / n_gen if n_gen else 0.0
    recall = matched / n_gold if n_gold else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
    return {"generated_lines": n_gen, "gold_lines": n_gold, "matched": matched,
            "precision": round(precision, 4), "recall": round(recall, 4), "f1": round(f1, 4),
            "missing": sorted((t - g).elements()), "extra": sorted((g - t).elements())}

"""Configuration loading and validation.

`load_config(path)` merges a user JSON file over DEFAULT_CONFIG and validates
it. A broken config is a FatalError with a message that says what to fix.
Unknown top-level keys are reported as review issues (they are usually typos).
"""
from __future__ import annotations

import copy
import json
import os
import string
from typing import Any, Dict, List, Optional, Tuple

from .issues import FatalError, make_issue

SECTION_LABELS = ["index", "document_info", "requirements", "initialization",
                  "test_inputs", "expected_outputs", "constraints", "other"]

# Output syntax templates. Placeholders allowed per template are listed in
# FORMAT_FIELDS; anything else is rejected at load time so a typo in the config
# cannot crash rendering halfway through a run.
DEFAULT_FORMATS = {
    "section_init": "# init system and verify",
    "init_func": "func <-> {name}",
    "init_check": "{sym} <-> {value} /",
    "init_verify": "{sym} = /",
    "case_header": "# test case {n}",
    "step_header": "# step {n}",
    "section_env": "# setup test case environment",
    "env_func": "func <-> {name}",
    "env_computers": "pcomp <-> {mask}",
    "section_env_verify": "# test and verify test case environment",
    "env_check": "{sym} <-> {value} /",
    "env_verify": "{sym} = /",
    "section_inputs": "# setting inputs",
    "set_input": "{sym}[{mask}] <-> {value}",
    "section_checks": "# checking expected output",
    "check": "{sym}[{mask}] <-> {value}/",
    "verify": "{sym} = /",
    "todo": "# TODO {text}",
    "unresolved": "??UNRESOLVED: {text}??",
}
FORMAT_FIELDS = {
    "section_init": set(), "init_func": {"name"}, "init_check": {"sym", "value"},
    "init_verify": {"sym"}, "case_header": {"n", "id"}, "step_header": {"n"},
    "section_env": set(), "env_func": {"name"}, "env_computers": {"mask"},
    "section_env_verify": set(), "env_check": {"sym", "value"}, "env_verify": {"sym"},
    "section_inputs": set(), "set_input": {"sym", "mask", "value"},
    "section_checks": set(), "check": {"sym", "mask", "value"}, "verify": {"sym"},
    "todo": {"text"}, "unresolved": {"text"},
}

DEFAULT_KEYWORDS = {
    "index": ["index", "table of contents", "contents", "toc"],
    "document_info": ["author", "document information", "document info", "revision",
                      "history", "version", "scope", "introduction", "purpose",
                      "references", "glossary", "abbreviation", "approval"],
    "requirements": ["requirement", "specification", "traceab"],
    "initialization": ["initiali", "precondition", "pre condition", "prerequisite",
                       "setup", "set up", "boot"],
    "test_inputs": ["test input", "input", "stimul", "test case", "test step",
                    "test procedure", "test sequence", "test scenario"],
    "expected_outputs": ["expected", "output", "result", "verification", "acceptance",
                         "pass criteria"],
    "constraints": ["constraint", "assumption", "limitation", "note", "remark",
                    "restriction", "caution", "warning"],
}

DEFAULT_CONFIG: Dict[str, Any] = {
    "funcs": [],                       # known function names; empty = not enforced
    "num_computers": 4,                # lanes of an expected-output field = computers
    "default_masks": {"input": "111", "check": "1111"},
    "lane_meaning": {"check": "computer", "set_input": "channel"},
    "input_lane_render": "todo",       # "todo" or "mask" (treat channel lanes like computers)
    "dont_care_values": ["", "-", "--", "x", "X", "n/a", "N/A", "na", "NA", "\u2014", "\u2013"],
    "env_expectations": {},            # {"in_water": {"vehicle_mode": "2"}}
    "case_environment_default": None,  # {"func": ["in_water"], "target_computer": [1,1,1,1]}
    "table_options": {"header_rows": None, "transpose": False, "id_column": None,
                      "text_format": "plain", "per_table": {}},
    "table_column_map": {},            # header text -> variable, or {"variable","kind","lane_meaning"}
    "ignore_header_patterns": ["^remarks?$", "^comments?$", "^notes?$", "^description$",
                               "^requirement(s)?( id)?$", "^reference(s)?$", "^status$",
                               "^tester$", "^date$", "^pass\\s*/\\s*fail$"],
    "keyword_rules": DEFAULT_KEYWORDS,
    "sections": {"batch_size": 12, "overlap": 2, "preview_chars": 300,
                 "max_prompt_chars": 6000},
    "grounding": {"accept": 0.92, "margin": 0.05, "floor": 0.55, "top_n": 5},
    "llm": {"backend": "ollama", "model": "gemma2:9b", "base_url": None,
            "temperature": 0.0, "max_tokens": 1024, "timeout": 120.0, "retries": 2,
            "backoff": 1.0, "num_ctx": None, "fold_system": True, "cache": True,
            "log_full": True},
    "formats": DEFAULT_FORMATS,
    "emit_global_init": False,
    "recipe_dir": "recipes",
    "engine": "auto",                  # auto | langgraph | sequential
    "strict": False,
}

_TYPES = {
    "funcs": list, "num_computers": int, "default_masks": dict, "lane_meaning": dict,
    "input_lane_render": str, "dont_care_values": list, "env_expectations": dict,
    "table_options": dict, "table_column_map": dict, "ignore_header_patterns": list,
    "keyword_rules": dict, "sections": dict, "grounding": dict, "llm": dict,
    "formats": dict, "emit_global_init": bool, "recipe_dir": str, "engine": str,
    "strict": bool,
}


def _merge(base: Any, override: Any) -> Any:
    """Recursive dict merge; lists and scalars from `override` replace `base`."""
    if isinstance(base, dict) and isinstance(override, dict):
        out = copy.deepcopy(base)
        for key, value in override.items():
            out[key] = _merge(base[key], value) if key in base else copy.deepcopy(value)
        return out
    return copy.deepcopy(override)


def validate_config(cfg: Dict[str, Any]) -> List[Dict[str, str]]:
    """Check types and templates. Raise FatalError for anything unusable."""
    issues: List[Dict[str, str]] = []
    for key in cfg:
        if key not in DEFAULT_CONFIG:
            issues.append(make_issue("review", "config", "unknown config key %r (typo?)" % key,
                                     fix="check the spelling against config.example.json"))
    for key, typ in _TYPES.items():
        if key in cfg and not isinstance(cfg[key], typ) or (typ is int and isinstance(cfg.get(key), bool)):
            raise FatalError("config: %r must be of type %s" % (key, typ.__name__))
    if cfg["num_computers"] < 1 or cfg["num_computers"] > 16:
        raise FatalError("config: num_computers must be between 1 and 16")
    if cfg["input_lane_render"] not in ("todo", "mask"):
        raise FatalError("config: input_lane_render must be 'todo' or 'mask'")
    if cfg["engine"] not in ("auto", "langgraph", "sequential"):
        raise FatalError("config: engine must be auto, langgraph or sequential")
    for name, mask in cfg["default_masks"].items():
        if name not in ("input", "check") or not isinstance(mask, str) or set(mask) - set("01") or not mask:
            raise FatalError("config: default_masks.%s must be a string of 0/1 digits" % name)
    for name, value in cfg["lane_meaning"].items():
        if value not in ("computer", "channel", "bit", "none"):
            raise FatalError("config: lane_meaning.%s must be computer, channel, bit or none" % name)
    fmt = cfg["formats"]
    for name, template in fmt.items():
        if name not in FORMAT_FIELDS:
            issues.append(make_issue("review", "config", "unknown format key %r" % name))
            continue
        if not isinstance(template, str):
            raise FatalError("config: formats.%s must be a string" % name)
        try:
            used = {f for _, f, _, _ in string.Formatter().parse(template) if f}
        except ValueError as exc:
            raise FatalError("config: formats.%s is not a valid template: %s" % (name, exc))
        bad = used - FORMAT_FIELDS[name]
        if bad:
            raise FatalError("config: formats.%s uses unknown placeholder(s) %s; allowed: %s" % (
                name, sorted(bad), sorted(FORMAT_FIELDS[name])))
    for name in FORMAT_FIELDS:
        if name not in fmt:
            fmt[name] = DEFAULT_FORMATS[name]
    return issues


def load_config(path: Optional[str] = None,
                overrides: Optional[Dict[str, Any]] = None) -> Tuple[Dict[str, Any], List[Dict[str, str]]]:
    """Load defaults, merge the user file and CLI overrides, validate."""
    cfg = copy.deepcopy(DEFAULT_CONFIG)
    if path:
        if not os.path.isfile(path):
            raise FatalError("config file not found: %s" % path)
        try:
            with open(path, "r", encoding="utf-8-sig") as handle:
                user = json.load(handle)
        except ValueError as exc:
            raise FatalError("config file %s is not valid JSON: %s" % (path, exc))
        if not isinstance(user, dict):
            raise FatalError("config file %s must contain a JSON object" % path)
        cfg = _merge(cfg, user)
    if overrides:
        cfg = _merge(cfg, overrides)
    issues = validate_config(cfg)
    return cfg, issues

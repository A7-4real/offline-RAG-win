"""Stage 4: build interleaved test cases from the decoded tables and recipes.

Input and expected-output tables stay separate in the Word file; here they are
joined into one record per test case so every later stage (render, validate,
review) works on one case at a time.

Join rule
    * tables with a usable id column (unique ids) are joined by id
    * otherwise by row position
    * row-count / id mismatches are reported; unmatched rows are never dropped
    * several tables with the same role and layout are concatenated; tables with
      different layouts of the same role are joined to the same cases by position

Case shape
    {"id": "1", "ordinal": 1,
     "setup_test_case_environment": {"func": [], "target_computer": []},
     "verify_test_case_environment": [<variable text>],
     "steps": [{"source": {"input_rows": [...], "expected_rows": [...]},
                "set_input": [item], "check_expected_output": [item], "verify_only": [item]}]}
    item = {"variable": str|None, "label": column key, "value": str|None,
            "lanes": [str|None]|None, "lane_labels": [...], "lane_meaning": ..., "source": "T3 row 2 / ..."}
Environment columns (kinds env_func / env_computers / env_verify) exist only when
configured through table_column_map; otherwise the environment stays empty and
ONE review issue is raised (or case_environment_default from the config is used).
"""
from __future__ import annotations

import copy
import re
from typing import Any, Dict, List, Optional, Tuple

from .issues import make_issue


def _idkey(text: str) -> str:
    t = str(text).strip().lower()
    return str(int(t)) if t.isdigit() else t


def _make_item(entry: Dict[str, Any], fld: Dict[str, Any], vals: List[Optional[str]], source: str
               ) -> Optional[Dict[str, Any]]:
    if fld["kind"] == "lanes":
        if all(v is None for v in vals):
            return None
        return {"variable": entry.get("variable"), "label": fld["key"], "value": None,
                "lanes": list(vals), "lane_labels": list(fld["lane_labels"]),
                "lane_meaning": entry.get("lane_meaning", "none"), "source": source}
    if vals[0] is None:
        return None
    return {"variable": entry.get("variable"), "label": fld["key"], "value": vals[0], "lanes": None,
            "lane_labels": [], "lane_meaning": "none", "source": source}


def _group_parts(blocks: List[Dict[str, Any]], roles: Dict[str, Dict[str, Any]],
                 recipes: Dict[str, Dict[str, Any]], issues: List[Dict[str, str]]) -> List[Dict[str, Any]]:
    parts: List[Dict[str, Any]] = []
    for b in blocks:
        if b["kind"] != "table" or b["table"] is None:
            continue
        role = roles.get(b["id"], {}).get("role", "ignore")
        recipe = recipes.get(b["id"])
        if role == "ignore" or recipe is None:
            continue
        layout = b["table"]["layout_hash"]
        tlabel = "T%d" % (b["table_index"] + 1)
        part = next((p for p in parts if p["role"] == role and p["layout"] == layout), None)
        if part is None:
            part = {"role": role, "layout": layout, "table": b["table"], "recipe": recipe, "rows": [],
                    "tables": []}
            parts.append(part)
        else:
            issues.append(make_issue("review", "assemble",
                                     "%s has the same layout as an earlier %s table; rows are appended as further test cases"
                                     % (tlabel, role), tlabel))
        part["tables"].append(tlabel)
        for row in b["table"]["rows"]:
            part["rows"].append({"row": row, "tlabel": tlabel})
    for role in ("input", "expected", "mixed"):
        n = len([p for p in parts if p["role"] == role])
        if n > 1:
            issues.append(make_issue("review", "assemble",
                                     "%d %s tables with different layouts are joined to the same cases by row position" % (n, role)))
    return parts


def _split_funcs(text: str) -> List[str]:
    """'in_water, boot' -> ['in_water', 'boot']"""
    return [t.strip() for t in re.split(r"[,;\n/]+", text) if t.strip()]


def assemble_cases(blocks: List[Dict[str, Any]], roles: Dict[str, Dict[str, Any]],
                   recipes: Dict[str, Dict[str, Any]], cfg: Dict[str, Any]
                   ) -> Tuple[List[Dict[str, Any]], List[Dict[str, str]]]:
    issues: List[Dict[str, str]] = []
    parts = _group_parts(blocks, roles, recipes, issues)
    if not parts:
        return [], issues

    # --- decide the order and keys of the cases -------------------------------
    id_part_maps: List[Tuple[Dict[str, Dict[str, Any]], Dict[str, str]]] = []
    for p in parts:
        ids = [_idkey(r["row"]["row_id"]) for r in p["rows"]]
        usable = p["table"]["id_column"] and len(set(ids)) == len(ids) and all(ids)
        p["by_id"] = {k: r for k, r in zip(ids, p["rows"])} if usable else None
        p["ids"] = ids if usable else None
    order: List[str] = []
    display: Dict[str, str] = {}
    id_parts = [p for p in parts if p["by_id"] is not None]
    for p in id_parts:
        for k, r in zip(p["ids"], p["rows"]):
            if k not in display:
                order.append(k)
                display[k] = r["row"]["row_id"]
    if len(id_parts) > 1:
        sets = [set(p["ids"]) for p in id_parts]
        if any(s != sets[0] for s in sets[1:]):
            only = sorted(set().union(*sets) - set.intersection(*sets))
            issues.append(make_issue("review", "assemble",
                                     "test ids differ between tables (not in all tables: %s)" % ", ".join(only[:10]),
                                     fix="check the id columns of the input and expected-output tables"))
    positional = [p for p in parts if p["by_id"] is None]
    n_pos = max([len(p["rows"]) for p in positional] or [0])
    if not id_parts:
        order = ["#%d" % (i + 1) for i in range(n_pos)]
        display = {k: str(i + 1) for i, k in enumerate(order)}
    else:
        for i in range(len(order), n_pos):                   # positional part longer than the id order
            key = "#%d" % (i + 1)
            order.append(key)
            display[key] = str(i + 1)
    counts = {"%s %s" % (p["role"], "+".join(p["tables"])): len(p["rows"]) for p in parts}
    if len(set(len(p["rows"]) for p in parts)) > 1:
        issues.append(make_issue("review", "assemble",
                                 "row counts differ between tables (%s); unmatched rows are kept in their own cases"
                                 % ", ".join("%s: %d" % kv for kv in counts.items()),
                                 fix="check that every test case has an input row and an expected-output row"))

    # --- build the cases -----------------------------------------------------------
    env_default = cfg.get("case_environment_default")
    env_seen = False
    cases: List[Dict[str, Any]] = []
    for n, key in enumerate(order, start=1):
        env = copy.deepcopy(env_default) if isinstance(env_default, dict) else {}
        case = {"id": display[key], "ordinal": n,
                "setup_test_case_environment": {"func": list(env.get("func", [])),
                                                "target_computer": list(env.get("target_computer", []))},
                "verify_test_case_environment": list(env.get("verify", [])),
                "steps": []}
        step = {"source": {"input_rows": [], "expected_rows": []},
                "set_input": [], "check_expected_output": [], "verify_only": []}
        for p in parts:
            if p["by_id"] is not None:
                ref = p["by_id"].get(key)
            else:
                idx = int(key[1:]) - 1 if key.startswith("#") else n - 1
                ref = p["rows"][idx] if idx < len(p["rows"]) else None
            if ref is None:
                continue
            row, tlabel = ref["row"], ref["tlabel"]
            bucket = "input_rows" if p["role"] == "input" else "expected_rows"
            step["source"][bucket].append("%s row %s" % (tlabel, row["row_id"]))
            for fld in p["table"]["fields"]:
                entry = p["recipe"]["fields"].get(fld["key"])
                if not entry or entry["kind"] == "ignore":
                    continue
                vals = row["values"][fld["key"]]
                src = "%s row %s / %s" % (tlabel, row["row_id"], fld["key"])
                kind = entry["kind"]
                if kind in ("set_input", "check", "verify_only"):
                    item = _make_item(entry, fld, vals, src)
                    if item is None:
                        continue
                    if kind == "set_input":
                        step["set_input"].append(item)
                    elif kind == "check":
                        step["check_expected_output"].append(item)
                    else:
                        step["verify_only"].append(item)
                elif kind in ("env_func", "env_computers", "env_verify"):
                    env_seen = True
                    text = ",".join(v for v in vals if v)
                    if not text:
                        continue
                    setup = case["setup_test_case_environment"]
                    if kind == "env_func":
                        for name in _split_funcs(text):
                            known = cfg.get("funcs") or []
                            if known and name not in known:
                                issues.append(make_issue("review", "assemble", "func %r is not in the configured function list" % name, src))
                            if name not in setup["func"]:
                                setup["func"].append(name)
                    elif kind == "env_computers":
                        bits = [v for v in vals if v is not None] if fld["kind"] == "lanes" else list(text)
                        if bits and all(str(b) in ("0", "1") for b in bits):
                            setup["target_computer"] = [int(b) for b in bits]
                        else:
                            issues.append(make_issue("review", "assemble", "computer selection %r is not a list of 0/1" % text, src))
                    else:
                        for name in _split_funcs(text):
                            if name not in case["verify_test_case_environment"]:
                                case["verify_test_case_environment"].append(name)
        case["steps"].append(step)
        if not step["set_input"] and not step["check_expected_output"] and not step["verify_only"]:
            issues.append(make_issue("review", "assemble", "test case %s has no inputs and no expected outputs" % case["id"], "case %s" % case["id"]))
        cases.append(case)
    if cases and not env_seen and not isinstance(env_default, dict):
        issues.append(make_issue("review", "assemble",
                                 "no column describes the test-case environment (func and computers); it was left empty for all %d cases" % len(cases),
                                 fix="map a column with kind env_func / env_computers in table_column_map, or set case_environment_default in config.json"))
    return cases, issues

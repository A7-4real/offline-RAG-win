# NOTE: no "from __future__ import annotations" here on purpose. LangGraph reads the
# Annotated[...] reducers from the real type hints of RunState at graph-build time.
import operator
from typing import Any, Dict, List, Optional, TypedDict

try:                                    # Python 3.9+
    from typing import Annotated
except ImportError:                     # Python 3.8
    from typing_extensions import Annotated  # type: ignore


class RunState(TypedDict, total=False):
    """Shared state of the graph. Everything in it is JSON-serialisable.

    Written by stage        keys
        (start)             input_path
        load                blocks
        sections            sections
        roles               roles
        recipes             recipes
        assemble            cases
        notes               notes
        ground              spec
        validate            validation
        render              outputs
        every stage         issues, stage_log (lists that are APPENDED, see reducers)
        any stage           fatal (a message; stops the run)
    """
    input_path: str
    blocks: List[Dict[str, Any]]
    sections: List[Dict[str, Any]]
    roles: Dict[str, Dict[str, Any]]
    recipes: Dict[str, Dict[str, Any]]
    cases: List[Dict[str, Any]]
    notes: Dict[str, Any]
    spec: Dict[str, Any]
    validation: List[Dict[str, Any]]
    outputs: Dict[str, Any]
    fatal: Optional[str]
    issues: Annotated[List[Dict[str, Any]], operator.add]
    stage_log: Annotated[List[Dict[str, Any]], operator.add]


# Same reducers for the built-in sequential engine, so both engines behave alike.
REDUCERS = {"issues": operator.add, "stage_log": operator.add}

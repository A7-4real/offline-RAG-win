"""JSON schemas for every LLM answer, plus a tiny validator.

Why a home-made validator: the schemas below are also what we hand to the
backend for constrained decoding (Ollama `format`, LM Studio `response_format`).
The backend only guarantees the *shape* when it supports grammars; this
validator re-checks the shape in code (so an unconstrained backend or an old
library version cannot silently let bad JSON through) and has no dependency.

Supported keywords: type, enum, required, properties, additionalProperties,
items, minItems, maxItems.
"""
from __future__ import annotations

from typing import Any, Dict, List, Sequence


def validate(instance: Any, schema: Dict[str, Any], path: str = "$") -> List[str]:
    """Return a list of human-readable problems (empty list = valid)."""
    errors: List[str] = []
    allowed = schema.get("enum")
    if allowed is not None:
        try:
            ok = instance in allowed
        except TypeError:
            ok = False
        if not ok:
            shown = ", ".join(repr(a) for a in list(allowed)[:12])
            more = "" if len(allowed) <= 12 else ", ..."
            errors.append("%s: %r is not one of [%s%s]" % (path, instance, shown, more))
            return errors
    kind = schema.get("type")
    if kind == "object":
        if not isinstance(instance, dict):
            return ["%s: expected an object, got %s" % (path, type(instance).__name__)]
        for key in schema.get("required", []):
            if key not in instance:
                errors.append("%s: missing required key %r" % (path, key))
        props = schema.get("properties", {})
        for key, value in instance.items():
            if key in props:
                errors.extend(validate(value, props[key], "%s.%s" % (path, key)))
            elif schema.get("additionalProperties") is False:
                errors.append("%s: unexpected key %r" % (path, key))
    elif kind == "array":
        if not isinstance(instance, list):
            return ["%s: expected an array, got %s" % (path, type(instance).__name__)]
        if "minItems" in schema and len(instance) < schema["minItems"]:
            errors.append("%s: needs at least %d items, got %d" % (path, schema["minItems"], len(instance)))
        if "maxItems" in schema and len(instance) > schema["maxItems"]:
            errors.append("%s: allows at most %d items, got %d" % (path, schema["maxItems"], len(instance)))
        item_schema = schema.get("items")
        if item_schema:
            for idx, item in enumerate(instance):
                errors.extend(validate(item, item_schema, "%s[%d]" % (path, idx)))
    elif kind == "string":
        if not isinstance(instance, str):
            errors.append("%s: expected a string, got %s" % (path, type(instance).__name__))
    elif kind == "integer":
        if isinstance(instance, bool) or not isinstance(instance, int):
            errors.append("%s: expected an integer" % path)
    elif kind == "number":
        if isinstance(instance, bool) or not isinstance(instance, (int, float)):
            errors.append("%s: expected a number" % path)
    elif kind == "boolean":
        if not isinstance(instance, bool):
            errors.append("%s: expected true or false" % path)
    return errors


def _obj(props: Dict[str, Any], required: Sequence[str] = ()) -> Dict[str, Any]:
    return {"type": "object", "properties": props,
            "required": list(required) if required else list(props.keys()),
            "additionalProperties": False}


def _enum(values: Sequence[str]) -> Dict[str, Any]:
    return {"type": "string", "enum": list(values)}


# ---------------------------------------------------------------------------
# One builder per LLM task. Every key is required, so the model cannot skip one.
# "reason" comes first on purpose: the model writes a short justification before
# it commits to the answer, which helps small models.
# ---------------------------------------------------------------------------
def section_labels_schema(ids: Sequence[str], labels: Sequence[str]) -> Dict[str, Any]:
    item = _obj({"id": _enum(ids), "label": _enum(labels)})
    return _obj({"labels": {"type": "array", "items": item,
                            "minItems": len(ids), "maxItems": len(ids)}})


def table_role_schema(roles: Sequence[str]) -> Dict[str, Any]:
    return _obj({"reason": {"type": "string"}, "role": _enum(roles)})


def field_map_schema(candidates: Sequence[str], kinds: Sequence[str]) -> Dict[str, Any]:
    return _obj({"reason": {"type": "string"},
                 "variable": _enum(list(candidates) + ["NONE"]),
                 "kind": _enum(kinds)})


def choose_variable_schema(candidates: Sequence[str]) -> Dict[str, Any]:
    return _obj({"variable": _enum(list(candidates) + ["NONE"])})


def notes_schema(funcs: Sequence[str] = ()) -> Dict[str, Any]:
    func_item: Dict[str, Any] = _enum(funcs) if funcs else {"type": "string"}
    test_var = _obj({"evidence": {"type": "string"}, "variable": {"type": "string"},
                     "expected_value": {"type": "string"}})
    verify_var = _obj({"evidence": {"type": "string"}, "variable": {"type": "string"}})
    constraint = _obj({"evidence": {"type": "string"}, "text": {"type": "string"}})
    return _obj({
        "funcs": {"type": "array", "items": func_item},
        "test_variables": {"type": "array", "items": test_var},
        "verify_variables": {"type": "array", "items": verify_var},
        "constraints": {"type": "array", "items": constraint},
    })

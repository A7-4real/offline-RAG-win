"""Robust LLM access.

Layers
    Transport      one call: messages (+ optional JSON schema) -> Reply.
                   LangChainTransport talks to Ollama or LM Studio through
                   LangChain; ScriptedTransport (testing.py) is a fake.
    LLMClient      everything that makes a small local model dependable:
                   timeout, retry with backoff, truncation detection, code-fence
                   stripping, JSON extraction, schema validation, semantic
                   checks with error feedback, an on-disk cache and a call log.

Every failure ends as an LLMError subclass. Stages catch LLMError and fall back
to rules, so a bad model answer never crashes a run.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import threading
import time
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from .schema import validate as validate_schema

PROMPT_VERSION = "1"   # bump when prompts change so the cache is not reused


class LLMError(Exception):
    """Base class for every model-related failure."""


class LLMDisabled(LLMError):
    """Rules-only mode: no model is configured."""


class LLMTimeout(LLMError):
    """The model did not answer in time."""


class LLMTransportError(LLMError):
    """Connection problem, missing library, server error."""


class LLMOutputError(LLMError):
    """The model answered, but not with valid, acceptable JSON after all retries."""


class Reply:
    """One model answer. `truncated` is True when generation hit max_tokens."""
    __slots__ = ("text", "truncated")

    def __init__(self, text: str, truncated: bool = False) -> None:
        self.text = text
        self.truncated = truncated


Messages = List[Tuple[str, str]]          # [("system", text), ("human", text)]
Transport = Callable[[Messages, Optional[Dict[str, Any]]], Reply]


# ---------------------------------------------------------------------------
# helpers that clean up what small models return
# ---------------------------------------------------------------------------
_FENCE_RE = re.compile(r"^```[a-zA-Z0-9_-]*\s*\n?(.*?)\n?```\s*$", re.S)


def strip_fences(text: str) -> str:
    """Remove a surrounding ```json ... ``` fence if present."""
    stripped = text.strip()
    match = _FENCE_RE.match(stripped)
    return match.group(1).strip() if match else stripped


def extract_json(text: str) -> Any:
    """Parse JSON from model output, tolerating fences and chatter around it."""
    if len(text) > 400000:
        raise ValueError("model output is unreasonably long")
    cleaned = strip_fences(text)
    try:
        return json.loads(cleaned)
    except ValueError:
        pass
    decoder = json.JSONDecoder()
    for match in re.finditer(r"[\{\[]", cleaned):
        try:
            obj, _ = decoder.raw_decode(cleaned[match.start():])
            return obj
        except ValueError:
            continue
    raise ValueError("no JSON found in the model output")


def call_with_timeout(fn: Callable[[], Any], timeout: Optional[float]) -> Any:
    """Run fn in a daemon thread and give up after `timeout` seconds."""
    if not timeout or timeout <= 0:
        return fn()
    box: Dict[str, Any] = {}

    def runner() -> None:
        try:
            box["value"] = fn()
        except BaseException as exc:    # noqa: BLE001 - re-raised below
            box["error"] = exc

    thread = threading.Thread(target=runner, daemon=True)
    thread.start()
    thread.join(timeout)
    if thread.is_alive():
        raise LLMTimeout("no answer within %.0f s" % timeout)
    if "error" in box:
        raise box["error"]
    return box["value"]


def fold_system(messages: Messages) -> Messages:
    """Gemma has no system role: merge the system text into the first human turn."""
    system = [text for role, text in messages if role == "system"]
    rest = [(role, text) for role, text in messages if role != "system"]
    if not system:
        return rest
    if rest and rest[0][0] == "human":
        rest[0] = ("human", "\n".join(system) + "\n\n" + rest[0][1])
    else:
        rest.insert(0, ("human", "\n".join(system)))
    return rest


# ---------------------------------------------------------------------------
# LangChain transport (Ollama and LM Studio)
# ---------------------------------------------------------------------------
def _content_text(message: Any) -> str:
    content = getattr(message, "content", message)
    if isinstance(content, list):
        parts = []
        for part in content:
            if isinstance(part, dict):
                parts.append(str(part.get("text", "")))
            else:
                parts.append(str(part))
        return "".join(parts)
    return "" if content is None else str(content)


def _is_truncated(message: Any) -> bool:
    meta = getattr(message, "response_metadata", None) or {}
    reason = meta.get("done_reason") or meta.get("finish_reason")
    return reason == "length"


def _looks_like_schema_error(exc: BaseException) -> bool:
    text = str(exc).lower()
    return any(word in text for word in
               ("response_format", "json_schema", "grammar", "format", "schema", "unsupported"))


class LangChainTransport:
    """Chat model through LangChain.

    backend "ollama"   -> langchain_ollama.ChatOllama, schema passed as `format`
    backend "lmstudio" -> langchain_openai.ChatOpenAI pointed at LM Studio's
                          OpenAI-compatible server, schema passed as
                          response_format=json_schema
    If the server or library version rejects the schema the transport remembers
    that and continues without it (the client still validates every answer).
    Models are imported lazily so the rest of the package works without them.
    """

    def __init__(self, backend: str, model: str, base_url: Optional[str] = None,
                 temperature: float = 0.0, max_tokens: int = 1024, timeout: float = 120.0,
                 num_ctx: Optional[int] = None, fold: bool = True,
                 api_key: str = "lm-studio") -> None:
        self.backend = backend
        self.model = model
        self.base_url = base_url
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.timeout = timeout
        self.num_ctx = num_ctx
        self.fold = fold
        self.api_key = api_key
        self._models: Dict[str, Any] = {}
        self._schema_ok = True

    # -- model construction -------------------------------------------------
    def _build_ollama(self, schema: Optional[Dict[str, Any]]) -> Any:
        try:
            from langchain_ollama import ChatOllama
        except ImportError as exc:
            raise LLMTransportError("langchain-ollama is not installed (pip install langchain-ollama)") from exc
        kwargs: Dict[str, Any] = {"model": self.model, "temperature": self.temperature,
                                  "num_predict": self.max_tokens}
        if self.base_url:
            kwargs["base_url"] = self.base_url
        if self.num_ctx:
            kwargs["num_ctx"] = self.num_ctx
        if schema is not None:
            for fmt in (schema, "json"):          # full schema first, plain JSON mode second
                try:
                    return ChatOllama(format=fmt, **kwargs)
                except Exception:                  # old library version: try the next option
                    continue
        return ChatOllama(**kwargs)

    def _build_openai(self, schema: Optional[Dict[str, Any]]) -> Any:
        try:
            from langchain_openai import ChatOpenAI
        except ImportError as exc:
            raise LLMTransportError("langchain-openai is not installed (pip install langchain-openai)") from exc
        model = ChatOpenAI(model=self.model, base_url=self.base_url or "http://localhost:1234/v1",
                           api_key=self.api_key, temperature=self.temperature,
                           max_tokens=self.max_tokens, timeout=self.timeout, max_retries=0)
        if schema is not None:
            model = model.bind(response_format={
                "type": "json_schema",
                "json_schema": {"name": "answer", "strict": True, "schema": schema}})
        return model

    def _get_model(self, schema: Optional[Dict[str, Any]]) -> Any:
        use_schema = schema if (schema is not None and self._schema_ok) else None
        key = json.dumps(use_schema, sort_keys=True) if use_schema is not None else ""
        if key not in self._models:
            if self.backend == "ollama":
                self._models[key] = self._build_ollama(use_schema)
            elif self.backend in ("lmstudio", "openai"):
                self._models[key] = self._build_openai(use_schema)
            else:
                raise LLMTransportError("unknown backend %r (use ollama or lmstudio)" % self.backend)
        return self._models[key]

    # -- the call -------------------------------------------------------------
    def __call__(self, messages: Messages, schema: Optional[Dict[str, Any]] = None) -> Reply:
        msgs = fold_system(messages) if self.fold else messages
        model = self._get_model(schema)
        try:
            answer = model.invoke(msgs)
        except LLMError:
            raise
        except Exception as exc:                    # noqa: BLE001
            if schema is not None and self._schema_ok and _looks_like_schema_error(exc):
                self._schema_ok = False             # server cannot do constrained output
                try:
                    answer = self._get_model(None).invoke(msgs)
                except Exception as exc2:           # noqa: BLE001
                    raise LLMTransportError("%s: %s" % (type(exc2).__name__, exc2)) from exc2
            else:
                raise LLMTransportError("%s: %s" % (type(exc).__name__, exc)) from exc
        return Reply(_content_text(answer), _is_truncated(answer))


# ---------------------------------------------------------------------------
# the client used by every stage
# ---------------------------------------------------------------------------
class LLMClient:
    def __init__(self, transport: Optional[Transport], model_id: str = "none",
                 retries: int = 2, backoff: float = 1.0, timeout: Optional[float] = 120.0,
                 cache_dir: Optional[str] = None, log_path: Optional[str] = None,
                 log_full: bool = True, sleep: Callable[[float], None] = time.sleep,
                 prompt_version: str = PROMPT_VERSION) -> None:
        self.transport = transport
        self.model_id = model_id
        self.retries = max(0, int(retries))
        self.backoff = backoff
        self.timeout = timeout
        self.cache_dir = cache_dir
        self.log_path = log_path
        self.log_full = log_full
        self.sleep = sleep
        self.prompt_version = prompt_version
        self.stats = {"calls": 0, "attempts": 0, "cache_hits": 0, "retries": 0,
                      "failures": 0, "truncated": 0, "timeouts": 0, "seconds": 0.0}

    @property
    def enabled(self) -> bool:
        return self.transport is not None

    # -- public API -----------------------------------------------------------
    def ask_json(self, task: str, system: str, user: str, schema: Dict[str, Any],
                 check: Optional[Callable[[Any], List[str]]] = None,
                 retries: Optional[int] = None) -> Any:
        """Ask for JSON that matches `schema` (and passes the optional `check`)."""
        if not self.enabled:
            raise LLMDisabled("no LLM configured (rules-only mode)")
        key = self._key(task, system, user, schema)
        cached = self._cache_get(key)
        if cached is not None:
            self.stats["cache_hits"] += 1
            return cached
        self.stats["calls"] += 1
        attempts = (self.retries if retries is None else max(0, retries)) + 1
        last_error = "unknown error"
        last_exc: Optional[LLMError] = None
        for attempt in range(attempts):
            prompt = user
            if attempt and isinstance(last_exc, LLMOutputError):
                prompt = (user + "\n\nYour previous answer was rejected: " + last_error +
                          "\nReturn ONLY valid JSON that follows the schema.")
            started = time.time()
            self.stats["attempts"] += 1
            problem = ""
            try:
                reply = self._invoke([("system", system), ("human", prompt)], schema)
                if reply.truncated:
                    self.stats["truncated"] += 1
                    raise LLMOutputError("the answer was cut off at the token limit")
                try:
                    parsed = extract_json(reply.text)
                except ValueError as exc:
                    raise LLMOutputError(str(exc))
                errors = validate_schema(parsed, schema)
                if not errors and check is not None:
                    errors = list(check(parsed))
                if errors:
                    raise LLMOutputError("; ".join(errors[:5]))
                self._log(task, attempt, started, prompt, reply.text, "")
                self._cache_put(key, parsed)
                self.stats["seconds"] += time.time() - started
                return parsed
            except LLMError as exc:
                last_exc = exc
                last_error = str(exc)
                problem = "%s: %s" % (type(exc).__name__, exc)
                self._log(task, attempt, started, prompt, "", problem)
                self.stats["seconds"] += time.time() - started
                if attempt + 1 < attempts:
                    self.stats["retries"] += 1
                    if not isinstance(exc, LLMOutputError):
                        self.sleep(self.backoff * (2 ** attempt))
        self.stats["failures"] += 1
        raise last_exc if last_exc is not None else LLMOutputError(last_error)

    def ask_text(self, task: str, system: str, user: str, retries: Optional[int] = None) -> str:
        """Ask for free text. Retries on transport problems and empty answers."""
        if not self.enabled:
            raise LLMDisabled("no LLM configured (rules-only mode)")
        key = self._key(task, system, user, None)
        cached = self._cache_get(key)
        if isinstance(cached, str):
            self.stats["cache_hits"] += 1
            return cached
        self.stats["calls"] += 1
        attempts = (self.retries if retries is None else max(0, retries)) + 1
        last_exc: Optional[LLMError] = None
        for attempt in range(attempts):
            started = time.time()
            self.stats["attempts"] += 1
            try:
                reply = self._invoke([("system", system), ("human", user)], None)
                text = reply.text.strip()
                if not text:
                    raise LLMOutputError("empty answer")
                if reply.truncated:
                    self.stats["truncated"] += 1
                self._log(task, attempt, started, user, text, "")
                if not reply.truncated:
                    self._cache_put(key, text)
                self.stats["seconds"] += time.time() - started
                return text
            except LLMError as exc:
                last_exc = exc
                self._log(task, attempt, started, user, "", "%s: %s" % (type(exc).__name__, exc))
                self.stats["seconds"] += time.time() - started
                if attempt + 1 < attempts:
                    self.stats["retries"] += 1
                    self.sleep(self.backoff * (2 ** attempt))
        self.stats["failures"] += 1
        raise last_exc if last_exc is not None else LLMOutputError("no answer")

    # -- internals ------------------------------------------------------------
    def _invoke(self, messages: Messages, schema: Optional[Dict[str, Any]]) -> Reply:
        assert self.transport is not None
        try:
            reply = call_with_timeout(lambda: self.transport(messages, schema), self.timeout)  # type: ignore[misc]
        except LLMTimeout:
            self.stats["timeouts"] += 1
            raise
        except LLMError:
            raise
        except Exception as exc:                        # noqa: BLE001
            raise LLMTransportError("%s: %s" % (type(exc).__name__, exc)) from exc
        if isinstance(reply, str):
            reply = Reply(reply)
        if not isinstance(reply, Reply):
            raise LLMTransportError("transport returned %s, expected Reply" % type(reply).__name__)
        return reply

    def _key(self, task: str, system: str, user: str, schema: Optional[Dict[str, Any]]) -> str:
        blob = json.dumps([self.model_id, self.prompt_version, task, system, user, schema],
                          sort_keys=True, ensure_ascii=False)
        return hashlib.sha256(blob.encode("utf-8")).hexdigest()

    def _cache_get(self, key: str) -> Any:
        if not self.cache_dir:
            return None
        path = os.path.join(self.cache_dir, key + ".json")
        try:
            with open(path, "r", encoding="utf-8") as handle:
                return json.load(handle)["value"]
        except (OSError, ValueError, KeyError):
            return None                                 # missing or corrupt: just recompute

    def _cache_put(self, key: str, value: Any) -> None:
        if not self.cache_dir:
            return
        try:
            os.makedirs(self.cache_dir, exist_ok=True)
            path = os.path.join(self.cache_dir, key + ".json")
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as handle:
                json.dump({"value": value}, handle, ensure_ascii=False)
            os.replace(tmp, path)
        except OSError:
            pass                                        # cache is best effort

    def _log(self, task: str, attempt: int, started: float, prompt: str, reply: str, error: str) -> None:
        if not self.log_path:
            return
        record: Dict[str, Any] = {"time": time.strftime("%Y-%m-%d %H:%M:%S"), "task": task,
                                  "attempt": attempt, "seconds": round(time.time() - started, 3),
                                  "error": error, "model": self.model_id}
        if self.log_full:
            record["prompt"] = prompt
            record["reply"] = reply
        try:
            os.makedirs(os.path.dirname(self.log_path) or ".", exist_ok=True)
            with open(self.log_path, "a", encoding="utf-8") as handle:
                handle.write(json.dumps(record, ensure_ascii=False) + "\n")
        except OSError:
            pass                                        # logging must never break a run


def build_client(cfg: Dict[str, Any], run_dir: Optional[str], cache_dir: Optional[str] = None) -> LLMClient:
    """Create the client described by cfg['llm']. backend 'none' = rules only."""
    llm = cfg["llm"]
    backend = (llm.get("backend") or "none").lower()
    if backend == "none":
        return LLMClient(None, model_id="none")
    base_url = llm.get("base_url")
    if backend == "ollama" and not base_url:
        base_url = "http://localhost:11434"
    transport = LangChainTransport(
        backend=backend, model=llm["model"], base_url=base_url,
        temperature=float(llm.get("temperature", 0.0)), max_tokens=int(llm.get("max_tokens", 1024)),
        timeout=float(llm.get("timeout", 120.0)), num_ctx=llm.get("num_ctx"),
        fold=bool(llm.get("fold_system", True)))
    use_cache = bool(llm.get("cache", True))
    return LLMClient(
        transport, model_id="%s:%s" % (backend, llm["model"]),
        retries=int(llm.get("retries", 2)), backoff=float(llm.get("backoff", 1.0)),
        timeout=float(llm.get("timeout", 120.0)),
        cache_dir=(cache_dir or (os.path.join(run_dir, "llm_cache") if run_dir else None)) if use_cache else None,
        log_path=os.path.join(run_dir, "llm_log.jsonl") if run_dir else None,
        log_full=bool(llm.get("log_full", True)))

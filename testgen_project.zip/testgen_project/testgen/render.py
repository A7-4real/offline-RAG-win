"""Stage 8: spec JSON -> tpf text. No LLM, no I/O.

The renderer only trusts the spec: every item already carries its `symbol`
(or None when unresolved). Syntax lives in config['formats'] (templates), so a
syntax change never touches code.

Rules
    scalar input     <sym>[<default input mask>] <-> value
    scalar check     <sym>[<default check mask>] <-> value/
    lane check       computers that share a value go on ONE line:
                     [1,0,1,0] -> sym[1010] <-> 1/  and  sym[0101] <-> 0/
    channel lanes    cannot be written until the syntax is known -> '# TODO' line
                     (or masks when input_lane_render = "mask")
    unresolved item  ??UNRESOLVED: <label> = <values>??  (never skipped silently)
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple

from .config import DEFAULT_FORMATS
from .issues import make_issue


def clean(value: Any) -> str:
    """One-line, trimmed text."""
    return re.sub(r"\s+", " ", str(value)).strip()


def lane_groups(values: List[Optional[str]]) -> List[Tuple[str, str]]:
    """[(mask, value)] with one entry per distinct value, in first-seen order.
    Lanes whose value is None ("don't care") are left out of every mask."""
    order: List[str] = []
    members: Dict[str, List[int]] = {}
    for i, raw in enumerate(values):
        if raw is None:
            continue
        v = clean(raw)
        if v == "":
            continue
        if v not in members:
            members[v] = []
            order.append(v)
        members[v].append(i)
    out = []
    for v in order:
        idx = set(members[v])
        out.append(("".join("1" if i in idx else "0" for i in range(len(values))), v))
    return out


class Renderer:
    def __init__(self, cfg: Dict[str, Any]) -> None:
        self.cfg = cfg
        self.issues: List[Dict[str, str]] = []
        self._agg: Dict[Tuple[str, str], Dict[str, Any]] = {}   # repeated findings, one issue per column
        self.lines: List[str] = []
        self.stats = {"unresolved": 0, "todo": 0, "items": 0}

    def fmt(self, _key: str, **kw: Any) -> str:
        """Apply format template `_key` (its placeholders, e.g. name=, arrive as keywords)."""
        template = self.cfg["formats"].get(_key) or DEFAULT_FORMATS[_key]
        try:
            return template.format(**kw)
        except (KeyError, IndexError, ValueError):
            self.issues.append(make_issue("error", "render", "format %r could not be applied; default used" % _key))
            return DEFAULT_FORMATS[_key].format(**kw)

    def emit(self, line: str) -> None:
        self.lines.append(line)

    def note(self, kind: str, key: str, message: str, location: str, fix: str) -> None:
        """Remember a finding that repeats for every row; reported once with a count."""
        entry = self._agg.setdefault((kind, key), {"n": 0, "message": message, "location": location, "fix": fix})
        entry["n"] += 1

    def flush_notes(self) -> None:
        for entry in self._agg.values():
            more = "" if entry["n"] == 1 else " (%d occurrences, first shown)" % entry["n"]
            self.issues.append(make_issue("review", "render", entry["message"] + more, entry["location"], entry["fix"]))
        self._agg.clear()

    def unresolved(self, item: Dict[str, Any], loc: str) -> None:
        vals = item.get("lanes") if item.get("lanes") is not None else [item.get("value")]
        shown = ",".join("" if v is None else clean(v) for v in vals)
        label = item.get("label") or item.get("variable") or "?"
        self.emit(self.fmt("unresolved", text="%s = %s" % (label, shown)))
        self.stats["unresolved"] += 1
        self.note("unresolved", label, "no symbol for %r; line written as ??UNRESOLVED??" % label,
                  item.get("source") or loc, "add the variable to symbols.csv or fix the recipe")

    def item(self, item: Dict[str, Any], kind: str, loc: str) -> None:
        """kind: set_input | check | verify"""
        self.stats["items"] += 1
        sym = item.get("symbol")
        if not sym:
            self.unresolved(item, loc)
            return
        if kind == "verify":
            self.emit(self.fmt("verify", sym=sym))
            return
        mask_default = self.cfg["default_masks"]["input" if kind == "set_input" else "check"]
        lanes = item.get("lanes")
        if lanes is None:
            value = clean(item.get("value", ""))
            if value:
                self.emit(self.fmt(kind, sym=sym, mask=mask_default, value=value))
            return
        meaning = item.get("lane_meaning", "none")
        as_mask = meaning == "computer" or (meaning == "channel" and self.cfg["input_lane_render"] == "mask")
        if as_mask:
            if meaning == "computer" and len(lanes) != self.cfg["num_computers"]:
                self.note("masklen", sym, "%s has %d lane values but num_computers is %d"
                          % (sym, len(lanes), self.cfg["num_computers"]), item.get("source") or loc, "")
            for mask, value in lane_groups(lanes):
                self.emit(self.fmt(kind, sym=sym, mask=mask, value=value))
            return
        shown = ",".join("-" if v is None else clean(v) for v in lanes)
        self.emit(self.fmt("todo", text="%s: %d %s lanes [%s]; syntax not defined" % (sym, len(lanes), meaning, shown)))
        self.stats["todo"] += 1
        self.note("todo", sym, "%s has %s lanes; no tpf syntax is defined for them (TODO line written)" % (sym, meaning),
                  item.get("source") or loc, "show the target syntax, or set input_lane_render to 'mask'")

    def global_init(self, init: Dict[str, Any]) -> None:
        funcs = init.get("funcs", [])
        tests = init.get("test_variables", [])
        verifies = init.get("verify_variables", [])
        if not (funcs or tests or verifies):
            return
        self.emit(self.fmt("section_init"))
        for name in funcs:
            self.emit(self.fmt("init_func", name=name))
        for t in tests:
            if t.get("symbol"):
                self.emit(self.fmt("init_check", sym=t["symbol"], value=clean(t.get("expected_value", ""))))
            else:
                self.unresolved({"label": t.get("variable_text", "?"), "value": t.get("expected_value")}, "global init")
        for v in verifies:
            if v.get("symbol"):
                self.emit(self.fmt("init_verify", sym=v["symbol"]))
            else:
                self.unresolved({"label": v.get("variable_text", "?"), "value": ""}, "global init")

    def case(self, case: Dict[str, Any]) -> None:
        loc = "case %s" % case["id"]
        self.emit(self.fmt("case_header", n=case["ordinal"], id=case["id"]))
        setup = case["setup_test_case_environment"]
        if setup.get("func") or setup.get("target_computer"):
            self.emit(self.fmt("section_env"))
            for name in setup.get("func", []):
                self.emit(self.fmt("env_func", name=name))
            comp = setup.get("target_computer", [])
            if comp:
                if all(str(c) in ("0", "1") for c in comp):
                    self.emit(self.fmt("env_computers", mask="".join(str(int(c)) for c in comp)))
                else:
                    self.issues.append(make_issue("error", "render", "target_computer %r is not a list of 0/1" % (comp,), loc))
        verify = case.get("verify_test_case_environment", [])
        if verify:
            self.emit(self.fmt("section_env_verify"))
            exp = self.cfg.get("env_expectations", {})
            for v in verify:
                var = v.get("variable") if isinstance(v, dict) else None
                sym = v.get("symbol") if isinstance(v, dict) else None
                label = v.get("variable_text", var) if isinstance(v, dict) else str(v)
                if not sym:
                    self.unresolved({"label": label, "value": ""}, loc)
                    continue
                value = None
                for func in setup.get("func", []):
                    if var in exp.get(func, {}):
                        value = exp[func][var]
                if value is None:
                    self.emit(self.fmt("env_verify", sym=sym))
                else:
                    self.emit(self.fmt("env_check", sym=sym, value=clean(value)))
        steps = case.get("steps", [])
        for s_idx, step in enumerate(steps, start=1):
            if len(steps) > 1:
                self.emit(self.fmt("step_header", n=s_idx))
            if step.get("set_input"):
                self.emit(self.fmt("section_inputs"))
                for it in step["set_input"]:
                    self.item(it, "set_input", loc)
            if step.get("check_expected_output") or step.get("verify_only"):
                self.emit(self.fmt("section_checks"))
                for it in step.get("check_expected_output", []):
                    self.item(it, "check", loc)
                for it in step.get("verify_only", []):
                    self.item(it, "verify", loc)


def render_spec(spec: Dict[str, Any], cfg: Dict[str, Any]) -> Tuple[List[str], List[Dict[str, str]], Dict[str, int]]:
    """Return (lines, issues, stats)."""
    r = Renderer(cfg)
    if cfg.get("emit_global_init"):
        r.global_init(spec.get("global_init", {}))
    for case in spec.get("test_cases", []):
        r.case(case)
    if not spec.get("test_cases"):
        r.emit("# no test cases were produced (see review.md)")
    r.flush_notes()
    return r.lines, r.issues, dict(r.stats, lines=len(r.lines))

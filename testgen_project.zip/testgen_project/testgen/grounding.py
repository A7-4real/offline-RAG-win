"""Variable grounding: free text -> canonical variable name -> symbol.

The symbol table (symbols.csv) is the single source of truth. The model never
invents or recalls a variable name; it only *chooses* from a short candidate
list that code computed (see choose_with_llm).

Resolution status
    exact      normalized text equals a variable, alias or symbol
    fuzzy      one clear best match (score >= accept and margin >= margin)
    ambiguous  plausible candidates but no clear winner -> ask the LLM / human
    none       nothing close -> flagged, never guessed
"""
from __future__ import annotations

import csv
import io
import os
import re
from difflib import SequenceMatcher
from typing import Any, Dict, List, Optional, Tuple

from .issues import FatalError, make_issue
from .llm_client import LLMClient, LLMError
from .schema import choose_variable_schema

_CAMEL = re.compile(r"([a-z0-9])([A-Z])")
_NON_ALNUM = re.compile(r"[^a-z0-9]+")


def normalize(text: str) -> str:
    """'Driver_Pannel autoGas' -> 'driver pannel auto gas'."""
    text = _CAMEL.sub(r"\1 \2", str(text))
    return _NON_ALNUM.sub(" ", text.lower()).strip()


def score(a: str, b: str) -> float:
    """Similarity of two *normalized* strings in [0, 1]."""
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    ta, tb = set(a.split()), set(b.split())
    token = len(ta & tb) / float(len(ta | tb))
    seq = SequenceMatcher(None, a, b).ratio()
    squashed = SequenceMatcher(None, a.replace(" ", ""), b.replace(" ", "")).ratio()
    return max(seq, squashed, 0.5 * squashed + 0.5 * token)


class SymbolTable:
    """variable -> symbol map with fuzzy lookup."""

    def __init__(self, rows: List[Dict[str, str]]) -> None:
        self.rows: Dict[str, Dict[str, str]] = {}
        self.symbol_to_var: Dict[str, str] = {}
        self._names: Dict[str, List[str]] = {}          # variable -> normalized names
        self._exact: Dict[str, str] = {}                # normalized name -> variable
        self._tokens: Dict[str, set] = {}               # token -> variables
        self._cache: Dict[Tuple[str, int], List[Tuple[str, float]]] = {}
        for row in rows:
            var = row["variable"]
            self.rows[var] = row
            self.symbol_to_var.setdefault(row["symbol"], var)
            names = [var] + [a for a in row.get("aliases", "").split("|") if a.strip()]
            norm_names = []
            for name in names:
                norm = normalize(name)
                if not norm:
                    continue
                norm_names.append(norm)
                self._exact.setdefault(norm, var)
                for tok in norm.split():
                    self._tokens.setdefault(tok, set()).add(var)
            self._names[var] = norm_names
            self._exact.setdefault(normalize(row["symbol"]), var)

    def __len__(self) -> int:
        return len(self.rows)

    def has_variable(self, variable: Optional[str]) -> bool:
        return variable in self.rows

    def symbol_for(self, variable: Optional[str]) -> Optional[str]:
        row = self.rows.get(variable or "")
        return row["symbol"] if row else None

    def description(self, variable: str) -> str:
        return self.rows.get(variable, {}).get("description", "")

    def candidates(self, text: str, top_n: int = 5, floor: float = 0.0) -> List[Tuple[str, float]]:
        """Best-matching variables for `text`, highest score first."""
        norm = normalize(text)
        key = (norm, top_n)
        if key in self._cache:
            return [c for c in self._cache[key] if c[1] >= floor]
        if not norm:
            return []
        pool = set()
        for tok in norm.split():
            pool |= self._tokens.get(tok, set())
        if len(pool) < top_n * 3:                       # few token hits: scan everything
            pool = set(self.rows)
        scored: List[Tuple[str, float]] = []
        for var in pool:
            best = 0.0
            for name in self._names.get(var, []):
                matcher = SequenceMatcher(None, norm, name)
                if matcher.real_quick_ratio() < 0.4 or matcher.quick_ratio() < 0.4:
                    continue
                best = max(best, score(norm, name))
            if best > 0:
                scored.append((var, round(best, 4)))
        scored.sort(key=lambda item: (-item[1], item[0]))
        result = scored[:top_n]
        self._cache[key] = result
        return [c for c in result if c[1] >= floor]

    def resolve(self, text: str, ground_cfg: Dict[str, Any]) -> Dict[str, Any]:
        """Rule-based resolution; see module docstring for the statuses."""
        norm = normalize(text)
        if norm in self._exact:
            var = self._exact[norm]
            return {"status": "exact", "variable": var, "score": 1.0, "candidates": [(var, 1.0)]}
        cands = self.candidates(text, int(ground_cfg["top_n"]), float(ground_cfg["floor"]))
        if not cands:
            return {"status": "none", "variable": None, "score": 0.0, "candidates": []}
        best = cands[0]
        second = cands[1][1] if len(cands) > 1 else 0.0
        if best[1] >= ground_cfg["accept"] and (best[1] - second) >= ground_cfg["margin"]:
            return {"status": "fuzzy", "variable": best[0], "score": best[1], "candidates": cands}
        return {"status": "ambiguous", "variable": None, "score": best[1], "candidates": cands}


def load_symbols(path: str) -> Tuple[SymbolTable, List[Dict[str, str]]]:
    """Read symbols.csv: columns variable,symbol[,description][,aliases (a|b|c)]."""
    issues: List[Dict[str, str]] = []
    if not path or not os.path.isfile(path):
        raise FatalError("symbols file not found: %s" % path)
    with open(path, "rb") as handle:
        raw = handle.read()
    if not raw.strip():
        raise FatalError("symbols file is empty: %s" % path)
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = raw.decode("latin-1")
        issues.append(make_issue("info", "config", "symbols file is not UTF-8; read as latin-1"))
    try:
        dialect = csv.Sniffer().sniff(text[:2048], delimiters=",;\t")
    except csv.Error:
        dialect = csv.excel
    reader = csv.DictReader(io.StringIO(text), dialect=dialect)
    if not reader.fieldnames:
        raise FatalError("symbols file has no header row")
    fields = {(name or "").strip().lower(): name for name in reader.fieldnames}
    var_col = fields.get("variable") or fields.get("name")
    sym_col = fields.get("symbol")
    if not var_col or not sym_col:
        raise FatalError("symbols file needs the columns 'variable' and 'symbol' (found: %s)"
                         % ", ".join(reader.fieldnames))
    desc_col = fields.get("description")
    alias_col = fields.get("aliases")
    rows: List[Dict[str, str]] = []
    seen_var: Dict[str, int] = {}
    seen_sym: Dict[str, str] = {}
    for line_no, rec in enumerate(reader, start=2):
        var = (rec.get(var_col) or "").strip()
        sym = (rec.get(sym_col) or "").strip()
        if not var and not sym:
            continue
        if not var or not sym:
            issues.append(make_issue("review", "config", "symbols line %d is incomplete; skipped" % line_no,
                                     "symbols.csv:%d" % line_no, "fill both variable and symbol"))
            continue
        if var in seen_var:
            issues.append(make_issue("review", "config", "duplicate variable %r (line %d); first entry kept"
                                     % (var, line_no), "symbols.csv:%d" % line_no))
            continue
        if sym in seen_sym:
            issues.append(make_issue("review", "config", "symbol %r is used by both %r and %r"
                                     % (sym, seen_sym[sym], var), "symbols.csv:%d" % line_no,
                                     "two variables must not share a symbol"))
        seen_var[var] = line_no
        seen_sym.setdefault(sym, var)
        rows.append({"variable": var, "symbol": sym,
                     "description": (rec.get(desc_col) or "").strip() if desc_col else "",
                     "aliases": (rec.get(alias_col) or "").strip() if alias_col else ""})
    if not rows:
        raise FatalError("symbols file contains no usable rows")
    return SymbolTable(rows), issues


def choose_with_llm(client: LLMClient, symbols: SymbolTable, phrase: str,
                    candidates: List[Tuple[str, float]], context: str,
                    ) -> Optional[str]:
    """Let the model pick ONE of the code-computed candidates (or NONE).

    The answer is constrained to the candidate names by the schema and
    re-checked here; anything else raises LLMError, which the caller turns into
    an 'unresolved' item. Returns the variable or None (model said NONE).
    """
    names = [c[0] for c in candidates]
    if not names:
        return None
    lines = []
    for var, sc in candidates:
        desc = symbols.description(var)
        lines.append("- %s%s" % (var, (" (" + desc + ")") if desc else ""))
    user = (
        "TASK: choose_variable\n"
        "Pick the variable that the phrase refers to. Use only the candidates below. "
        "If none fits, answer NONE.\n\n"
        "Context: %s\nPhrase: \"%s\"\nCandidates:\n%s\n\n"
        "Answer as JSON: {\"variable\": \"<candidate or NONE>\"}" % (context, phrase, "\n".join(lines)))
    system = "You match phrases from test documents to variable names. Answer only with JSON."
    answer = client.ask_json("choose_variable", system, user, choose_variable_schema(names))
    choice = answer["variable"]
    return None if choice == "NONE" else choice

"""Stage 3: one *recipe* per table says what every column means.

A recipe is the reviewable decision "column X of this table layout = variable Y,
and it is a test input / expected check / ...". Values never pass through the
LLM; code copies them from the decoded table using the recipe.

Recipe shape (JSON)
    {"layout_hash": "...", "role": "expected", "approved": false, "from_cache": false,
     "fields": {"Section A / Power Status": {"kind": "check", "variable": "power_status",
                "lane_meaning": "none", "source": "rule", "confidence": 1.0, "reason": ""}}}
kind: set_input | check | verify_only | ignore | env_func | env_computers | env_verify
source: config (table_column_map) | rule | llm | cache | default

How a field is resolved (first match wins)
    1. column empty everywhere                  -> ignore
    2. config table_column_map                  -> as configured
    3. header matches ignore_header_patterns    -> ignore (remarks, comments, ...)
    4. keyword/fuzzy match against symbols.csv  -> exact or clear fuzzy match
    5. ambiguous match                          -> LLM picks ONE candidate (or NONE)
    6. nothing close                            -> unresolved (kept, flagged, rendered as ??UNRESOLVED??)
Recipes are cached per (layout, role) in recipe_dir so the same layout never asks
the LLM twice. Edit the cached file and set "approved": true to lock it.
"""
from __future__ import annotations

import json
import os
import re
from typing import Any, Dict, List, Optional, Tuple

from .grounding import SymbolTable, normalize
from .issues import make_issue
from .llm_client import LLMClient, LLMError
from .prompts import SYSTEM_JSON, field_map_prompt
from .roles import EXPECTED_WORDS, INPUT_WORDS
from .schema import field_map_schema

KIND_HELP = {
    "set_input": "the value is SET as a test input",
    "check": "the value is CHECKED as an expected output",
    "verify_only": "the value is only looked at manually",
    "ignore": "not needed in the test file",
}
ROLE_KINDS = {"input": ["set_input", "verify_only", "ignore"],
              "expected": ["check", "verify_only", "ignore"],
              "mixed": ["set_input", "check", "verify_only", "ignore"]}
ALL_KINDS = ["set_input", "check", "verify_only", "ignore", "env_func", "env_computers", "env_verify"]
_STATUS_RANK = {"exact": 3, "fuzzy": 2, "ambiguous": 1, "none": 0}


def _texts(path: List[str]) -> List[str]:
    """Phrases to try for grounding: leaf, last two segments, whole path."""
    if not path:
        return []
    out = [path[-1]]
    if len(path) >= 2:
        out.append(" ".join(path[-2:]))
    if len(path) >= 3:
        out.append(" ".join(path))
    return out


def _lookup_column_map(cmap: Dict[str, Any], key: str, path: List[str]) -> Optional[Dict[str, Any]]:
    wanted = [key] + _texts(path)[::-1]
    index = {normalize(k): v for k, v in cmap.items()}
    for text in wanted:
        hit = index.get(normalize(text))
        if hit is not None:
            return {"variable": hit} if isinstance(hit, str) else dict(hit)
    return None


def _kind_from_keywords(text: str) -> Optional[str]:
    norm = " " + normalize(text) + " "
    n_in = sum(1 for w in INPUT_WORDS if w in norm)
    n_out = sum(1 for w in EXPECTED_WORDS if w in norm)
    if n_in > n_out:
        return "set_input"
    if n_out > n_in:
        return "check"
    return None


def _cache_path(recipe_dir: Optional[str], layout: str, role: str) -> Optional[str]:
    return os.path.join(recipe_dir, "%s_%s.json" % (layout, role)) if recipe_dir else None


def _load_cached(path: Optional[str], table: Dict[str, Any], symbols: SymbolTable) -> Optional[Dict[str, Any]]:
    if not path or not os.path.isfile(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as handle:
            rec = json.load(handle)
        fields = rec["fields"]
        keys = {f["key"] for f in table["fields"]}
        if set(fields) != keys:
            return None
        for entry in fields.values():
            if entry["kind"] not in ALL_KINDS:
                return None
            if entry.get("variable") is not None and not symbols.has_variable(entry["variable"]):
                return None
        return rec
    except (OSError, ValueError, KeyError, TypeError):
        return None                                   # unreadable cache: rebuild


def _save_cached(path: Optional[str], recipe: Dict[str, Any]) -> None:
    if not path:
        return
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(recipe, handle, indent=2, ensure_ascii=False)
        os.replace(tmp, path)
    except OSError:
        pass


def _lane_meaning(fld: Dict[str, Any], kind: str, cfg: Dict[str, Any], spec: Optional[Dict[str, Any]] = None) -> str:
    if fld["kind"] != "lanes":
        return "none"
    if spec and spec.get("lane_meaning") in ("computer", "channel", "bit", "none"):
        return spec["lane_meaning"]
    return cfg["lane_meaning"].get(kind, "none")


def _map_field(fld: Dict[str, Any], role: str, table: Dict[str, Any], tlabel: str,
               symbols: SymbolTable, client: LLMClient, cfg: Dict[str, Any],
               issues: List[Dict[str, str]]) -> Dict[str, Any]:
    key, path = fld["key"], fld["path"]
    loc = "%s / %s" % (tlabel, key)
    default_kind = {"input": "set_input", "expected": "check"}.get(role)
    values = [v for row in table["rows"] for v in row["values"][key] if v not in (None, "")]
    if not values:
        return {"kind": "ignore", "variable": None, "lane_meaning": "none", "source": "rule",
                "confidence": 1.0, "reason": "column has no values"}
    # 2. explicit configuration
    spec = _lookup_column_map(cfg["table_column_map"], key, path)
    if spec is not None:
        kind = spec.get("kind") or default_kind or _kind_from_keywords(key) or "check"
        var = spec.get("variable")
        if kind not in ALL_KINDS:
            issues.append(make_issue("review", "recipes", "table_column_map: unknown kind %r for %s" % (kind, key), loc))
            kind = default_kind or "check"
        if var is not None and not symbols.has_variable(var):
            issues.append(make_issue("review", "recipes", "table_column_map: variable %r is not in symbols.csv" % var, loc))
            var = None
        return {"kind": kind, "variable": var, "lane_meaning": _lane_meaning(fld, kind, cfg, spec),
                "source": "config", "confidence": 1.0, "reason": "table_column_map"}
    # 3. headers that never carry test data
    leaf = path[-1] if path else key
    for pat in cfg["ignore_header_patterns"]:
        if re.search(pat, leaf.strip(), re.I):
            return {"kind": "ignore", "variable": None, "lane_meaning": "none", "source": "rule",
                    "confidence": 1.0, "reason": "header matches ignore pattern %r" % pat}
    # 4. rule-based grounding over several phrases, keep the best result
    best: Optional[Dict[str, Any]] = None
    pool: Dict[str, float] = {}
    for text in _texts(path) or [key]:
        res = symbols.resolve(text, cfg["grounding"])
        for var, sc in res["candidates"]:
            pool[var] = max(pool.get(var, 0.0), sc)
        rank = (_STATUS_RANK[res["status"]], res["score"])
        if best is None or rank > (_STATUS_RANK[best["status"]], best["score"]):
            best = res
    assert best is not None
    kind = default_kind or _kind_from_keywords(" ".join(path)) or None
    if best["status"] in ("exact", "fuzzy") and kind:
        return {"kind": kind, "variable": best["variable"], "lane_meaning": _lane_meaning(fld, kind, cfg),
                "source": "rule", "confidence": best["score"], "reason": best["status"] + " match"}
    # 5. ambiguous (or mixed table): let the LLM choose among code-computed candidates
    cands = sorted(pool.items(), key=lambda kv: (-kv[1], kv[0]))[:int(cfg["grounding"]["top_n"])]
    cands = [c for c in cands if c[1] >= float(cfg["grounding"]["floor"])]
    if best["status"] in ("exact", "fuzzy"):
        cands = [(best["variable"], best["score"])]
    if cands and client.enabled:
        kinds = ROLE_KINDS.get(role, ROLE_KINDS["mixed"])
        samples = []
        for row in table["rows"][:3]:
            vals = ",".join("" if v is None else v for v in row["values"][key])
            samples.append(vals)
        prompt = field_map_prompt(role, key, fld["kind"], fld["lane_labels"], samples,
                                  [c[0] for c in cands], {k: KIND_HELP[k] for k in kinds})
        try:
            ans = client.ask_json("field_map", SYSTEM_JSON, prompt,
                                  field_map_schema([c[0] for c in cands], kinds))
            var = None if ans["variable"] == "NONE" else ans["variable"]
            k = ans["kind"] if var is not None or ans["kind"] == "ignore" else "ignore"
            if var is None and k != "ignore":
                k = "ignore"
            return {"kind": k, "variable": var, "lane_meaning": _lane_meaning(fld, k, cfg),
                    "source": "llm", "confidence": 0.5, "reason": ans["reason"]}
        except LLMError as exc:
            issues.append(make_issue("review", "recipes", "LLM could not map column %s (%s)" % (key, exc), loc))
    # 6. unresolved: keep the column so nothing disappears silently
    final_kind = kind or default_kind or "check"
    var = best["variable"] if best["status"] in ("exact", "fuzzy") else None
    issues.append(make_issue(
        "review", "recipes",
        "column %r could not be linked to a variable (best candidates: %s)"
        % (key, ", ".join(c[0] for c in cands[:3]) or "none"), loc,
        "add it to table_column_map in config.json or edit the recipe file and set approved=true"))
    return {"kind": final_kind, "variable": var, "lane_meaning": _lane_meaning(fld, final_kind, cfg),
            "source": "default", "confidence": 0.0, "reason": "unresolved"}


def build_recipes(blocks: List[Dict[str, Any]], roles: Dict[str, Dict[str, Any]], symbols: SymbolTable,
                  client: LLMClient, cfg: Dict[str, Any], recipe_dir: Optional[str]
                  ) -> Tuple[Dict[str, Dict[str, Any]], List[Dict[str, str]]]:
    """Return ({table block id: recipe}, issues)."""
    issues: List[Dict[str, str]] = []
    recipes: Dict[str, Dict[str, Any]] = {}
    for b in blocks:
        if b["kind"] != "table" or b["table"] is None:
            continue
        role = roles.get(b["id"], {}).get("role", "ignore")
        if role == "ignore":
            continue
        table = b["table"]
        tlabel = "T%d" % (b["table_index"] + 1)
        path = _cache_path(recipe_dir, table["layout_hash"], role)
        cached = _load_cached(path, table, symbols)
        if cached is not None:
            cached["from_cache"] = True
            recipes[b["id"]] = cached
            if not cached.get("approved"):
                issues.append(make_issue("review", "recipes",
                                         "recipe for %s (layout %s) was reused from cache but is not approved"
                                         % (tlabel, table["layout_hash"]), tlabel,
                                         "check %s and set \"approved\": true" % path))
            continue
        fields: Dict[str, Dict[str, Any]] = {}
        for fld in table["fields"]:
            fields[fld["key"]] = _map_field(fld, role, table, tlabel, symbols, client, cfg, issues)
        recipe = {"layout_hash": table["layout_hash"], "role": role, "approved": False,
                  "from_cache": False, "table_block": b["id"], "fields": fields}
        recipes[b["id"]] = recipe
        _save_cached(path, recipe)
        issues.append(make_issue("review", "recipes",
                                 "recipe for %s (layout %s) was generated automatically and is not approved"
                                 % (tlabel, table["layout_hash"]), tlabel,
                                 "check %s and set \"approved\": true" % (path or "03_recipes.json")))
    return recipes, issues

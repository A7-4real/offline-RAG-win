"""Fake model for tests and dry runs (no LLM needed).

FakeModel answers every prompt type the pipeline sends, by parsing the prompt,
like a competent small model would. `fail` injects failures per task:
    fail={"table_role": ("malformed", None)}   # always
    fail={"field_map": ("exception", 1)}       # only the first call
modes: malformed | bad_enum | truncated | exception | timeout | empty | fenced
"""
from __future__ import annotations

import json
import re
import time
from typing import Any, Callable, Dict, List, Optional, Tuple

from .llm_client import LLMTransportError, Reply


def _task(messages: List[Tuple[str, str]]) -> str:
    m = re.match(r"\s*TASK:\s*(\w+)", messages[-1][1])
    return m.group(1) if m else "unknown"


class FakeModel:
    def __init__(self, fail: Optional[Dict[str, Tuple[str, Optional[int]]]] = None,
                 overrides: Optional[Dict[str, Callable[[str], Any]]] = None, sleep_for: float = 0.3) -> None:
        self.fail = dict(fail or {})
        self.overrides = overrides or {}
        self.calls: List[str] = []
        self.sleep_for = sleep_for
        self._counts: Dict[str, int] = {}

    # -- Transport interface ---------------------------------------------------
    def __call__(self, messages: List[Tuple[str, str]], schema: Optional[Dict[str, Any]] = None) -> Reply:
        task = _task(messages)
        self.calls.append(task)
        n = self._counts[task] = self._counts.get(task, 0) + 1
        prompt = messages[-1][1]
        mode = self.fail.get(task)
        if mode and (mode[1] is None or n <= mode[1]):
            return self._broken(mode[0], task, prompt)
        if task in self.overrides:
            res = self.overrides[task](prompt)
            return res if isinstance(res, Reply) else Reply(res if isinstance(res, str) else json.dumps(res))
        return Reply(self._answer(task, prompt))

    def _broken(self, mode: str, task: str, prompt: str) -> Reply:
        if mode == "exception":
            raise LLMTransportError("connection refused (fake)")
        if mode == "timeout":
            time.sleep(self.sleep_for)
            return Reply("{}")
        if mode == "malformed":
            return Reply("Sure! Here is my answer: it is probably the second one.")
        if mode == "empty":
            return Reply("")
        if mode == "truncated":
            return Reply('{"labels": [{"id": "S0', truncated=True)
        if mode == "bad_enum":
            return Reply(json.dumps({"labels": [{"id": "S000", "label": "banana"}], "role": "banana",
                                     "variable": "banana", "kind": "banana"}))
        if mode == "fenced":
            return Reply("```json\n" + self._answer(task, prompt) + "\n```")
        raise ValueError("unknown fail mode %r" % mode)

    # -- sensible answers ----------------------------------------------------------
    def _answer(self, task: str, prompt: str) -> str:
        if task == "section_labels":
            labels = []
            for m in re.finditer(r"^\[(S\d+)\].*?hint: (\w+)", prompt, re.M):
                hint = m.group(2)
                labels.append({"id": m.group(1), "label": hint if hint not in ("none", "") else "other"})
            return json.dumps({"labels": labels})
        if task == "table_role":
            hint = (re.search(r"Rule-based hint: (\w+)", prompt) or [None, "ignore"])[1]
            return json.dumps({"reason": "fake", "role": hint if hint in ("input", "expected", "mixed", "ignore") else "ignore"})
        if task == "field_map":
            role = re.search(r"Table role: (\w+)", prompt).group(1)
            block = re.search(r"Candidate variables:\n((?:- .*\n?)+)", prompt).group(1)
            names = [l[2:].strip() for l in block.splitlines() if l.startswith("- ") and "no candidates" not in l]
            if not names:
                return json.dumps({"reason": "none", "variable": "NONE", "kind": "ignore"})
            return json.dumps({"reason": "first candidate", "variable": names[0],
                               "kind": {"input": "set_input", "expected": "check"}.get(role, "check")})
        if task == "choose_variable":
            block = re.search(r"Candidates:\n((?:- .*\n?)+)", prompt).group(1)
            first = block.splitlines()[0][2:].split(" (")[0].strip()
            return json.dumps({"variable": first})
        if task == "notes_normalize":
            text = prompt.split("TEXT:\n", 1)[1]
            funcs = [w.upper() for w in ("boot", "load") if re.search(r"\b%s\b" % w, text, re.I)]
            checks = ["%s = %s" % (a, b) for a, b in re.findall(r"(\w+) is (\d+)", text)]
            verify = re.findall(r"the (\w+) value manually", text)
            cons = [s.strip() for s in text.split(".") if "must" in s]
            return ("FUNCTIONS: %s\nCHECKS: %s\nVERIFY: %s\nCONSTRAINTS: %s"
                    % (", ".join(funcs) or "NONE", "; ".join(checks) or "NONE", ", ".join(verify) or "NONE",
                       "; ".join(cons) or "NONE"))
        if task == "notes_extract":
            text = prompt.split("ORIGINAL TEXT:\n", 1)[1].split("\n\nNOTES:", 1)[0]
            funcs = [w.upper() for w in ("boot", "load") if re.search(r"\b%s\b" % w, text, re.I)]
            tests = [{"evidence": "%s is %s" % (a, b), "variable": a, "expected_value": b}
                     for a, b in re.findall(r"(\w+) is (\d+)", text)]
            verify = [{"evidence": "the %s value manually" % v, "variable": v}
                      for v in re.findall(r"the (\w+) value manually", text)]
            cons = [{"evidence": s.strip(), "text": s.strip()} for s in text.split(".") if "must" in s]
            return json.dumps({"funcs": funcs, "test_variables": tests, "verify_variables": verify, "constraints": cons})
        if task == "ping":
            return json.dumps({"ok": True})
        raise ValueError("FakeModel has no answer for task %r" % task)

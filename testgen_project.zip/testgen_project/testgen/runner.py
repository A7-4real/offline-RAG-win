"""Run the whole pipeline once. This is the function the CLI and the tests call."""
from __future__ import annotations

import os
from typing import Any, Dict, Optional, Tuple

from .graph import build_app, build_sequential_app
from .grounding import SymbolTable
from .issues import FatalError, make_issue
from .llm_client import LLMClient
from .report import write_reports
from .stages import RunContext


def run_pipeline(input_path: str, out_dir: str, cfg: Dict[str, Any], symbols: SymbolTable,
                 client: LLMClient, recipe_dir: Optional[str] = None, strict: bool = False,
                 resume_from: Optional[int] = None, stop_after: Optional[int] = None,
                 engine: Optional[str] = None, config_issues: Optional[list] = None
                 ) -> Tuple[Dict[str, Any], int, str]:
    """Return (final_state, exit_code, engine_used). Never raises for document problems."""
    ctx = RunContext(cfg, symbols, client, input_path, out_dir, recipe_dir=recipe_dir, strict=strict,
                     resume_from=resume_from, stop_after=stop_after)
    os.makedirs(ctx.work_dir, exist_ok=True)
    initial: Dict[str, Any] = {"input_path": input_path, "issues": list(config_issues or []),
                               "stage_log": [], "fatal": None}
    wanted = engine or cfg.get("engine", "auto")
    try:
        app, used = build_app(ctx, wanted)
    except FatalError as exc:
        state = dict(initial, fatal=str(exc))
        state["issues"] = state["issues"] + [make_issue("error", "engine", str(exc))]
        return state, write_reports(ctx, state, "none"), "none"
    try:
        state = app.invoke(initial, config={"recursion_limit": 60}) if used == "langgraph" else app.invoke(initial)
    except Exception as exc:                            # noqa: BLE001 - the graph engine itself failed
        if wanted == "langgraph":
            raise
        note = make_issue("error", "engine", "%s engine failed (%s: %s); re-ran with the sequential engine"
                          % (used, type(exc).__name__, exc))
        used = "sequential"
        state = build_sequential_app(ctx).invoke(dict(initial, issues=list(initial["issues"]) + [note]))
    code = write_reports(ctx, state, used)
    return state, code, used

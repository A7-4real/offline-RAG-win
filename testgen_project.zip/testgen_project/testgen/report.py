"""Human-readable outputs: review.md, tables.md, run_report.json.

review.md is the file to read after every run: errors first, then review items,
then what the pipeline decided (section labels, table roles, recipes) and the
paragraph facts that were not turned into test lines.
"""
from __future__ import annotations

import json
import os
from typing import Any, Dict, List

from .issues import counts, dedupe, exit_code
from .stages import RunContext, write_json
from .table_decoder import to_markdown


def _issue_line(i: Dict[str, Any]) -> str:
    loc = (" `%s`" % i["location"]) if i.get("location") else ""
    fix = (" -> %s" % i["fix"]) if i.get("fix") else ""
    return "- [%s]%s %s%s" % (i["stage"], loc, i["message"], fix)


def build_review(ctx: RunContext, state: Dict[str, Any], issues: List[Dict[str, Any]], code: int,
                 engine: str) -> str:
    c = counts(issues)
    out: List[str] = ["# Review: %s" % ctx.stem, ""]
    status = {0: "clean", 1: "finished, items need review", 2: "FATAL - run did not finish"}[code]
    out.append("Status: **%s** | errors %d | review %d | info %d | engine %s | model %s"
               % (status, c["error"], c["review"], c["info"], engine, ctx.client.model_id))
    if state.get("fatal"):
        out += ["", "**Fatal:** %s" % state["fatal"]]
    for sev, title in (("error", "Errors"), ("review", "Please review")):
        items = [i for i in issues if i["severity"] == sev]
        if items:
            out += ["", "## %s (%d)" % (title, len(items))] + [_issue_line(i) for i in items]
    sections = state.get("sections", [])
    if sections:
        out += ["", "## Section labels", "", "| id | heading | label | source |", "|---|---|---|---|"]
        for s in sections:
            out.append("| %s | %s | %s | %s |" % (s["id"], s["heading"].replace("|", "/"), s["label"], s["label_source"]))
    roles = state.get("roles", {})
    if roles:
        out += ["", "## Table roles", "", "| table block | role | source | reason |", "|---|---|---|---|"]
        for tid, r in roles.items():
            out.append("| %s | %s | %s | %s |" % (tid, r["role"], r["source"], str(r["reason"]).replace("|", "/")))
    recipes = state.get("recipes", {})
    if recipes:
        out += ["", "## Recipes (column meanings)"]
        for tid, rec in recipes.items():
            out += ["", "### %s (layout %s, %s, approved=%s)" % (tid, rec["layout_hash"], rec["role"], rec.get("approved")),
                    "", "| column | kind | variable | source |", "|---|---|---|---|"]
            for key, e in rec["fields"].items():
                out.append("| %s | %s | %s | %s |" % (key.replace("|", "/"), e["kind"], e.get("variable") or "-", e["source"]))
    notes = state.get("notes", {})
    spec = state.get("spec", {})
    if notes:
        init = notes.get("init", {})
        out += ["", "## Facts from paragraphs (not turned into test lines unless emit_global_init is true)"]
        out.append("- init functions: %s" % (", ".join(init.get("funcs", [])) or "none"))
        for t in spec.get("global_init", {}).get("test_variables", []):
            out.append("- init check: %s = %s (symbol %s)" % (t["variable_text"], t["expected_value"], t.get("symbol") or "UNRESOLVED"))
        for v in spec.get("global_init", {}).get("verify_variables", []):
            out.append("- init verify: %s (symbol %s)" % (v["variable_text"], v.get("symbol") or "UNRESOLVED"))
        for ctext in spec.get("constraints", []):
            out.append("- constraint: %s" % ctext)
        for label, lines in notes.get("raw", {}).items():
            if lines:
                out += ["", "Raw %s text:" % label] + ["> " + l for l in lines]
    info = [i for i in issues if i["severity"] == "info"]
    if info:
        out += ["", "## Info (%d)" % len(info)] + [_issue_line(i) for i in info]
    stats = ctx.client.stats
    out += ["", "## LLM usage", "- calls %(calls)d, attempts %(attempts)d, cache hits %(cache_hits)d, retries %(retries)d, "
            "failures %(failures)d, truncated %(truncated)d, timeouts %(timeouts)d, seconds %(seconds).1f" % stats]
    return "\n".join(out) + "\n"


def build_tables_md(state: Dict[str, Any]) -> str:
    roles = state.get("roles", {})
    out = ["# Decoded tables", "", "Each test row is shown as its own small table. Check the decoder here first."]
    for b in state.get("blocks", []):
        if b["kind"] != "table":
            continue
        t = b["table"]
        role = roles.get(b["id"], {}).get("role", "?")
        out += ["", "## Table %d (%s) role: %s" % (b["table_index"] + 1, b["id"], role)]
        if t is None:
            out.append("_could not be decoded; text: %s_" % b["text"][:200])
            continue
        out.append("layout %s, %d header row(s), %d column(s), %d data row(s), id column: %s"
                   % (t["layout_hash"], t["n_header_rows"], t["n_cols"], t["n_rows"], t["id_column"]))
        out += ["", to_markdown(t, "per_case")]
    return "\n".join(out) + "\n"


def write_reports(ctx: RunContext, state: Dict[str, Any], engine: str) -> int:
    """Write review.md, tables.md and run_report.json. Returns the exit code."""
    issues = dedupe(state.get("issues", []))
    code = exit_code(issues, bool(state.get("fatal")))
    os.makedirs(ctx.out_dir, exist_ok=True)
    for suffix, builder in ((".review.md", lambda: build_review(ctx, state, issues, code, engine)),
                            (".tables.md", lambda: build_tables_md(state))):
        try:
            with open(ctx.path(suffix), "w", encoding="utf-8") as handle:
                handle.write(builder())
        except Exception as exc:                        # noqa: BLE001 - reports are best effort
            issues.append({"severity": "info", "stage": "report", "location": suffix,
                           "message": "could not write report: %s" % exc, "fix": ""})
    try:
        write_json(ctx.path(".run_report.json"), {
            "input": ctx.input_path, "engine": engine, "exit_code": code, "fatal": state.get("fatal"),
            "counts": counts(issues), "stages": state.get("stage_log", []),
            "llm": dict(ctx.client.stats, model=ctx.client.model_id),
            "outputs": state.get("outputs", {})})
    except OSError:
        pass
    return code

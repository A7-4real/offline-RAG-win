"""Stage 2: decide what each table is (input, expected, mixed, ignore).

Decision order per table
    1. section label: test_inputs -> input, expected_outputs -> expected
    2. a section with several data tables, or a heading/caption that contradicts
       the section label, is ambiguous -> ask the LLM (enum), else use keywords
    3. tables in sections labelled 'other' use keywords, then the LLM
    4. tables in index/document_info/requirements/constraints/initialization
       sections are ignored (the initialization file is handled elsewhere)
At least one input or expected table must exist, otherwise an error is raised.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple

from .grounding import normalize
from .issues import make_issue
from .llm_client import LLMClient, LLMError
from .prompts import SYSTEM_JSON, table_role_prompt
from .schema import table_role_schema

ROLES = ["input", "expected", "mixed", "ignore"]
INPUT_WORDS = ["input", "stimul", "set value", "setting", "test step", "test case", "precondition"]
EXPECTED_WORDS = ["expected", "output", "result", "verify", "check", "response", "outcome"]


def keyword_role(text: str) -> Optional[str]:
    """'input' / 'expected' from keywords, None if neither or both match equally."""
    norm = " " + normalize(text) + " "
    n_in = sum(1 for w in INPUT_WORDS if w in norm)
    n_out = sum(1 for w in EXPECTED_WORDS if w in norm)
    if n_in > n_out:
        return "input"
    if n_out > n_in:
        return "expected"
    return None


def _caption(blocks_by_id: Dict[str, Dict[str, Any]], section: Dict[str, Any], table_id: str) -> str:
    ids = section["block_ids"]
    pos = ids.index(table_id)
    for bid in reversed(ids[max(0, pos - 2):pos]):
        b = blocks_by_id[bid]
        if b["kind"] in ("paragraph", "list"):
            return b["text"][:200]
    return ""


def decide_roles(blocks: List[Dict[str, Any]], sections: List[Dict[str, Any]],
                 client: LLMClient, cfg: Dict[str, Any]) -> Tuple[Dict[str, Dict[str, Any]], List[Dict[str, str]]]:
    issues: List[Dict[str, str]] = []
    by_id = {b["id"]: b for b in blocks}
    sec_of: Dict[str, Dict[str, Any]] = {}
    for sec in sections:
        for tid in sec["table_block_ids"]:
            sec_of[tid] = sec
    roles: Dict[str, Dict[str, Any]] = {}
    for b in blocks:
        if b["kind"] != "table":
            continue
        tid = b["id"]
        sec = sec_of.get(tid)
        table = b["table"]
        if sec is None:
            roles[tid] = {"role": "ignore", "source": "rule", "reason": "table outside any section"}
            continue
        if table is None or not table["rows"]:
            reason = "table could not be decoded" if table is None else "table has no data rows"
            roles[tid] = {"role": "ignore", "source": "rule", "reason": reason}
            if sec["label"] in ("test_inputs", "expected_outputs", "other"):
                issues.append(make_issue("review", "roles", "table %s ignored: %s" % (tid, reason),
                                         tid, "check the table in the Word file"))
            continue
        label = sec["label"]
        caption = _caption(by_id, sec, tid)
        headers = [f["key"] for f in table["fields"]]
        kw = keyword_role(" ".join([sec["heading"], caption] + headers[:8]))
        default = {"test_inputs": "input", "expected_outputs": "expected"}.get(label)
        n_data_tables = sum(1 for x in sec["table_block_ids"]
                            if by_id[x]["table"] is not None and by_id[x]["table"]["rows"])
        ambiguous = (default is not None and (n_data_tables > 1 or (kw is not None and kw != default))) or \
                    (label == "other" and kw is None)
        if default is not None and not ambiguous:
            roles[tid] = {"role": default, "source": "section", "reason": "section label %s" % label}
            continue
        if default is None and label != "other":
            roles[tid] = {"role": "ignore", "source": "section", "reason": "section label %s" % label}
            continue
        if default is None and not ambiguous and kw is not None:
            roles[tid] = {"role": kw, "source": "rule", "reason": "keywords in heading/headers"}
            issues.append(make_issue("review", "roles", "table %s in an 'other' section was used as %s (keywords)" % (tid, kw), tid))
            continue
        # ambiguous: ask the LLM, fall back to keywords/section
        first = ""
        if table["rows"]:
            r0 = table["rows"][0]["values"]
            first = "; ".join("%s=%s" % (k, ",".join("" if v is None else v for v in vals))
                              for k, vals in list(r0.items())[:6])
        role = None
        reason = ""
        if client.enabled:
            prompt = table_role_prompt(sec["heading"], caption, label, headers[:12], first,
                                       kw or default or "", table["n_rows"])
            try:
                ans = client.ask_json("table_role", SYSTEM_JSON, prompt, table_role_schema(ROLES))
                role, reason = ans["role"], ans["reason"]
                src = "llm"
            except LLMError as exc:
                issues.append(make_issue("review", "roles", "LLM could not decide the role of table %s (%s)" % (tid, exc), tid))
        if role is None:
            role, src = (kw or default or "ignore"), "rule"
            reason = "keyword/section fallback"
        roles[tid] = {"role": role, "source": src, "reason": reason}
        if src == "rule" and default is not None and kw is not None and kw != default:
            issues.append(make_issue("review", "roles", "table %s: heading suggests %s but section says %s; used %s" % (tid, kw, default, role), tid))
        if role == "ignore" and label in ("test_inputs", "expected_outputs"):
            issues.append(make_issue("review", "roles", "table %s in a %s section was ignored" % (tid, label), tid))
    if not any(r["role"] in ("input", "expected", "mixed") for r in roles.values()):
        issues.append(make_issue("error", "roles", "no input or expected-output table was found; the test file will have no test cases",
                                 fix="check section headings, or set roles by hand in 02_roles.json and resume from stage 3"))
    return roles, issues

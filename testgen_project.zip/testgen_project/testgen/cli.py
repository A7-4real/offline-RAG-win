"""Command line interface.

    python -m testgen run SPEC.docx --symbols symbols.csv [--config config.json] [--out DIR]
                         [--backend ollama|lmstudio|none] [--model NAME] [--base-url URL]
                         [--strict] [--resume-from N] [--stop-after N] [--engine auto|langgraph|sequential]
    python -m testgen tables SPEC.docx [--header-rows N] [--transpose] [--style per_case|flat]
    python -m testgen render SPEC.spec.json [--config config.json] [--out FILE.tpf]
    python -m testgen eval GENERATED.tpf GOLD.tpf
    python -m testgen check --symbols symbols.csv [--config config.json] [--backend ...]

Exit codes: 0 clean | 1 finished with items to review | 2 fatal.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Any, Dict, List, Optional

from .config import load_config
from .eval import compare
from .grounding import load_symbols
from .issues import FatalError, counts
from .llm_client import LLMError, build_client
from .render import render_spec
from .runner import run_pipeline
from .stages import STAGE_NAMES


def _overrides(args: argparse.Namespace) -> Dict[str, Any]:
    llm: Dict[str, Any] = {}
    if getattr(args, "backend", None):
        llm["backend"] = args.backend
    if getattr(args, "model", None):
        llm["model"] = args.model
    if getattr(args, "base_url", None):
        llm["base_url"] = args.base_url
    out: Dict[str, Any] = {"llm": llm} if llm else {}
    if getattr(args, "strict", False):
        out["strict"] = True
    return out


def _stage_index(value: Optional[str]) -> Optional[int]:
    if value is None:
        return None
    if value.isdigit() and int(value) < len(STAGE_NAMES):
        return int(value)
    if value in STAGE_NAMES:
        return STAGE_NAMES.index(value)
    raise FatalError("stage must be 0-%d or one of %s" % (len(STAGE_NAMES) - 1, ", ".join(STAGE_NAMES)))


def cmd_run(args: argparse.Namespace) -> int:
    cfg, cfg_issues = load_config(args.config, _overrides(args))
    symbols, sym_issues = load_symbols(args.symbols)
    out_dir = args.out or os.path.splitext(args.spec)[0] + "_out"
    base = os.path.dirname(os.path.abspath(args.config)) if args.config else os.getcwd()
    recipe_dir = args.recipes or cfg["recipe_dir"]
    if not os.path.isabs(recipe_dir):
        recipe_dir = os.path.join(base, recipe_dir)
    client = build_client(cfg, os.path.join(out_dir, "work"))
    state, code, engine = run_pipeline(
        args.spec, out_dir, cfg, symbols, client, recipe_dir=recipe_dir, strict=args.strict,
        resume_from=_stage_index(args.resume_from), stop_after=_stage_index(args.stop_after),
        engine=args.engine, config_issues=cfg_issues + sym_issues)
    c = counts(state.get("issues", []))
    print("engine: %s | model: %s" % (engine, client.model_id))
    if state.get("fatal"):
        print("FATAL: %s" % state["fatal"], file=sys.stderr)
    else:
        print("test file: %s" % state.get("outputs", {}).get("tpf", "(not rendered)"))
    print("errors %d | review %d | info %d  -> read %s" % (
        c["error"], c["review"], c["info"], os.path.join(out_dir, os.path.splitext(os.path.basename(args.spec))[0] + ".review.md")))
    return code


def cmd_tables(args: argparse.Namespace) -> int:
    from .docx_loader import load_blocks
    from .table_decoder import to_markdown
    cfg, _ = load_config(args.config)
    if args.header_rows:
        cfg["table_options"]["header_rows"] = args.header_rows
    if args.transpose:
        cfg["table_options"]["transpose"] = True
    blocks, issues = load_blocks(args.spec, cfg)
    for b in blocks:
        if b["kind"] == "table":
            print("\n## Table %d" % (b["table_index"] + 1))
            if b["table"] is None:
                print("(could not be decoded)")
                continue
            t = b["table"]
            print("%d header rows, %d columns, %d data rows, id column: %s" % (t["n_header_rows"], t["n_cols"], t["n_rows"], t["id_column"]))
            print(to_markdown(t, args.style))
    for i in issues:
        print("[%s] %s" % (i["severity"], i["message"]), file=sys.stderr)
    return 0


def cmd_render(args: argparse.Namespace) -> int:
    cfg, _ = load_config(args.config)
    try:
        with open(args.spec_json, "r", encoding="utf-8") as handle:
            spec = json.load(handle)
    except (OSError, ValueError) as exc:
        raise FatalError("cannot read %s: %s" % (args.spec_json, exc))
    lines, issues, stats = render_spec(spec, cfg)
    out = args.out or os.path.splitext(args.spec_json)[0].replace(".spec", "") + ".tpf"
    with open(out, "w", encoding="utf-8", newline="\n") as handle:
        handle.write("\n".join(lines) + "\n")
    print("wrote %s (%d lines, %d unresolved, %d todo)" % (out, stats["lines"], stats["unresolved"], stats["todo"]))
    return 1 if issues else 0


def cmd_eval(args: argparse.Namespace) -> int:
    try:
        with open(args.generated, encoding="utf-8") as h1, open(args.gold, encoding="utf-8") as h2:
            gen, gold = h1.read(), h2.read()
    except OSError as exc:
        raise FatalError("cannot read file: %s" % exc)
    res = compare(gen, gold)
    print("precision %.3f recall %.3f f1 %.3f (matched %d of %d generated, %d gold)" % (
        res["precision"], res["recall"], res["f1"], res["matched"], res["generated_lines"], res["gold_lines"]))
    for label in ("missing", "extra"):
        for line in res[label][:30]:
            print("%s: %s" % (label, line))
    return 0


def cmd_check(args: argparse.Namespace) -> int:
    cfg, issues = load_config(args.config, _overrides(args))
    symbols, sym_issues = load_symbols(args.symbols)
    print("config ok; %d symbols loaded" % len(symbols))
    for i in issues + sym_issues:
        print("[%s] %s" % (i["severity"], i["message"]))
    client = build_client(cfg, None)
    if not client.enabled:
        print("LLM backend: none (rules only)")
        return 0
    try:
        ans = client.ask_json("ping", "Answer only with JSON.", 'TASK: ping\nReturn {"ok": true}.',
                              {"type": "object", "properties": {"ok": {"type": "boolean"}},
                               "required": ["ok"], "additionalProperties": False}, retries=0)
        print("LLM backend %s answered: %s" % (client.model_id, ans))
        return 0
    except LLMError as exc:
        print("LLM backend %s FAILED: %s" % (client.model_id, exc), file=sys.stderr)
        return 2


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="testgen", description="Word test description -> tpf test file")
    sub = p.add_subparsers(dest="command", required=True)

    def llm_args(sp: argparse.ArgumentParser) -> None:
        sp.add_argument("--config")
        sp.add_argument("--backend", choices=["ollama", "lmstudio", "none"])
        sp.add_argument("--model")
        sp.add_argument("--base-url", dest="base_url")

    r = sub.add_parser("run", help="run the full pipeline")
    r.add_argument("spec")
    r.add_argument("--symbols", required=True)
    r.add_argument("--out")
    r.add_argument("--recipes")
    r.add_argument("--strict", action="store_true")
    r.add_argument("--resume-from", dest="resume_from")
    r.add_argument("--stop-after", dest="stop_after")
    r.add_argument("--engine", choices=["auto", "langgraph", "sequential"])
    llm_args(r)
    r.set_defaults(func=cmd_run)
    t = sub.add_parser("tables", help="show how tables are decoded (no LLM)")
    t.add_argument("spec")
    t.add_argument("--config")
    t.add_argument("--header-rows", type=int, dest="header_rows")
    t.add_argument("--transpose", action="store_true")
    t.add_argument("--style", choices=["per_case", "flat"], default="per_case")
    t.set_defaults(func=cmd_tables)
    rd = sub.add_parser("render", help="re-render a hand-edited spec.json")
    rd.add_argument("spec_json")
    rd.add_argument("--config")
    rd.add_argument("--out")
    rd.set_defaults(func=cmd_render)
    e = sub.add_parser("eval", help="compare generated and gold tpf")
    e.add_argument("generated")
    e.add_argument("gold")
    e.set_defaults(func=cmd_eval)
    c = sub.add_parser("check", help="check config, symbols and the LLM connection")
    c.add_argument("--symbols", required=True)
    llm_args(c)
    c.set_defaults(func=cmd_check)
    return p


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return args.func(args)
    except FatalError as exc:
        print("FATAL: %s" % exc, file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("interrupted", file=sys.stderr)
        return 130

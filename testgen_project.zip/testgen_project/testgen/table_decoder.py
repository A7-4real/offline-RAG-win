"""Decode a Word table into plain data, with no LLM.

Why this exists: python-docx `row.cells` repeats merged cells and loses which
value belongs to which header column. Complex tables (several merged header rows,
sub-columns, lane columns 1..4) must be read from the XML grid instead.

Pipeline inside decode_table():
    1. build_grid       XML -> rectangular grid; every cell knows its span and
                        a shared identity across the grid positions it covers
    2. detect_header_rows   how many top rows are headers (overridable)
    3. header paths     each grid column gets a path like
                        ["Section A", "Field 1", "Byte 1", "2"]
    4. fields           columns are grouped: lanes (same parent, numeric last
                        segment, e.g. ... / 1, 2, 3, 4) become ONE field with
                        several values; every other column is a scalar field
    5. rows             each data row becomes {field key: [values]}

Decoded table shape (plain dicts, JSON friendly):
    {"layout_hash": str, "n_header_rows": int, "n_cols": int, "n_rows": int,
     "id_column": bool,
     "fields": [{"key": "Section A / Flag", "path": [...], "kind": "scalar"|"lanes",
                 "lane_labels": ["1","2","3","4"], "cols": [3,4,5,6]}],
     "rows":   [{"row_id": "1", "row_index": 1, "source_row": 4,
                 "values": {"Section A / Flag": ["0"], ...}}],
     "warnings": [str]}
Values are strings (leading zeros are preserved) or None for "don't care".
If you maintain your own decoder, anything that returns this shape can replace
this module.
"""
from __future__ import annotations

import hashlib
import re
from typing import Any, Dict, Iterator, List, Optional, Sequence

from docx.oxml.ns import qn

SEP = " / "
MAX_COLS = 400
MAX_ROWS = 5000
ID_HEADER_RE = re.compile(
    r"^(row|no\.?|#|tc|id|tc\s*id|test\s*(case|step|id|no\.?)|step|seq\.?|index|s\.?\s*no\.?|sl\.?\s*no\.?)$",
    re.I)
_NUMERIC_RE = re.compile(r"^-?\d+(\.\d+)?$")
_DIGITS_RE = re.compile(r"^\d+$")

Cell = Dict[str, Any]
Grid = List[List[Cell]]


# ---------------------------------------------------------------------------
# 1. XML -> grid
# ---------------------------------------------------------------------------
def _cell_text(tc: Any) -> str:
    """All text of a cell (nested tables flattened), whitespace collapsed."""
    parts = []
    for para in tc.iter(qn("w:p")):
        text = "".join(t.text or "" for t in para.iter(qn("w:t")))
        text = re.sub(r"\s+", " ", text).strip()
        if text:
            parts.append(text)
    return " ".join(parts)


def _int_val(element: Any, default: int) -> int:
    if element is None:
        return default
    try:
        return int(element.get(qn("w:val")))
    except (TypeError, ValueError):
        return default


def _tr_cells(tr: Any) -> Iterator[Any]:
    """Cells of a row, also those wrapped in content controls (w:sdt)."""
    for child in tr:
        if child.tag == qn("w:tc"):
            yield child
        elif child.tag == qn("w:sdt"):
            content = child.find(qn("w:sdtContent"))
            if content is not None:
                for inner in content:
                    if inner.tag == qn("w:tc"):
                        yield inner


def build_grid(tbl: Any, warnings: List[str]) -> Grid:
    """Rectangular grid of cell dicts. Merged cells share ONE dict object."""
    rows = list(tbl.findall(qn("w:tr")))
    if not rows:
        return []
    next_id = [0]

    def new_cell(text: str, r: int, c: int, span: int) -> Cell:
        next_id[0] += 1
        return {"id": next_id[0], "text": text, "r0": r, "c0": c, "colspan": span, "rowspan": 1}

    grid: Grid = []
    open_v: Dict[int, Cell] = {}            # column -> cell whose vertical merge is open
    for r_idx, tr in enumerate(rows):
        row: List[Cell] = []
        tr_pr = tr.find(qn("w:trPr"))
        if tr_pr is not None:
            for _ in range(max(0, min(_int_val(tr_pr.find(qn("w:gridBefore")), 0), MAX_COLS))):
                row.append(new_cell("", r_idx, len(row), 1))
        new_open: Dict[int, Cell] = {}
        for tc in _tr_cells(tr):
            tc_pr = tc.find(qn("w:tcPr"))
            span = 1
            v_merge = None
            if tc_pr is not None:
                span = max(1, min(_int_val(tc_pr.find(qn("w:gridSpan")), 1), MAX_COLS))
                v_merge = tc_pr.find(qn("w:vMerge"))
            col = len(row)
            cell: Optional[Cell] = None
            if v_merge is not None and v_merge.get(qn("w:val")) in (None, "continue"):
                origin = open_v.get(col)
                if origin is not None and origin["colspan"] == span and origin["c0"] == col:
                    origin["rowspan"] += 1
                    cell = origin
                else:
                    warnings.append("row %d: vertical merge without a start cell; treated as a normal cell"
                                    % (r_idx + 1))
            if cell is None:
                cell = new_cell(_cell_text(tc), r_idx, col, span)
            if v_merge is not None:
                for k in range(span):
                    new_open[col + k] = cell
            for _ in range(span):
                row.append(cell)
            if len(row) > MAX_COLS:
                raise ValueError("table has more than %d grid columns" % MAX_COLS)
        open_v = new_open
        grid.append(row)
    width = max(len(r) for r in grid)
    if width == 0:
        return []
    for r_idx, row in enumerate(grid):
        while len(row) < width:
            row.append(new_cell("", r_idx, len(row), 1))
    if len(grid) > MAX_ROWS:
        warnings.append("table has %d rows; only the first %d were read" % (len(grid), MAX_ROWS))
        grid = grid[:MAX_ROWS]
    return grid


def transpose_grid(grid: Grid) -> Grid:
    """Swap rows and columns (for tables where each test case is a column)."""
    if not grid:
        return grid
    mapping: Dict[int, Cell] = {}
    for row in grid:
        for cell in row:
            if cell["id"] not in mapping:
                mapping[cell["id"]] = {"id": cell["id"], "text": cell["text"], "r0": cell["c0"],
                                       "c0": cell["r0"], "rowspan": cell["colspan"],
                                       "colspan": cell["rowspan"]}
    n_rows, n_cols = len(grid), len(grid[0])
    return [[mapping[grid[r][c]["id"]] for r in range(n_rows)] for c in range(n_cols)]


# ---------------------------------------------------------------------------
# 2. header rows
# ---------------------------------------------------------------------------
def unique_cells(row: Sequence[Cell]) -> List[Cell]:
    seen = set()
    out = []
    for cell in row:
        if cell["id"] not in seen:
            seen.add(cell["id"])
            out.append(cell)
    return out


def _has_hspan(row: Sequence[Cell]) -> bool:
    return any(c["colspan"] > 1 and c["text"] for c in unique_cells(row))


def _is_counter_row(row: Sequence[Cell]) -> bool:
    """A row like 1 2 3 4 | 1 2 3 4 (lane numbers under a group header)."""
    texts = [c["text"] for c in unique_cells(row) if c["text"]]
    if len(texts) < 2 or not all(_DIGITS_RE.match(t) for t in texts) or texts[0] != "1":
        return False
    prev = 1
    for text in texts[1:]:
        value = int(text)
        if value != prev + 1 and value != 1:
            return False
        prev = value
    return True


def _mostly_numeric(row: Sequence[Cell]) -> bool:
    texts = [c["text"] for c in unique_cells(row) if c["text"]]
    if not texts:
        return False
    return sum(1 for t in texts if _NUMERIC_RE.match(t)) / float(len(texts)) >= 0.7


def detect_header_rows(grid: Grid) -> int:
    """Number of header rows (at least 1). Rules, in order, applied row by row:
      a) the row continues a vertical merge that started in a header row
      b) the row is a lane-counter row (1 2 3 4 ...) under a spanned header
      c) the row above has horizontally merged cells and this row has more
         cells, mostly text (sub-headers)
    Override with table_options.header_rows when a document defeats these rules.
    """
    n = len(grid)
    if n == 0:
        return 0
    k = 1
    while k < n:
        cur, prev = grid[k], grid[k - 1]
        if any(c["r0"] < k < c["r0"] + c["rowspan"] for c in unique_cells(cur)):
            k += 1
            continue
        if _has_hspan(prev) and _is_counter_row(cur):
            k += 1
            continue
        if (_has_hspan(prev) and len(unique_cells(cur)) > len(unique_cells(prev))
                and not _mostly_numeric(cur)
                and sum(1 for c in unique_cells(cur) if c["text"]) >= 0.5 * len(unique_cells(cur))):
            k += 1
            continue
        break
    return k


# ---------------------------------------------------------------------------
# 3-5. paths, fields, rows
# ---------------------------------------------------------------------------
def header_path(grid: Grid, col: int, n_header: int) -> List[str]:
    path: List[str] = []
    last_id = None
    for r in range(n_header):
        cell = grid[r][col]
        if cell["id"] == last_id:
            continue
        last_id = cell["id"]
        text = cell["text"]
        if text and (not path or path[-1] != text):
            path.append(text)
    return path


def _unique_key(key: str, used: set) -> str:
    if key not in used:
        used.add(key)
        return key
    n = 2
    while "%s [%d]" % (key, n) in used:
        n += 1
    key = "%s [%d]" % (key, n)
    used.add(key)
    return key


def _looks_like_id_column(grid: Grid, n_header: int, path: List[str], opt: Optional[bool]) -> bool:
    if opt is not None:
        return bool(opt)
    data = [grid[r][0] for r in range(n_header, len(grid))]
    leaf = path[-1] if path else ""
    if len(path) >= 2 and _DIGITS_RE.match(leaf):
        return False
    if ID_HEADER_RE.match(leaf.strip()):
        return True
    texts = [c["text"] for c in data]
    if len(texts) >= 2 and all(_DIGITS_RE.match(t) for t in texts):
        return [int(t) for t in texts] == list(range(1, len(texts) + 1))
    return False


def decode_table(tbl: Any, options: Optional[Dict[str, Any]] = None,
                 dont_care: Sequence[str] = ("", "-", "x", "n/a")) -> Dict[str, Any]:
    """Decode one <w:tbl> element. Raises ValueError for unusable tables."""
    opts = options or {}
    warnings: List[str] = []
    grid = build_grid(tbl, warnings)
    if not grid:
        raise ValueError("table has no cells")
    if opts.get("transpose"):
        grid = transpose_grid(grid)
    width = len(grid[0])
    n_rows = len(grid)
    override = opts.get("header_rows")
    if isinstance(override, int) and not isinstance(override, bool) and override >= 1:
        n_header = min(override, n_rows)
        if override > n_rows:
            warnings.append("header_rows=%d is larger than the table (%d rows)" % (override, n_rows))
    else:
        n_header = detect_header_rows(grid)
    paths = [header_path(grid, c, n_header) for c in range(width)]
    has_id = width >= 2 and _looks_like_id_column(grid, n_header, paths[0], opts.get("id_column"))
    first_col = 1 if has_id else 0

    # --- fields: group lane columns, everything else is scalar -----------------
    care = {str(v).strip().lower() for v in dont_care}
    fields: List[Dict[str, Any]] = []
    used: set = set()
    col = first_col
    while col < width:
        path = paths[col]
        lane_leaf = len(path) >= 2 and _DIGITS_RE.match(path[-1])
        if lane_leaf:
            parent = path[:-1]
            cols = [col]
            labels = [path[-1]]
            nxt = col + 1
            while (nxt < width and len(paths[nxt]) >= 2 and paths[nxt][:-1] == parent
                   and _DIGITS_RE.match(paths[nxt][-1]) and int(paths[nxt][-1]) > int(labels[-1])):
                cols.append(nxt)
                labels.append(paths[nxt][-1])
                nxt += 1
            if len(cols) >= 2:
                fields.append({"key": _unique_key(SEP.join(parent), used), "path": list(parent),
                               "kind": "lanes", "lane_labels": labels, "cols": cols})
                col = nxt
                continue
        key = SEP.join(path) if path else "col%d" % (col + 1)
        if not path:
            warnings.append("column %d has no header text; named %r" % (col + 1, key))
        fields.append({"key": _unique_key(key, used), "path": list(path), "kind": "scalar",
                       "lane_labels": [], "cols": [col]})
        col += 1

    # --- data rows -------------------------------------------------------------
    rows: List[Dict[str, Any]] = []
    blank = 0
    merged_note = False
    for r in range(n_header, n_rows):
        values: Dict[str, List[Optional[str]]] = {}
        any_value = False
        for fld in fields:
            vals: List[Optional[str]] = []
            for c in fld["cols"]:
                cell = grid[r][c]
                if cell["colspan"] > 1 or cell["rowspan"] > 1:
                    merged_note = True
                text = cell["text"].strip()
                if text.lower() in care:
                    vals.append(None)
                else:
                    vals.append(text)
                    any_value = True
            values[fld["key"]] = vals
        row_id = grid[r][0]["text"].strip() if has_id else ""
        if not any_value and not row_id:
            blank += 1
            continue
        index = len(rows) + 1
        rows.append({"row_id": row_id or str(index), "row_index": index,
                     "source_row": r, "values": values})
    if blank:
        warnings.append("%d blank row(s) skipped" % blank)
    if merged_note:
        warnings.append("data cells are merged; a merged value is repeated for every column it covers")
    if not rows:
        warnings.append("table has a header but no data rows")
    layout = "|".join("%s:%s:%d" % (f["key"], f["kind"], len(f["cols"])) for f in fields) + "|h%d" % n_header
    return {"layout_hash": hashlib.sha1(layout.encode("utf-8")).hexdigest()[:12],
            "n_header_rows": n_header, "n_cols": width, "n_rows": len(rows),
            "id_column": has_id, "fields": fields, "rows": rows, "warnings": warnings}


# ---------------------------------------------------------------------------
# text views (for review files and fallbacks; the pipeline itself never needs them)
# ---------------------------------------------------------------------------
def _cell(value: Optional[str]) -> str:
    return "" if value is None else str(value).replace("|", "\\|")


def to_markdown(decoded: Dict[str, Any], style: str = "per_case") -> str:
    """per_case: one small table per row (best for a human or a small model).
    flat: one wide table (compact, hard to read when there are many columns)."""
    fields, rows = decoded["fields"], decoded["rows"]
    out: List[str] = []
    if style == "flat":
        heads = []
        for f in fields:
            if f["kind"] == "lanes":
                heads.extend("%s #%s" % (f["key"], lab) for lab in f["lane_labels"])
            else:
                heads.append(f["key"])
        out.append("| Row | " + " | ".join(_cell(h) for h in heads) + " |")
        out.append("|" + "---|" * (len(heads) + 1))
        for row in rows:
            cells: List[str] = []
            for f in fields:
                cells.extend(_cell(v) for v in row["values"][f["key"]])
            out.append("| %s | %s |" % (_cell(row["row_id"]), " | ".join(cells)))
        return "\n".join(out)
    max_lanes = max([len(f["lane_labels"]) for f in fields if f["kind"] == "lanes"] or [0])
    head = ["Field", "Value"] + ["Lane %d" % (i + 1) for i in range(max_lanes)]
    for row in rows:
        out.append("### Row %s" % row["row_id"])
        out.append("| " + " | ".join(head) + " |")
        out.append("|" + "---|" * len(head))
        for f in fields:
            vals = row["values"][f["key"]]
            if f["kind"] == "lanes":
                lanes = [_cell(v) for v in vals] + [""] * (max_lanes - len(vals))
                out.append("| %s |  | %s |" % (_cell(f["key"]), " | ".join(lanes)))
            else:
                out.append("| %s | %s |%s" % (_cell(f["key"]), _cell(vals[0]), " |" * max_lanes))
        out.append("")
    return "\n".join(out)


def flatten_text(decoded: Dict[str, Any]) -> str:
    """One line per row: 'Row 1: key=value; key=[a,b,c,d]'."""
    lines = []
    for row in decoded["rows"]:
        parts = []
        for f in decoded["fields"]:
            vals = row["values"][f["key"]]
            if f["kind"] == "lanes":
                parts.append("%s=[%s]" % (f["key"], ",".join("" if v is None else v for v in vals)))
            else:
                parts.append("%s=%s" % (f["key"], "" if vals[0] is None else vals[0]))
        lines.append("Row %s: %s" % (row["row_id"], "; ".join(parts)))
    return "\n".join(lines)

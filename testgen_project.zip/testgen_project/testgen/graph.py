"""LangGraph wiring.

    START -> load -> sections -> roles -> recipes -> assemble -> notes
          -> ground -> validate -> render -> END
with a conditional edge after every node: a fatal error or --stop-after jumps
straight to END.

Engines
    langgraph   the real langgraph.graph.StateGraph
    sequential  a 30-line runner with the same node functions and reducers, used
                automatically when langgraph is not installed (engine = "auto")
Both engines run the same node functions, so results are identical. If the
LangGraph engine itself raises (not a stage - stages never raise), "auto" mode
logs it and re-runs with the sequential engine.
"""
from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional

from .issues import FatalError
from .stages import STAGES, RunContext, make_node
from .state import REDUCERS, RunState

END_NODE = "__end__"       # same value as langgraph.graph.END


def build_nodes(ctx: RunContext) -> List[Any]:
    return [(name, make_node(ctx, i, name, fn)) for i, (name, fn) in enumerate(STAGES)]


def make_router(ctx: RunContext, idx: int, next_name: str, end: Any) -> Callable[[Dict[str, Any]], Any]:
    def route(state: Dict[str, Any]) -> Any:
        if state.get("fatal"):
            return end
        if ctx.stop_after is not None and idx >= ctx.stop_after:
            return end
        return next_name
    return route


class SequentialApp:
    """Minimal stand-in for a compiled graph: invoke(state) -> final state."""

    def __init__(self, nodes: List[Any], routers: List[Callable[[Dict[str, Any]], Any]]) -> None:
        self.nodes = nodes
        self.routers = routers

    def invoke(self, state: Dict[str, Any], config: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        state = dict(state)
        index = {name: i for i, (name, _) in enumerate(self.nodes)}
        current = self.nodes[0][0]
        for _ in range(len(self.nodes) + 2):           # hard stop against routing bugs
            if current == END_NODE:
                break
            i = index[current]
            update = self.nodes[i][1](state) or {}
            for key, value in update.items():
                if key in REDUCERS:
                    state[key] = REDUCERS[key](state.get(key, []), value)
                else:
                    state[key] = value
            current = self.routers[i](state)
        return state


def build_langgraph_app(ctx: RunContext) -> Any:
    from langgraph.graph import END, START, StateGraph      # raises ImportError if missing
    nodes = build_nodes(ctx)
    graph = StateGraph(RunState)
    for name, fn in nodes:
        graph.add_node(name, fn)
    graph.add_edge(START, nodes[0][0])
    for i, (name, _) in enumerate(nodes):
        nxt = nodes[i + 1][0] if i + 1 < len(nodes) else END
        route = make_router(ctx, i, nxt, END)
        graph.add_conditional_edges(name, route, {nxt: nxt, END: END})
    return graph.compile()


def build_sequential_app(ctx: RunContext) -> SequentialApp:
    nodes = build_nodes(ctx)
    routers = []
    for i in range(len(nodes)):
        nxt = nodes[i + 1][0] if i + 1 < len(nodes) else END_NODE
        routers.append(make_router(ctx, i, nxt, END_NODE))
    return SequentialApp(nodes, routers)


def build_app(ctx: RunContext, engine: str = "auto") -> Any:
    """Return (app, engine_used)."""
    if engine in ("auto", "langgraph"):
        try:
            return build_langgraph_app(ctx), "langgraph"
        except ImportError as exc:
            if engine == "langgraph":
                raise FatalError("engine 'langgraph' requested but langgraph is not installed (%s)" % exc)
    return build_sequential_app(ctx), "sequential"

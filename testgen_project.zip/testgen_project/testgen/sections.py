"""Stage 1: group blocks into sections and label every section.

Section = one heading plus the blocks until the next heading. Labels:
index, document_info, requirements, initialization, test_inputs,
expected_outputs, constraints, other.

Labelling order
    1. a keyword rule gives a *hint* (cheap, deterministic)
    2. the LLM labels all sections (enum-constrained, in batches with overlap
       when the document has many sections); disagreements with the rule are
       reported
    3. if the LLM is off or fails, the rule label is used; with no rule match the
       label is 'other' and a review issue is raised
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from .config import SECTION_LABELS
from .grounding import normalize
from .issues import make_issue
from .llm_client import LLMClient, LLMError
from .prompts import SYSTEM_JSON, section_labels_prompt
from .schema import section_labels_schema

PRIORITY = ["expected_outputs", "test_inputs", "initialization", "constraints",
            "requirements", "document_info", "index"]
USEFUL = ("initialization", "test_inputs", "expected_outputs", "constraints")


def build_sections(blocks: List[Dict[str, Any]], preview_chars: int = 300) -> List[Dict[str, Any]]:
    """Cut the block list at every heading."""
    sections: List[Dict[str, Any]] = []
    current: Optional[Dict[str, Any]] = None

    def new(heading: str, level: int, order: int) -> Dict[str, Any]:
        sec = {"id": "S%03d" % len(sections), "heading": heading, "level": level, "start_order": order,
               "block_ids": [], "table_block_ids": [], "n_paragraphs": 0, "n_lists": 0,
               "label": None, "rule_label": None, "label_source": "", "preview": ""}
        sections.append(sec)
        return sec

    for b in blocks:
        if b["kind"] == "heading":
            current = new(b["text"], b["level"], b["order"])
            continue
        if current is None:
            current = new("(preamble)", 0, b["order"])
        current["block_ids"].append(b["id"])
        if b["kind"] == "table":
            current["table_block_ids"].append(b["id"])
        elif b["kind"] == "list":
            current["n_lists"] += 1
        else:
            current["n_paragraphs"] += 1
    by_id = {b["id"]: b for b in blocks}
    for sec in sections:
        pieces = []
        for bid in sec["block_ids"]:
            b = by_id[bid]
            if b["kind"] == "table":
                heads = [f["key"] for f in (b["table"] or {}).get("fields", [])][:6]
                pieces.append("[table: %s]" % (", ".join(heads) if heads else "unreadable"))
            else:
                pieces.append(b["text"])
        sec["preview"] = " | ".join(pieces)[:preview_chars]
    return sections


def rule_label(text: str, rules: Dict[str, List[str]]) -> Optional[str]:
    """Best keyword-rule label for a heading, or None."""
    norm = " " + normalize(text) + " "
    best: Optional[Tuple[int, int, str]] = None
    for label, words in rules.items():
        hits = sum(1 for w in words if normalize(w) and normalize(w) in norm)
        if not hits:
            continue
        prio = PRIORITY.index(label) if label in PRIORITY else len(PRIORITY)
        cand = (hits, -prio, label)
        if best is None or cand > best:
            best = cand
    return best[2] if best else None


def plan_batches(n: int, size: int, overlap: int) -> List[List[int]]:
    """Index windows of `size` sections that overlap by `overlap`."""
    size = max(1, size)
    overlap = max(0, min(overlap, size - 1))
    if n <= size:
        return [list(range(n))] if n else []
    batches, start = [], 0
    while True:
        end = min(start + size, n)
        batches.append(list(range(start, end)))
        if end >= n:
            break
        start = end - overlap
    return batches


def _summary(sec: Dict[str, Any]) -> str:
    parts = []
    if sec["n_paragraphs"]:
        parts.append("%d paragraph(s)" % sec["n_paragraphs"])
    if sec["n_lists"]:
        parts.append("%d list item(s)" % sec["n_lists"])
    if sec["table_block_ids"]:
        parts.append("%d table(s)" % len(sec["table_block_ids"]))
    return ", ".join(parts) or "empty"


def label_sections(sections: List[Dict[str, Any]], client: LLMClient, cfg: Dict[str, Any]
                   ) -> List[Dict[str, str]]:
    """Fill sec['label'] / ['rule_label'] / ['label_source'] in place; return issues."""
    issues: List[Dict[str, str]] = []
    rules = cfg["keyword_rules"]
    scfg = cfg["sections"]
    for sec in sections:
        sec["rule_label"] = rule_label(sec["heading"], rules)
    llm_labels: Dict[str, str] = {}
    if client.enabled and sections:
        for batch in plan_batches(len(sections), int(scfg["batch_size"]), int(scfg["overlap"])):
            sub = [sections[i] for i in batch]
            preview = int(scfg["preview_chars"])
            while True:                                     # shrink previews to fit the prompt budget
                items = [{"id": s["id"], "heading": s["heading"], "summary": _summary(s),
                          "preview": s["preview"][:preview], "hint": s["rule_label"] or ""} for s in sub]
                prompt = section_labels_prompt(items, SECTION_LABELS)
                if len(prompt) <= int(scfg["max_prompt_chars"]) or preview <= 40:
                    break
                preview = max(40, preview // 2)
            ids = [s["id"] for s in sub]

            def check(parsed: Any, ids: List[str] = ids) -> List[str]:
                got = [e["id"] for e in parsed["labels"]]
                missing = [i for i in ids if i not in got]
                dup = sorted({i for i in got if got.count(i) > 1})
                errs = []
                if missing:
                    errs.append("missing sections %s" % missing)
                if dup:
                    errs.append("sections labelled twice: %s" % dup)
                return errs
            try:
                answer = client.ask_json("section_labels", SYSTEM_JSON, prompt,
                                         section_labels_schema(ids, SECTION_LABELS), check=check)
            except LLMError as exc:
                issues.append(make_issue("review", "sections",
                                         "LLM labelling failed for sections %s..%s (%s); rule labels used"
                                         % (ids[0], ids[-1], exc), "%s..%s" % (ids[0], ids[-1])))
                continue
            for entry in answer["labels"]:
                prev = llm_labels.get(entry["id"])
                if prev is None:
                    llm_labels[entry["id"]] = entry["label"]
                elif prev != entry["label"]:
                    issues.append(make_issue("review", "sections",
                                             "overlapping batches disagree on %s (%s vs %s); first kept"
                                             % (entry["id"], prev, entry["label"]), entry["id"]))
    for sec in sections:
        llm = llm_labels.get(sec["id"])
        rule = sec["rule_label"]
        if llm:
            sec["label"], sec["label_source"] = llm, "llm"
            if rule and rule != llm:
                sev = "review" if (llm in USEFUL or rule in USEFUL) else "info"
                issues.append(make_issue(sev, "sections",
                                         "label %r (LLM) differs from keyword rule %r for heading %r"
                                         % (llm, rule, sec["heading"]), sec["id"],
                                         "check the section label in 01_sections.json"))
        elif rule:
            sec["label"], sec["label_source"] = rule, "rule"
        else:
            sec["label"], sec["label_source"] = "other", "default"
            if sec["block_ids"]:
                issues.append(make_issue("review", "sections",
                                         "could not label section %r; treated as 'other'" % sec["heading"],
                                         sec["id"], "set the label by hand in 01_sections.json and resume from stage 2"))
    return issues
